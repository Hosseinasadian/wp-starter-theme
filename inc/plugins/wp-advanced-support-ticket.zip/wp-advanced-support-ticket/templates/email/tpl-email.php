<div style="direction: rtl; width: 100%; background: #f1f2f6; text-align: right; font-family: Tahoma, sans-serif; font-size: 14px; line-height: 30px; color: #464646; border-radius: 3px">
	<div style="padding: 15px 25px;">
        <p style="text-align: center; margin-bottom: 10px;"><img src="##site-logo##" alt="logo"></p>
		<p><strong>##ticket-title##</strong></p>
		<p>سلام ##recipient-name## عزیز</p>
        <p>کاربر ##sender-name## در تاریخ <em style="color: #999999;" dir="ltr">##date##</em>  یک تیکت پشتیبانی <span class="p-title">در ارتباط با محصول <strong>##product-title##</strong></span> ارسال کرده است.</p>
		<p style="text-align: center;">##ticket-url##</p>
        <p style="font-size: 12px; text-align: justify; margin: 15px 0; background: #dedfe3; padding: 15px; border-radius: 3px;">##footer-text##</p>
        <p style="text-align: center; font-size: 11px;">##site-url##</p>
	</div>
</div>