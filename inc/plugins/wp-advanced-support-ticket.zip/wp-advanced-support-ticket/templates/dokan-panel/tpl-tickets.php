<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );

/**
 *  Dokan Dashboard Template
 *
 *  Dokan Main Dahsboard template for Fron-end
 *
 *  @since 2.4
 *
 *  @package dokan
 */
?>
<div class="dokan-dashboard-wrap">
	<?php
	/**
	 *  dokan_dashboard_content_before hook
	 *
	 *  @hooked get_dashboard_side_navigation
	 *
	 *  @since 2.4
	 */
	do_action( 'dokan_dashboard_content_before' );
	?>

	<div class="dokan-dashboard-content">

		<?php
		/**
		 *  dokan_dashboard_content_before hook
		 *
		 *  @hooked show_seller_dashboard_notice
		 *
		 *  @since 2.4
		 */
		do_action( 'dokan_help_content_inside_before' );
		?>

		<?php
		if ( isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ) {
			if ( $_GET['action'] == 'new' ) {
				wast_send_ticket();
				include( WAST_TPL_PATH . 'panel/tpl-new-ticket.php' );
			} elseif ( $_GET['action'] == 'reply' ) {
				wast_reply_ticket();
				include( WAST_TPL_PATH . 'panel/tpl-reply-ticket.php' );
			}
		} else {
			include( WAST_TPL_PATH . 'panel/tpl-all-tickets.php' );
		}
		?>

		<?php
		/**
		 *  dokan_dashboard_content_inside_after hook
		 *
		 *  @since 2.4
		 */
		do_action( 'dokan_dashboard_content_inside_after' );
		?>


	</div><!-- .dokan-dashboard-content -->

	<?php
	/**
	 *  dokan_dashboard_content_after hook
	 *
	 *  @since 2.4
	 */
	do_action( 'dokan_dashboard_content_after' );
	?>

</div><!-- .dokan-dashboard-wrap -->