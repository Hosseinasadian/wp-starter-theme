<?php wast_print_user_ticket_statistics();?>
<div class="wast-wrapper">
	<div class="wast-list-header">
    <h3 class="wast-title wast-clearfix">
        <span>فهرست تیکت ها</span>
    </h3>
	<div class="wast-filter wast-clearfix">
		<form id="wast-filter" method="get">
			<div class="alm-wast-filter-item">
				<span class="alm-wast-filter-item-label">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
						<path d="M2.25 5.25H15.75" stroke="#373254" stroke-width="1.5" stroke-linecap="round"/>
						<path d="M4.5 9H13.5" stroke="#373254" stroke-width="1.5" stroke-linecap="round"/>
						<path d="M7.5 12.75H10.5" stroke="#373254" stroke-width="1.5" stroke-linecap="round"/>
					</svg>
					همه
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
  						<path d="M13.2807 5.96655L8.93404 10.3132C8.4207 10.8266 7.5807 10.8266 7.06737 10.3132L2.7207 5.96655" stroke="#373254" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</span>

				<select name="status" class="wast-custom-select">
					<option value="all">همه</option>
					<?php
					foreach ( wast_get_ticket_statuses() as $key => $value ) {
						$status = 'all';
						if ( isset( $_GET['status'] ) && ! empty( $_GET['status'] ) && in_array( $_GET['status'], array_keys( wast_get_ticket_statuses() ) ) ) {
							$status = $_GET['status'];
						}
						$selected = $status == $key ? 'selected' : '';
						echo '<option value="' . $key . '" ' . $selected . '>' . $value . '</option>';
					}
					?>
				</select>
			</div>
		</form>
	</div>
	<a href="<?php echo add_query_arg( array( 'action' => 'new' ), remove_query_arg( array( 'page-number',
		'status' ) ) ); ?>" class="alm-wast-header-button wast-float-left">
		<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
			<path opacity="0.4" d="M12.1425 1.5H5.8575C3.1275 1.5 1.5 3.1275 1.5 5.8575V12.135C1.5 14.8725 3.1275 16.5 5.8575 16.5H12.135C14.865 16.5 16.4925 14.8725 16.4925 12.1425V5.8575C16.5 3.1275 14.8725 1.5 12.1425 1.5Z" fill="#8D8D8D"/>
			<path d="M12 8.4375H9.5625V6C9.5625 5.6925 9.3075 5.4375 9 5.4375C8.6925 5.4375 8.4375 5.6925 8.4375 6V8.4375H6C5.6925 8.4375 5.4375 8.6925 5.4375 9C5.4375 9.3075 5.6925 9.5625 6 9.5625H8.4375V12C8.4375 12.3075 8.6925 12.5625 9 12.5625C9.3075 12.5625 9.5625 12.3075 9.5625 12V9.5625H12C12.3075 9.5625 12.5625 9.3075 12.5625 9C12.5625 8.6925 12.3075 8.4375 12 8.4375Z" fill="#8D8D8D"/>
		</svg>
		ایجاد تیکت
	</a>
	</div>
    <hr class="wast-hr">

	<table class="wast-table">
		<thead class="wast-thead-light">
		<tr>
			<th class="wast-id-column" scope="col">شناسه</th>
			<th class="wast-title-column" scope="col">عنوان</th>
			<th class="wast-section-column" scope="col">دپارتمان</th>
			<th class="wast-status-column" scope="col">وضعیت</th>
			<th class="wast-priority-column" scope="col">اولویت</th>
			<th class="wast-date-column" scope="col">آخرین تغییر</th>
			<th class="wast-actions-column" scope="col">عملیات</th>
		</tr>
		</thead>
		<?php

		$tickets = wast_get_user_tickets();

		if ( $tickets && sizeof( $tickets ) ) {
			?>
				<tbody>
					<?php
					foreach ( $tickets as $ticket ) {
						$tiket_reply_link = add_query_arg( 
							array( 
								'action'    => 'reply',
								'ticket_id' => $ticket->ID 
							), 
							remove_query_arg( 
								array( 
									'page-number',
									'status'
								)
							)
						);
						$section_name = '';
						$terms = wp_get_post_terms( $ticket->ID, 'ticket-type' );
						if ( $terms && is_array( $terms ) ) {
							if ( isset( $terms[0]->name ) ) {
								$section_name = $terms[0]->name;
							}
						}

						$priority_term = get_post_meta( $ticket->ID, '_wast_ticket_priority', true );
						$priority = '';
						switch ( $priority ) {
							case 'low':
								$priority = 'کم';
								break;
							default:
							case 'medium':
								$priority = 'متوسط';
								break;
							case 'high':
								$priority = 'زیاد';
								break;
						}
						?>
						<tr>
							<td class="wast-id-column" data-title="شناسه">
								<?php echo $ticket->ID;?>
							</td>
							<td class="wast-title-column" data-title="عنوان">
								<?php echo $ticket->post_title; ?>
							</td>
							<td class="wast-section-column" data-title="دپارتمان">
								<?php echo $section_name;?>
							</td>
							<td class="wast-status-column" data-title="وضعیت">
								<?php
								$status = get_post_status( $ticket->ID );
								foreach ( wast_get_ticket_statuses() as $key => $value ) {
									if ( $status == $key ) {
										echo '<span class="alm-wast-status">' . $value . '</span>';
										break;
									}
								}
								?>
							</td>
							<td class="wast-priority-column" data-title="اولویت">
								<?php echo $priority;?>
							</td>
							<td class="wast-date-column" data-title="آخرین تغییر">
								<?php
								$replies = wast_get_ticket_replies( $ticket->ID );
								if ( sizeof( $replies ) ) {
									echo wast_time_ago( $replies[ sizeof( $replies ) - 1 ]['date'] );

								}else{
									echo wast_time_ago( get_the_time( 'U', $ticket->ID ) );
								}
								?>
							</td>
							<td class="wast-date-column" data-title="عملیات">
								<a href="<?php echo $tiket_reply_link?>">باز</a>
							</td>
						</tr>
						<?php
					}
					wp_reset_query();
					?>
				</tbody>
			<?php
		}

		?>
	</table>

	<?php
	if ( $tickets && sizeof( $tickets ) ) {
		$page_number = 1;
		if ( isset( $_GET['page-number'] ) && ctype_digit( $_GET['page-number'] ) ) {
			$page_number = $_GET['page-number'];
		}
		$posts_per_page = wast_get_option( 'posts-per-page' ) ? wast_get_option( 'posts-per-page' ) : 20;


		$big  = 999999999;
		$args = array(
			'base' => preg_replace('/\?.*/', '', get_pagenum_link()) . '%_%',
			'format'    => '?page-number=%#%',
			'total'     => ceil(wast_get_user_tickets_count()/$posts_per_page),
			'current'   => max( 1, $page_number ),
			'show_all'  => false,
		);

		ob_start();
		echo paginate_links( $args );
		$pagination_links = ob_get_clean();
		if($pagination_links){
			echo "<div class='wast-pagination-links'>$pagination_links</div>";
		}
		?>
		<?php
	} else {
		?>
		<span class="alm-account-empty-tickets">
			<span class="alm-account-empty-tickets-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120" fill="none">
					<path d="M18.3496 12.5V72.35C18.3496 77.25 20.6496 81.9 24.5996 84.85L50.6496 104.35C56.1996 108.5 63.8496 108.5 69.3996 104.35L95.4495 84.85C99.3995 81.9 101.7 77.25 101.7 72.35V12.5H18.3496Z" stroke="#373254" stroke-width="4" stroke-miterlimit="10"/>
					<path d="M10 12.5H110" stroke="#373254" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round"/>
					<path d="M40 40H80" stroke="#373254" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M40 65H80" stroke="#373254" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</span>
			<span class="alm-account-empty-tickets-message">
				<?php esc_html_e('تیکتی وجود ندارد.','alma')?>
			</span>
		</span>

		<?php
	}
	?>
</div>