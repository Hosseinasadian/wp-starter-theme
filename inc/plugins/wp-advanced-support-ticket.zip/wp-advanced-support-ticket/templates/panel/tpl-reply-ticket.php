<?php
if ( ! isset( $_GET['ticket_id'] ) || ! ctype_digit( $_GET['ticket_id'] ) ) {
	return;
}

$ticket_id = $_GET['ticket_id'];
$ticket    = get_post( $ticket_id );
$author    = $ticket->post_author;
$terms     = wp_get_post_terms( $ticket_id, 'ticket-type' );
$term      = null;
if ( count( $terms ) ) {
	$term = $terms[0]->term_id;
}

$status     = $ticket->post_status;
$product_id = get_post_meta( $ticket_id, '_wast_ticket_product_id', true );
$ath_file   = get_post_meta( $ticket_id, '_wast_ticket_ath_file', true );

if ( wast_get_dokan_dashboard_page() == get_the_ID() ) {
	$seller_products = wast_get_seller_products( get_current_user_id() );
	if ( get_current_user_id() == $ticket->post_author || ( in_array( $product_id, $seller_products ) && $term == wast_get_option( 'dokan-ticket-type' ) ) ) {
		// nothing
	} else {
		exit();
	}
} else {
	if ( get_current_user_id() != $ticket->post_author ) {
		exit();
	}
}
?>
<?php wast_print_user_ticket_statistics();?>
<div class="wast-wrapper">
    <h3 class="wast-title wast-clearfix">
        <span>تیکت شماره <?php echo esc_html($ticket_id)?></span>
        <a href="<?php echo remove_query_arg( array( 'action',
			'ticket_id' ) ); ?>" class="alm-wast-header-button wast-float-left">
			<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                 <path opacity="0.4" d="M12.1425 1.5H5.865C3.1275 1.5 1.5 3.1275 1.5 5.8575V12.135C1.5 14.865 3.1275 16.4925 5.8575 16.4925H12.1425C14.8725 16.5 16.5 14.8725 16.5 12.1425V5.8575C16.5 3.1275 14.8725 1.5 12.1425 1.5Z" fill="#8D8D8D"/>
                 <path d="M13.8975 8.60255L10.68 5.38505C10.4625 5.16755 10.1025 5.16755 9.885 5.38505C9.6675 5.60255 9.6675 5.96255 9.885 6.18005L12.1425 8.43755H4.5C4.1925 8.43755 3.9375 8.69255 3.9375 9.00005C3.9375 9.30755 4.1925 9.56255 4.5 9.56255H12.1425L9.885 11.82C9.6675 12.0375 9.6675 12.3975 9.885 12.615C9.9975 12.7275 10.14 12.78 10.2825 12.78C10.425 12.78 10.5675 12.7275 10.68 12.615L13.8975 9.39755C14.0025 9.29255 14.0625 9.15005 14.0625 9.00005C14.0625 8.85005 14.0025 8.70755 13.8975 8.60255Z" fill="#8D8D8D"/>
            </svg>  
			مشاهده همه تیکت‌ها
		</a>
    </h3>
    <hr class="wast-hr">

    <div class="wast-start-ticket wast-card <?php echo get_current_user_id() == $ticket->post_author?'wast-owner-card':''?>">
        <div class="wast-card-body">
            <h3 class="wast-card-title wast-title">
				<?php echo $ticket->post_title; ?>
            </h3>
			<div class="wast-card-content"><?php echo apply_filters( 'the_content', $ticket->post_content ); ?></div>
            <p class="wast-product-title">
                <span class="wast-product-title-label">محصول: </span>
				<?php
				if ( is_numeric( $product_id ) ) {
					echo '<a href="' . get_the_permalink( $product_id ) . '" target="_blank">' . get_the_title( $product_id ) . '</a>';

					if ( $author == get_current_user_id() ) {
						if ( wast_get_option( 'wc-support' ) && wast_get_option( 'expiration-time' ) == 'limilted' ) {
							if ( ! wast_is_customer_bought_product( $product_id ) ) {
								echo ' <small class="wast-expired">(اتمام پشتیبانی)</small>';
							} else {
								$product_exp_time = wast_get_exp_time( $product_id );
								if ( $product_exp_time && $author == get_current_user_id() ) {
									echo ' <time class="wast-exp-date wast-text-muted" dir="ltr">(اتمام پشتیبانی: ' . date_i18n( 'Y/m/d', $product_exp_time ) . ')</time>';
								}
							}
						}
					}
				} else {
					echo $product_id;
				}

				if ( $ath_file ) {
					echo '<a href="' . esc_url( $ath_file ) . '" class="wast-ath-file wast-float-left" title="فایل ضمیمه" target="_blank"><img src="' . WAST_IMG_URL . 'paperclip-gray.png" alt="فایل"></a>';
				}
				?>
            </p>
            <div class="alm-wast-metas">
				<?php
				foreach ( wast_get_ticket_statuses() as $key => $value ) {
					if ( $status == $key ) {
						echo '<div class="alm-wast-meta-first"><span class="alm-wast-status">' . $value . '</span></div>';
						break;
					}
				}
				?>
                <div class="alm-wast-meta-second">
                    <span class="alm-wast-meta">
                        <span class="alm-wast-meta-label">اولویت: </span>
						<?php
						$priority = get_post_meta( $ticket_id, '_wast_ticket_priority', true );
						echo '<span class="alm-wast-meta-value">';
						switch ( $priority ) {
							case 'low':
								echo 'کم';
								break;
							default:
							case 'medium':
								echo 'متوسط';
								break;
							case 'high':
								echo 'زیاد';
								break;
						}
						echo '</span>';
						?>
                    </span>

					<span class="alm-wast-meta">
						<span class="alm-wast-meta-label">تاریخ: </span>
                        <time class="alm-wast-meta-value" dir="ltr">
							<?php echo date_i18n( 'Y/m/d', get_the_time( 'U', $ticket->post_date ) ); ?>
                        </time>
					</span>

					<span class="alm-wast-meta">
						<span class="alm-wast-meta-label">دپارتمان: </span>
						<?php
						$terms = wp_get_post_terms( $ticket_id, 'ticket-type' );
						if ( $terms && is_array( $terms ) ) {
							if ( isset( $terms[0]->name ) ) {
								echo '<span class="alm-wast-meta-value">' . $terms[0]->name . '</span>';
							}
						}
						?>
                    </span>
                </div>
            </div>
        </div>
    </div>
	<?php
	$replies = wast_get_ticket_replies( $ticket_id );

	// Sort replies by date
	wast_aasort( $replies, "date" );

	if ( wast_get_option( 'ticket-order' ) == 'desc' ) {
		$replies = array_reverse( $replies );
	}

	if ( sizeof( $replies ) ) {
		foreach ( $replies as $reply ) {
			if ( ! is_array( $reply ) ) {
				continue;
			}

			if ( array_key_exists( 'content', $reply ) ) {
				if ( ! $reply['content'] ) {
					continue;
				}
			} else {
				continue;
			}

			$is_owner = get_current_user_id() == $reply['author_id'];

			?>
            <div class="wast-reply-item wast-card <?php echo $is_owner?'wast-owner-card':''; ?>">
                <div class="wast-card-body">
					<div class="wast-card-header">
						<h3 class="wast-card-title wast-title">
							<?php
								$author_id = $reply['author_id'];
								$user_info = get_userdata( $author_id );
							?>
							<?php echo $user_info->display_name; ?>
						</h3>
						<?php
								if ( array_key_exists( 'ath_file', $reply ) ) {
									echo '<a href="' . esc_url( $reply['ath_file'] ) . '" class="wast-ath-file wast-float-left" title="پیوست" target="_blank"><img src="' . WAST_IMG_URL . 'paperclip.png" alt="فایل"></a>';
								}
							?>
							<?php
								if ( user_can( $author_id, 'delete_others_pages' ) ) {
									echo wast_get_option( 'header-text' ) ? '<span class="wast-card-header-text wast-float-left">' . nl2br( wast_get_option( 'header-text' ) ) . '</span>' : '';
								}
							?>
					</div>

					<div class="wast-card-content"><?php echo apply_filters( 'the_content', $reply['content'] ); ?></div>
					<div class="alm-wast-metas">
						<div class="alm-wast-meta-first">
							<?php
								if ( user_can( $author_id, 'delete_others_pages' ) ) {
									echo wast_get_option( 'footer-text' ) ? '<span class="wast-card-footer-text">' . nl2br( wast_get_option( 'footer-text' ) ) . '</span>' : '';
								}
							?>
						</div>
						<div class="alm-wast-meta-second">
							<span class="alm-wast-meta">
								<span class="alm-wast-meta-label">تاریخ: </span>
								<time class="alm-wast-meta-value" dir="ltr">
									<?php echo date_i18n( 'Y/m/d', $reply['date'] ); ?>
								</time>
							</span>
						</div>
					</div>
                </div>
            </div>
			<?php
		}
	}

	?>

	<?php if($status !== 'closed'):?>

<form method="post" enctype="multipart/form-data" class="wast-reply-form">
		<?php WAST_Flash_Message::show_message(); ?>
        <input type="hidden" name="ticket-id" value="<?php echo esc_attr( $ticket_id ); ?>">
        <input type="hidden" name="product-id" value="<?php echo esc_attr( $product_id ); ?>">
		<div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
                <label for="ticket-content" class="wast-label">پاسخ خود را وارد کنید :</label>
				<?php
				if ( wast_get_option( 'wp-editor' ) ) {
					wp_editor( '', 'ticket-content', array( 'textarea_rows' => 10 ) );
				} else {
					echo '<textarea class="wast-form-control" name="ticket-content" id="ticket-content" rows="10"></textarea>';
				}
				?>
            </div>
		<?php if ( wast_get_option( 'active-upload' ) ): ?>
			<div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
				<div class="wast-custom-file">
					<input type="file" class="wast-custom-file-input" id="ticket-file" name="ticket-file">
					<label class="wast-custom-file-label" for="ticket-file">پیوست :</label>
				</div>
				<?php if ( wast_get_option( 'file-ext' ) ): ?>
					<div class="wast-text-muted">فرمت‌های مجاز:
						<bdi dir="ltr">.<?php echo str_replace( ',', ', .', wast_get_option( 'file-ext' ) ); ?></bdi>
					</div>
				<?php endif; ?>
				<?php if ( wast_get_option( 'file-max-size' ) ): ?>
					<div class="wast-text-muted">حداکثر حجم مجاز: <?php echo wast_get_option( 'file-max-size' ); ?> مگابایت</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
                <input type="checkbox" class="wast-form-check-input" id="status-closed" name="status-closed">
                <label class="wast-form-check-label" for="status-closed">بستن تیکت</label>
            </div>
        <div class="wast-btn-wrapper">
			<?php wp_nonce_field( 'wast_reply_ticket', 'wast_reply_ticket_field' ); ?>
			<input type="submit" name="submit-reply-ticket" class="wast-btn" value="ارسال پاسخ">
			<svg width="35" height="28" viewBox="0 0 35 28" fill="none" xmlns="http://www.w3.org/2000/svg">
				<g id="Group 1">
				<g id="vuesax/linear/arrow-left">
				<g id="arrow-left">
				<path id="Vector" d="M22.833 26.3333C29.1843 26.3333 34.333 20.9608 34.333 14.3333C34.333 7.70593 29.1843 2.33334 22.833 2.33334C16.4817 2.33334 11.333 7.70593 11.333 14.3333C11.333 20.9608 16.4817 26.3333 22.833 26.3333Z" fill="#FCD2C5" fill-opacity="0.2"/>
				<path id="Vector_2" d="M14.6667 25.6667C21.11 25.6667 26.3333 20.4433 26.3333 14C26.3333 7.55669 21.11 2.33334 14.6667 2.33334C8.22334 2.33334 3 7.55669 3 14C3 20.4433 8.22334 25.6667 14.6667 25.6667Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
				<path id="Vector_3" d="M18.75 14H11.75" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
				<path id="Vector_4" d="M14.083 10.5L10.583 14L14.083 17.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
				</g>
				</g>
				</g>
			</svg>
        </div>
    </form>

<?php endif;?>
</div>