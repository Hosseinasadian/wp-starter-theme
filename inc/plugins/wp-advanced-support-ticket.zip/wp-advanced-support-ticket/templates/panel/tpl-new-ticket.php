<?php wast_print_user_ticket_statistics();?>
<div class="wast-wrapper">
    <h3 class="wast-title wast-clearfix">
        <span>ارسال تیکت جدید</span>
        <a href="<?php echo remove_query_arg( array( 'action' ) ); ?>" class="alm-wast-header-button wast-float-left">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                 <path opacity="0.4" d="M12.1425 1.5H5.865C3.1275 1.5 1.5 3.1275 1.5 5.8575V12.135C1.5 14.865 3.1275 16.4925 5.8575 16.4925H12.1425C14.8725 16.5 16.5 14.8725 16.5 12.1425V5.8575C16.5 3.1275 14.8725 1.5 12.1425 1.5Z" fill="#8D8D8D"/>
                 <path d="M13.8975 8.60255L10.68 5.38505C10.4625 5.16755 10.1025 5.16755 9.885 5.38505C9.6675 5.60255 9.6675 5.96255 9.885 6.18005L12.1425 8.43755H4.5C4.1925 8.43755 3.9375 8.69255 3.9375 9.00005C3.9375 9.30755 4.1925 9.56255 4.5 9.56255H12.1425L9.885 11.82C9.6675 12.0375 9.6675 12.3975 9.885 12.615C9.9975 12.7275 10.14 12.78 10.2825 12.78C10.425 12.78 10.5675 12.7275 10.68 12.615L13.8975 9.39755C14.0025 9.29255 14.0625 9.15005 14.0625 9.00005C14.0625 8.85005 14.0025 8.70755 13.8975 8.60255Z" fill="#8D8D8D"/>
            </svg>    
            بازگشت به تیکت ها
        </a>
    </h3>
    <hr class="wast-hr">
	<?php
	if ( wast_get_option( 'help-info' ) ) {
		echo '<div class="wast-help-info">' . nl2br( esc_html( wast_get_option( 'help-info' ) ) ) . '</div>';
	} 
	?>
    <form method="post" enctype="multipart/form-data">
		<?php WAST_Flash_Message::show_message(); ?>
        <div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
            <label for="ticket-title" class="wast-label">عنوان</label>
            <input type="text" class="wast-form-control" name="ticket-title" id="ticket-title">
        </div>
        <fieldset class="alm-wast-fieldset alm-wast-fieldset-3">
            <div class="form-row alm-woocommerce-form-field">
                <label for="ticket-type" class="wast-label">دپارتمان :</label>
                <select class="wast-custom-select" name="ticket-type" id="ticket-type">
                    <option value="">لطفا انتخاب کنید.</option>
                    <?php
                    $terms = get_terms( 'ticket-type', array( 'hide_empty' => 0 ) );
                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                        foreach ( $terms as $term ) {
                            $term_list .= '<option value="' . $term->term_id . '">' . $term->name . '</option>';
                        }
                    }
                    $term_list .= '</select>';
                    echo $term_list;
                    ?>
                </select>
            </div>
            <div class="form-row alm-woocommerce-form-field">
                <label for="ticket-priority" class="wast-label">اولویت :</label>
                <select class="wast-custom-select" name="ticket-priority" id="ticket-priority">
                    <option value="low">کم</option>
                    <option value="medium" selected>متوسط</option>
                    <option value="high">زیاد</option>
                </select>
            </div>
            <div class="wast-product-title-wrapper form-row alm-woocommerce-form-field">
                <?php
                if ( wast_get_option( 'wc-support' ) ) {
                    $user_products = wast_get_customer_bought_products();
                    ?>
                    <label for="product-title" class="wast-label">محصول را انتخاب کنید:</label>
                    <select class="wast-custom-select" name="product-id" id="product-title">
                        <option value=""></option>
                        <?php
                        if ( sizeof( $user_products ) ) {
                            foreach ( $user_products as $product ) {
                                $product_exp_time = get_post_meta( $product, '_wast_product_exp_time', true );
                                if ( wast_get_option( 'expiration-time' ) == 'limilted' ) {
                                    if ( $product_exp_time ) {
                                        if ( wast_get_product_purchase_date( $product ) + ( $product_exp_time * 86400 ) > time() ) {
                                            echo '<option value="' . $product . '">' . get_the_title( $product ) . '</option>';
                                        }
                                    } else {
                                        if ( wast_get_product_purchase_date( $product ) + ( 365 * 999 * 86400 ) > time() ) {
                                            echo '<option value="' . $product . '">' . get_the_title( $product ) . '</option>';
                                        }
                                    }
                                } else {
                                    echo '<option value="' . $product . '">' . get_the_title( $product ) . '</option>';
                                }
                            }
                        }
                        ?>
                    </select>
                    <?php
                } else {
                    ?>
                    <label for="product-title" class="wast-label">محصول :</label>
                    <input type="hidden" name="product-id" id="product-id">
                    <input type="text" class="wast-form-control" name="product-title" id="product-title" autocomplete="off">
                    <img class="wast-loader" src="<?php echo WAST_IMG_URL; ?>loader.svg" alt="" width="18" height="18">
                    <div class="wast-ajax-result"></div>
                    <?php
                }
                ?>
            </div>
        </fieldset>
        <div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
            <label for="ticket-content" class="wast-label">محتوای تیکت :</label>
            <?php
            if ( wast_get_option( 'wp-editor' ) ) {
                wp_editor( '', 'ticket-content', array( 'textarea_rows' => 10 ) );
            } else {
                echo '<textarea class="wast-form-control" name="ticket-content" id="ticket-content" rows="10"></textarea>';
            }
            ?>
        </div>
		<?php if ( wast_get_option( 'active-upload' ) ): ?>
            <div class="form-row alm-woocommerce-form-field alm-woocommerce-full-form-field">
                <div class="wast-custom-file">
                    <input type="file" class="wast-custom-file-input" id="ticket-file" name="ticket-file">
                    <label class="wast-custom-file-label" for="ticket-file">پیوست :</label>
                </div>
                <?php if ( wast_get_option( 'file-ext' ) ): ?>
                    <div class="wast-text-muted">فرمت‌های مجاز:
                        <bdi dir="ltr">.<?php echo str_replace( ',', ', .', wast_get_option( 'file-ext' ) ); ?></bdi>
                    </div>
                <?php endif; ?>
                <?php if ( wast_get_option( 'file-max-size' ) ): ?>
                    <div class="wast-text-muted">حداکثر حجم مجاز: <?php echo wast_get_option( 'file-max-size' ); ?> مگابایت</div>
                <?php endif; ?>
            </div>
		<?php endif; ?>
        <div class="wast-btn-wrapper">
            <?php wp_nonce_field( 'wast_new_ticket', 'wast_new_ticket_field' ); ?>
            <input type="submit" name="submit-new-ticket" class="wast-btn" value="ارسال تیکت">
            <svg width="35" height="28" viewBox="0 0 35 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g id="Group 1">
                <g id="vuesax/linear/arrow-left">
                <g id="arrow-left">
                <path id="Vector" d="M22.833 26.3333C29.1843 26.3333 34.333 20.9608 34.333 14.3333C34.333 7.70593 29.1843 2.33334 22.833 2.33334C16.4817 2.33334 11.333 7.70593 11.333 14.3333C11.333 20.9608 16.4817 26.3333 22.833 26.3333Z" fill="#FCD2C5" fill-opacity="0.2"/>
                <path id="Vector_2" d="M14.6667 25.6667C21.11 25.6667 26.3333 20.4433 26.3333 14C26.3333 7.55669 21.11 2.33334 14.6667 2.33334C8.22334 2.33334 3 7.55669 3 14C3 20.4433 8.22334 25.6667 14.6667 25.6667Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path id="Vector_3" d="M18.75 14H11.75" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path id="Vector_4" d="M14.083 10.5L10.583 14L14.083 17.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </g>
                </g>
                </g>
            </svg>
        </div>
    </form>
</div>