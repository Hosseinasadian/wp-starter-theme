<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );
?>
<?php WAST_Flash_Message::show_message(); ?>
<form method="post">
    <table class="form-table">
        <tbody>
        <tr>
            <th scope="row">
                <label for="header-text">متن سربرگ</label>
            </th>
            <td>
                <textarea name="header-text" id="header-text" class="large-text" rows="3"><?php echo esc_textarea( wast_get_option( 'header-text' ) ); ?></textarea>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="footer-text">متن پابرگ</label>
            </th>
            <td>
                <textarea name="footer-text" id="footer-text" class="large-text" rows="3"><?php echo esc_textarea( wast_get_option( 'footer-text' ) ); ?></textarea>
            </td>
        </tr>
        </tbody>
    </table>
	<?php
	wp_nonce_field( 'wast_save_template', 'wast_template_nonce' );

	submit_button( 'ذخیره تغییرات', 'primary', 'wast-save-template-options', true );
	?>
</form>
