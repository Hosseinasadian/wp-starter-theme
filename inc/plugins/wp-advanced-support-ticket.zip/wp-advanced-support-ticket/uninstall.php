<?php
/**
 * If uninstall.php is not called by WordPress, die
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit( 'دسترسی غیر مجاز!' );
}

/**
 * Delete plugin data from database on plugin uninstall
 */
//delete_option( 'wast_version' );
//delete_option( 'wast_options' );