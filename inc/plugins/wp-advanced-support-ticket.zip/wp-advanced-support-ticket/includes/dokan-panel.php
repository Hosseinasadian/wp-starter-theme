<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );

add_filter( 'dokan_query_var_filter', 'wast_dokan_load_document_menu' );
function wast_dokan_load_document_menu( $query_vars ) {
	$query_vars['tickets'] = 'tickets';

	return $query_vars;
}

add_filter( 'dokan_get_dashboard_nav', 'wast_dokan_add_tickets_menu' );
function wast_dokan_add_tickets_menu( $urls ) {
	$urls['tickets'] = array(
		'title' => 'تیکت پشتیبانی',
		'icon'  => '<i class="fa fa-ticket" aria-hidden="true"></i>',
		'url'   => dokan_get_navigation_url( 'tickets' ),
		'pos'   => 51
	);

	return $urls;
}

add_action( 'dokan_load_custom_template', 'wast_dokan_load_template' );
function wast_dokan_load_template( $query_vars ) {
	if ( isset( $query_vars['tickets'] ) ) {
		include( WAST_TPL_PATH . 'dokan-panel/tpl-tickets.php' );
		exit();
	}
}