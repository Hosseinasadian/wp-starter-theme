<?php
/**
 * Exit if accessed directly
 */
defined( 'ABSPATH' ) || exit( 'دسترسی غیر مجاز!' );

add_shortcode( 'wast-ticket-panel', 'wast_ticket_callback' );
function wast_ticket_callback( $atts, $content = "" ) {
	wast_woo_tickets_endpoint_content();
}