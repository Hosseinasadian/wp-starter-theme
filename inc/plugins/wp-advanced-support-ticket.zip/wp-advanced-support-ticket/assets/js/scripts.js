jQuery(document).ready(function ($) {

    /**
     * Ajax search product request
     * @type {*|jQuery|HTMLElement}
     */
    var _nonce = $('meta[name="_wast_nonce"]').attr('content');
    var ajaxResult = $('.wast-product-title-wrapper .wast-ajax-result');
    var searchInput = $('.wast-product-title-wrapper input[type=text]');
    var loader = $('.wast-product-title-wrapper .wast-loader');
    var $continue = true;
    searchInput.on('input', function () {
        var $this = $(this);
        var searchTerm = $this.val();
        if (searchTerm.length < 2) {
            $continue = false;
            ajaxResult.fadeOut();
            loader.fadeOut();
            return false;
        } else {
            $continue = true;
        }

        loader.fadeIn();

        $.ajax({
            url: wast_data.ajax_url,
            type: 'post',
            dataType: 'json',
            timeout: 20000,
            data: {
                action: 'wast_search',
                searchTerm: searchTerm,
                _wast_nonce: _nonce
            },
            success: function (response) {
                if (response._result !== '' && $continue) {
                    ajaxResult.html(response._result).fadeIn();
                } else {
                    ajaxResult.empty().hide();
                }
                loader.fadeOut();
            },
            error: function () {
                ajaxResult.fadeOut();
                loader.fadeOut();
            }
        });
    });

    /**
     * Show product title in input
     */
    $(document).on('click', '.wast-ajax-result li', function (e) {
        e.stopPropagation();
        var $this = $(this);
        var productID = parseInt($this.data('id'));
        var productTitle = $this.text();

        $('#product-id').val(productID);
        searchInput.val(productTitle);
        ajaxResult.fadeOut();
    });
    $('body').click(function () {
        setTimeout(function () {
            ajaxResult.empty().hide();
            loader.fadeOut();
        }, 500);
    });

    /**
     * Show file name when file select form input[type="file"]
     */
    $('#ticket-file').change(function () {
        var $this = $(this);
        var file = $this[0].files[0];
        $this.next('label').text(file['name']);
    });

    $(document).on('click','.alm-wast-filter-item .alm-wast-filter-item-label',function(){
        let $sortBox = $(this).closest('.alm-wast-filter-item');
        if($sortBox)
            $sortBox.toggleClass('alm-wast-filter-open-sort');
    });


    $('.alm-wast-filter-item .wast-custom-select').each(function() {
		let $select = $(this);
		let $sortForm = $select.closest('form');
		let $sortBox = $select.closest('.alm-wast-filter-item');


		// Create the ul element
		let $ul = $('<ul>', {
		  'class': 'alm-wast-filter-list-items'
		});

		let initialValue = $select.val();

		// Iterate through each option in the select
		$select.find('option').each(function() {
		  let $option = $(this);
		  let $li = $('<li>', {
			'data-sort': $option.val(),
			'text': $option.text()
		  });

		  if ($option.val() === initialValue) {
			$li.addClass('alm-wast-filter-current-sort');
		  }

		  $ul.append($li);
		});

		// Append the new ul after the select
		$sortBox.append($ul);

		$ul.on('click', 'li', function() {
			let selectedValue = $(this).data('sort');
			$select.val(selectedValue).trigger('change');

			// Optional: Add active class to clicked li and remove from others
			$ul.find('li').removeClass('alm-wast-filter-current-sort');
			$(this).addClass('alm-wast-filter-current-sort');

			$sortBox.removeClass('alm-wast-filter-open-sort');

			$sortForm.submit();
		  });
	  })

    
});