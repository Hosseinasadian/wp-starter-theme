jQuery(document).ready(function ($) {

    $('.select-uploader').click(function (e) {
        e.preventDefault();
        var $this = $(this);
        var $target = $this.data('target');
        var $target_type = $this.data('target-type');
        var image = wp.media({
            title: 'انتخاب تصویر',
            multiple: false,
            button: {
                text: 'قرار دادن'
            }
        }).open().on('select', function (e) {
            var uploaded_image = image.state().get('selection').first();
            var image_url = uploaded_image.toJSON().url;
            switch (true) {
                case $target_type === 'image' :
                    $('#' + $target).attr('src', image_url);
                    $('#' + $target + '_input').val(image_url);
                    break;
            }
        });
    });

    $('.remove-uploader').click(function (e) {
        e.preventDefault();
        var $this = $(this);
        var target = $this.data('target');
        $('#' + target).attr('src', '');
        $('#' + target + '_input').attr('value', '');
    });

    $('#wast-pre-answer').click(function (e) {
        e.preventDefault();
        $('.wast-pre-answer-wrapper').slideToggle();
    });
    $('.wast-pre-answer-wrapper .dashicons-arrow-down-alt2').click(function (e) {
        e.preventDefault();
        $(this).parentsUntil('ul').find('div.content').slideToggle();
    });
    $('.wast-pre-answer-wrapper .dashicons-editor-textcolor').click(function (e) {
        e.preventDefault();
        var $this = $(this);
        var editor_id = $this.data('editor-id');
        var $content = $this.parentsUntil('ul').find('div.content').html();
        if (tinyMCE && tinyMCE.activeEditor) {
            tinyMCE.get(editor_id).selection.setContent($content);
        }
        $(editor_id).val($content);
    });
});