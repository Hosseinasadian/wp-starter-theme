<?php
/**
 * Plugin Name:     Alma Core
 * Plugin URI:      https://test.pezeshk-yar.ir/
 * Description:     Core Of Alma Theme
 * Author:          RTL-Theme
 * Author URI:      https://www.rtl-theme.com/author/hosseinasadian442
 * Text Domain:     alma-core
 * Domain Path:     /alma
 * Version:         1.1.3
 *
 * @package         Alma-Core
 */

 require_once 'core.php';

