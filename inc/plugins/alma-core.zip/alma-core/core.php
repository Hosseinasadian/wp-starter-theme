<?php

use libphonenumber\PhoneNumber;

 define('ALMA_CORE_ROOT', plugin_dir_path(__FILE__));
 define('ALMA_CORE_URL', plugin_dir_url(__FILE__));
 define('ALMA_CORE_VERSION', '1.1.3');


 /* License */
 add_action('admin_init', 'alma00457301_restrict_admin_access');
function alma00457301_restrict_admin_access()
{
    // Check if the user is not an administrator and the license is invalid
    global $pagenow;


    if($pagenow == 'admin.php'){
        $page_slug = sanitize_text_field(wp_unslash($_GET['page']));
        if($page_slug){
            $page_slug = strtolower($page_slug);
        }

        $restricted_pages = array('alma_options_options');

        if (in_array($page_slug, $restricted_pages)) {
            wp_redirect(admin_url());
            exit;
        }
    }

    if($pagenow == 'post.php' || $pagenow == 'post-new.php'){
        wp_redirect(admin_url());
        exit;
    }

    // List of allowed admin pages (adjust as needed)
    $allowed_pages = array('index.php', 'edit.php');

    // Check if the current page is not in the allowed list
    if (in_array($pagenow, $allowed_pages)) {
        // Check if it's a custom post type page
        global $typenow;
        $restricted_post_types = array('alm_notification','page'); // Add your custom post types here

        if (in_array($typenow, $restricted_post_types)) {
            wp_redirect(admin_url()); // Redirect to dashboard
            exit;
        }
    }
}

add_action( 'admin_init', 'alma3658004_remove_menu_items' );
function alma3658004_remove_menu_items() {
    remove_menu_page( 'edit.php?post_type=page' );
    remove_menu_page( 'edit.php?post_type=alm_notification' );
    remove_menu_page( 'alma_options_options');
}

// $almaRtlLicenseClassName  = 'RTL_License_1e641d7bc0b4e302';
// $almaRtlLicenseFilePath   = trailingslashit(get_template_directory()) . $almaRtlLicenseClassName . '.php';
// $almaRtlLicenseFileHash   = @sha1_file($almaRtlLicenseFilePath);

// if ( $almaRtlLicenseFileHash === 'c8a4b1750a2f790fdedd1b59a4e7a24ee258e9dc' && file_exists($almaRtlLicenseFilePath) ) {
// 	require_once $almaRtlLicenseFilePath;

// 	if ( class_exists($almaRtlLicenseClassName) && method_exists($almaRtlLicenseClassName, 'isActive') ) {
// 		$almarRtlLicenseClass = new $almaRtlLicenseClassName();

// 		if ( $almarRtlLicenseClass->{'isActive'}() === true ) {

			remove_action('admin_init', 'alma00457301_restrict_admin_access');
			remove_action( 'admin_init', 'alma3658004_remove_menu_items' );

			/* Newsletter */
			function alm_register_subscribers_menu_page()
			{
				add_menu_page(
					__('اعضای خبرنامه', 'alma-core'),
					__('اعضای خبرنامه', 'alma-core'),
					'manage_options',
					'alm_newsletter_subscribers',
					'alm_newsletter_subscribers_callback',
					'',
					6
				);
			}

			add_action('admin_menu', 'alm_register_subscribers_menu_page');

			require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/alm_subscribers_list_table.php';

			function alm_newsletter_subscribers_callback()
			{
				// Create an instance of our package class.
				$subscriberListTable = new Alm_Subscribers_List_Table();

				// Fetch, prepare, sort, and filter our data.
				$subscriberListTable->prepare_items();
				?>
				<div class="wrap">
					<h1 class="wp-heading-inline"><?php _e('اعضای خبرنامه', 'alma-core'); ?></h1>
					<form method="post">
						<?php
						$subscriberListTable->search_box(__('جستجوی اعضای خبرنامه', 'alma-core'), 'search_id');
						$subscriberListTable->display();
						?>
					</form>
				</div>
				<?php
			}
			/* Newsletter */

			/* SMS Settings */
			add_action('admin_menu', 'alm_add_sms_settings_page');

			function alm_add_sms_settings_page() {
				add_options_page(
					esc_html__('تنظیمات پیامک','alma-core'),
					esc_html__('تنظیمات پیامک','alma-core'),
					'manage_options',
					'alm-sms-settings',
					'alm_render_sms_settings_page'
				);
			}

			function alm_render_sms_settings_page() {
				?>
				<div class="wrap">
					<h1>SMS Gateway Settings</h1>
					<form method="post" action="options.php">
						<?php
						settings_fields('alm_sms_settings');
						do_settings_sections('alm_sms_settings');
						?>
						<h2><?php esc_html_e('فراز اس ام اس','alma-core')?></h2>
						<table class="form-table">
							<tr valign="top">
								<th scope="row"><?php esc_html_e('نام کاربری','alma-core')?></th>
								<td><input type="text" name="farazsms_username" value="<?php echo esc_attr(get_option('farazsms_username')); ?>" /></td>
							</tr>
							<tr valign="top">
								<th scope="row"><?php esc_html_e('رمز عبور','alma-core')?></th>
								<td><input type="password" name="farazsms_password" value="<?php echo esc_attr(get_option('farazsms_password')); ?>" /></td>
							</tr>
							<tr valign="top">
								<th scope="row"><?php esc_html_e('سرشماره ارسال پیامک','alma-core')?></th>
								<td><input type="text" name="farazsms_sender_number" value="<?php echo esc_attr(get_option('farazsms_sender_number')); ?>" /></td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php esc_html_e('کد پترن otp','alma-core')?></th>
								<td><input type="text" name="farazsms_otp_pattern_code" value="<?php echo esc_attr(get_option('farazsms_otp_pattern_code')); ?>" /></td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php esc_html_e('فعال','alma-core')?></th>
								<td><input type="checkbox" name="farazsms_active" value="1" <?php checked(1, get_option('farazsms_active'), true); ?> /></td>
							</tr>
						</table>

						<h2><?php esc_html_e('ملی پیامک','alma-core')?></h2>
						<table class="form-table">
							<tr valign="top">
								<th scope="row"><?php esc_html_e('نام کاربری','alma-core')?></th>
								<td><input type="text" name="melipayamak_username" value="<?php echo esc_attr(get_option('melipayamak_username')); ?>" /></td>
							</tr>
							<tr valign="top">
								<th scope="row"><?php esc_html_e('رمز عبور','alma-core')?></th>
								<td><input type="password" name="melipayamak_password" value="<?php echo esc_attr(get_option('melipayamak_password')); ?>" /></td>
							</tr>
							<tr valign="top">
								<th scope="row"><?php esc_html_e('سرشماره ارسال پیامک','alma-core')?></th>
								<td><input type="text" name="melipayamak_sender_number" value="<?php echo esc_attr(get_option('melipayamak_sender_number')); ?>" /></td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php esc_html_e('کد پترن otp','alma-core')?></th>
								<td><input type="text" name="melipayamak_otp_pattern_code" value="<?php echo esc_attr(get_option('melipayamak_otp_pattern_code')); ?>" /></td>
							</tr>

							<tr valign="top">
								<th scope="row"><?php esc_html_e('فعال','alma-core')?></th>
								<td><input type="checkbox" name="melipayamak_active" value="1" <?php checked(1, get_option('melipayamak_active'), true); ?> /></td>
							</tr>
						</table>

						<?php submit_button(); ?>
					</form>
				</div>
				<?php
			}

			add_action('admin_init', 'alm_register_sms_settings');

			function alm_register_sms_settings() {
				register_setting('alm_sms_settings', 'farazsms_username');
				register_setting('alm_sms_settings', 'farazsms_password');
				register_setting('alm_sms_settings', 'farazsms_sender_number');
				register_setting('alm_sms_settings', 'farazsms_otp_pattern_code');
				register_setting('alm_sms_settings', 'farazsms_active');


				register_setting('alm_sms_settings', 'melipayamak_username');
				register_setting('alm_sms_settings', 'melipayamak_password');
				register_setting('alm_sms_settings', 'melipayamak_sender_number');
				register_setting('alm_sms_settings', 'melipayamak_otp_pattern_code');
				register_setting('alm_sms_settings', 'melipayamak_active');
			}

			/* SMS Settings */
// 		}
// 	}
// }
 /* License */


require_once trailingslashit(ALMA_CORE_ROOT) . 'elementor/register.php';

function alm_core_load_textdomain()
{
    load_plugin_textdomain('alma-core', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('init', 'alm_core_load_textdomain');

function alm_core_plugins_loaded()
{
    require_once ALMA_CORE_ROOT . '/inc/options/index.php';
}
add_action('plugins_loaded', 'alm_core_plugins_loaded');

function register_alm_core_scripts(){
	// alm-mobile-menu
	wp_enqueue_style(
        'alm-mobile-menu',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-mobile-menu/main.css'
    );
	wp_enqueue_script(
        'alm-mobile-menu',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-mobile-menu/main.js',
        array('jquery'),
        null,
        true
    );
	// alm-advanced-search
	wp_register_style(
        'alm-advanced-search',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-advanced-search/main.css'
    );
	wp_register_script(
        'alm-advanced-search',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-advanced-search/main.js',
        array('jquery'),
        null,
        true
    );
	wp_localize_script('alm-advanced-search','alm_advanced_search',[
		'ajaxurl'=>admin_url('admin-ajax.php'),
		'translations'=>[
			'failed'=>esc_html__('دوباره تلاش کنید...','alma-core')
		]
	]);
	// alm-custom-image
	wp_register_style(
		'alm-custom-image',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-custom-image/main.css'
	);
	// alm-categories-slider
	wp_register_style(
		'alm-categories-slider',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-categories-slider/main.css'
	);

	// alm-products-slider
	wp_register_style(
		'alm-products-slider',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-products-slider/main.css'
	);

	// alm-post-card
	wp_register_style(
		'alm-post-card',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-post-card/main.css'
	);


	// alm-comments-slider
	wp_register_style(
		'alm-comments-slider',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-comments-slider/main.css'
	);
	wp_register_script(
        'alm-comments-slider',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-comments-slider/main.js',
        array('jquery'),
        null,
        true
    );
	wp_localize_script('alm-comments-slider','alm_comments_slider_object',[
		'translations'=>[
			'show_all'=>esc_html__('مشاهده همه','alma-core'),
			'show_less'=>esc_html__('مشاهده کمتر','alma-core')
		]
	]);

	// alm-otp-button
	wp_register_style(
		'alm-otp-button',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-otp-button/main.css'
	);

	// alm-minicart
	wp_enqueue_style(
		'alm-minicart',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-minicart/main.css'
	);

	wp_enqueue_script(
        'alm-minicart',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-minicart/main.js',
        array('init-jquery'),
        null,
        true
    );
    wp_localize_script('alm-minicart', 'alm_mini_crt_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('alm-mini-cart-nonce')
    ]);

	// alm-product-brands
	wp_register_style(
		'alm-product-brands',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-product-brands/main.css'
	);

	// alm-custom-products-slider
	wp_register_style(
		'alm-custom-products-slider',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-custom-products-slider/main.css'
	);

	// alm-newsletter
	wp_register_script(
        'alm-newsletter',
        trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-newsletter/main.js',
        array('init-jquery'),
        null,
        true
    );
    wp_localize_script('alm-newsletter', 'alm_newsletter_obj', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'security' => wp_create_nonce('alm-ajax-nonce')
    ]);

	// alm-custom-slide
	wp_register_style(
		'alm-custom-slide',
		trailingslashit(ALMA_CORE_URL) . 'elementor/assets/alm-custom-slide/main.css'
	);
}

add_action('wp_enqueue_scripts', 'register_alm_core_scripts');

add_action('wp_ajax_alm_ajax_search', 'alm_ajax_search');
add_action('wp_ajax_nopriv_alm_ajax_search', 'alm_ajax_search');

function alm_ajax_search(){
	$search = sanitize_text_field($_POST['search']);
    $post_types = array('any');

	if(isset($_POST['post_type'])){
		if(is_array(($_POST['post_type']))){
			$post_types = $_POST['post_type'];
		}elseif(is_string($_POST['post_type'])){
			$post_types = [
				$_POST['post_type']
			];
		}
	}

    $args = array(
        's' => $search,
        'post_type' => $post_types,
        'posts_per_page' => 10
    );

	$query = new WP_Query($args);
	$html = '';

	if ($query->have_posts()) {
		$html .= '<div class="alm-search-result-items">';
        while ($query->have_posts()) {
            $query->the_post();
			$html .= '<div class="alm-search-result-item">';
			$html .= '<a href="' . get_the_permalink() . '"><p>' . get_the_title() . '</p></a>';
			$html .= '</div>';
		}
		$html .= '</div>';
	}else{
		$html .= '<div class="alm-search-result-empty">' . __('متاسفانه موردی یافت نشد.','alma-core') . '</div>';
	}

	echo $html;
	wp_die();
}

function alm_core_register_rest_route()
{
    register_rest_route('alm/v1', '/terms/', array(
        'methods' => 'POST',
        'callback' => 'alm_get_terms',
        'permission_callback' => '__return_true', // Adjust this for security, more on this below
    ));
	register_rest_route('alm/v1', '/posts/', array(
        'methods' => 'POST',
        'callback' => 'alm_get_posts',
        'permission_callback' => '__return_true', // Adjust this for security, more on this below
    ));
}

add_action('rest_api_init', 'alm_core_register_rest_route');

function alm_get_terms(WP_REST_Request $request){
	if($request->has_param('id')){
		$include = $request->get_param('id');
		$term_args = array(
			'include'               => $include,
			'hide_empty'             => false,
			'fields'                 => 'all',
		);
		$query = new WP_Term_Query( $term_args );
		return new WP_REST_Response([
			'terms' => $query->terms,
		], 200);

	}else{
		$search = $request->get_param('search');
		$page = $request->get_param('page') ? intval($request->get_param('page')) : 1;
        $per_page = 10; // Adjust this number as needed

        $term_args = array(
            'hide_empty' => false,
            'fields'     => 'all',
            'number'     => $per_page,
            'offset'     => ($page - 1) * $per_page,
            'search'     => $search,
        );

		if($request->has_param('taxonomy')){
			$taxonomy = $request->get_param('taxonomy');
			if(is_array($taxonomy) && count($taxonomy)>0){
				$term_args['taxonomy'] = $request->get_param('taxonomy');
			}
		}

		$query = new WP_Term_Query( $term_args );
		$terms = $query->terms;

		$formatted_terms = array_map(function($term) {
			return [
				'id' => $term->term_id,
				'text' => $term->name
			];
		}, $terms);

		$total_query = new WP_Term_Query(array_merge($term_args, ['fields' => 'count']));
        $total_terms = $total_query->get_terms();

		return new WP_REST_Response([
			'results' => array_values($formatted_terms),
			'pagination' => [
                'more' => ($page * $per_page) < $total_terms
            ]
		], 200);
	}


}

function alm_get_posts(WP_REST_Request $request){
    if($request->has_param('id')){
        $include = $request->get_param('id');
        $post_args = array(
            'post_type'      => 'any', // Change 'any' to the specific post type if needed
            'post__in'       => $include,
            'posts_per_page' => -1,
        );
        $query = new WP_Query( $post_args );
        return new WP_REST_Response([
            'posts' => $query->posts,
        ], 200);

    } else {
        $search = $request->get_param('search');
        $page = $request->get_param('page') ? intval($request->get_param('page')) : 1;
        $per_page = 10; // Adjust this number as needed

        $post_args = array(
            'post_type'      => 'any', // Change 'any' to the specific post type if needed
            'posts_per_page' => $per_page,
            'paged'          => $page,
            's'              => $search, // Search query
        );

        if($request->has_param('post_type')){
            $post_type = $request->get_param('post_type');
            if(is_array($post_type) && count($post_type) > 0){
                $post_args['post_type'] = $post_type;
            }
        }

        $query = new WP_Query( $post_args );
        $posts = $query->posts;

        $formatted_posts = array_map(function($post) {
            return [
                'id'    => $post->ID,
                'text' => $post->post_title
            ];
        }, $posts);

        $total_posts = $query->found_posts;

        return new WP_REST_Response([
            'results' => array_values($formatted_posts),
            'pagination' => [
                'more' => ($page * $per_page) < $total_posts
			],
        ], 200);
    }
}

function alm_elementor_template()
{
    $elementor_templates = get_posts(array(
        'post_type' => 'elementor_library',
        'posts_per_page' => -1,
        'status' => 'publish'
    ));

    $elementor_templates_array = array();
    if (!empty($elementor_templates)) {
        foreach ($elementor_templates as $elementor_template) {
            $elementor_templates_array[$elementor_template->ID] = $elementor_template->post_title;
        }
    }
    return $elementor_templates_array;
}

function alm_custom_fonts()
{
    $custom_fonts = array();

    $posts = get_posts(array(
        'post_type' => 'elementor_font',
        'numberposts' => -1,
    ));

    foreach ($posts as $post) {
        $font_face = get_post_meta($post->ID, 'elementor_font_face', true);
        $font_files = get_post_meta($post->ID, 'elementor_font_files', true);

        if ($font_face && $font_files) {
            $font_name = $post->post_title;
            $custom_fonts[$font_name] = array(
                'family' => $font_name,
                'face' => $font_face,
                'files' => $font_files,
                'variants' => array(),
            );

            // Extract variants from font files
            foreach ($font_files as $file) {
                $weight = $file['font_weight'];
                $style = $file['font_style'];
                $variant = $weight . ($style !== 'normal' ? $style : '');
                $custom_fonts[$font_name]['variants'][] = $variant;
            }
        }
    }

    return $custom_fonts;
}

function alm_attachment_sizes() {
	global $_wp_additional_image_sizes;
	$sizes = array();
	$rSizes = array();
	foreach (get_intermediate_image_sizes() as $s) {
		$sizes[$s] = array(0, 0);
		if (isset($_wp_additional_image_sizes) && isset($_wp_additional_image_sizes[$s])){
			$sizes[$s] = array($_wp_additional_image_sizes[$s]['width'], $_wp_additional_image_sizes[$s]['height'],);
		}else{
			$sizes[$s][0] = get_option($s . '_size_w');
			$sizes[$s][1] = get_option($s . '_size_h');
		}
	}
	foreach ($sizes as $size => $atts) {
		$size = str_replace('_', ' ', $size);
		$rSizes[$size] = ucwords($size) . ' ' . implode('x', $atts);
	}
	$rSizes['full'] = 'Full Size';
	return $rSizes;
}

/* wc_modifications */
function alm_wc_discount_percentage(WC_Product $product)
{
    $percentage = '';

    if ($product->is_on_sale()) {

        if ($product->is_type('variable')) {
            $percentages = array();

            // Get all variation prices
            $prices = $product->get_variation_prices();

            // Loop through variation prices
            foreach ($prices['price'] as $key => $price) {
                // Only on sale variations
                if ($prices['regular_price'][$key] !== $price) {
                    // Calculate and set in the array the percentage for each variation on sale
                    $percentages[] = round(100 - (floatval($prices['sale_price'][$key]) / floatval($prices['regular_price'][$key]) * 100));
                }
            }
            // We keep the highest value
            count($percentages) > 0 && $percentage = max($percentages) . '%';

        } elseif ($product->is_type('grouped')) {
            $percentages = array();

            // Get all variation prices
            $children_ids = $product->get_children();

            // Loop through variation prices
            foreach ($children_ids as $child_id) {
                $child_product = wc_get_product($child_id);

                $discount = alm_wc_discount_percentage($child_product);
                if ($discount) {
                    $percentages[] = trim($discount, '%');
                }

                if (count($percentages) > 0) {
                    $percentage =  max($percentages) . '%';
                }
            }
            // We keep the highest value


        } else {
            $regular_price = $product->get_regular_price();
            $sale_price = $product->get_sale_price();

            $percentage = round(100 - (floatval($sale_price) / floatval($regular_price) * 100)) . '%';
        }
    }
    return $percentage;
}

function alm_wc_variation_price_format(WC_Product $product)
{

	$sale_prices = array($product->get_variation_price('min', true), $product->get_variation_price('max', true));
    $sale_price = $sale_prices[0];

    $regular_prices = array($product->get_variation_regular_price('min', true), $product->get_variation_regular_price('max', true));
    $price = $regular_prices[1];


	$price_range_array=[];
	if($sale_prices[0] !== false){
		$price_range_array[] = custom_wc_price_without_symbol($sale_prices[0]);
	}
	if($sale_prices[1] !== false){
		$price_range_array[] = custom_wc_price_without_symbol($sale_prices[1]);
	}

    return [
        'price' => custom_wc_price_without_symbol($price),
        'sale_price' => custom_wc_price_without_symbol($sale_price),
		'price_range'=>implode(' - ',array_unique($price_range_array)),
        'is_on_sale' => $price !== false && $sale_price !== false && $price !== $sale_price,
    ];
}

function alm_wc_show_range_price($product)
{
    return alm_get_option('variant_range_price');
}

function alm_wc_price_html(WC_Product $product)
{
	$currency = get_woocommerce_currency_symbol();

    $discount = alm_wc_discount_percentage($product);
    $show_range = alm_wc_show_range_price($product);

	$price_html = '';


    if ($product->is_type('variable')) {
        $variable_price = alm_wc_variation_price_format($product);
    }


    if ($discount) {
        if ($product->is_type('simple')) {
            $price_html .=  '<span class="regular-price">' . custom_wc_price_without_symbol($product->get_regular_price()) . '</span>';
        } elseif ($product->is_type('variable') && !$show_range) {
            $price_html .=  '<span class="regular-price">' . custom_wc_price_without_symbol($variable_price['price']) . '</span>';
        }
    }

    if ($product->is_type('variable')) {
        if ($show_range) {
			$price_range = $variable_price['price_range'];
			if($price_range === '0' && $zero_price_text = alm_get_option('zero_price_text')){
				$price_range = $zero_price_text;
			}elseif(empty($price_range) && $price_range !== '0' && $no_price_text = alm_get_option('no_price_text')){
				$price_range = $no_price_text;
			}
			if(!empty($price_range) || $price_range === '0'){
				$price_html .= '<span class="sale-price price-range">' . $price_range . '</span>';
			}
        } else {
			$variable_sale_price = $variable_price['sale_price'];

			$variable_sale_price_text = (string)$variable_sale_price;
			if($variable_sale_price === '0' && $zero_price_text = alm_get_option('zero_price_text')){
				$variable_sale_price_text = $zero_price_text;
			}elseif(empty($variable_sale_price) && $variable_sale_price !== '0' && $no_price_text = alm_get_option('no_price_text')){
				$variable_sale_price_text = $no_price_text;
			}

			if(!empty($variable_sale_price_text) || $variable_sale_price_text === '0'){
				$price_html .= '<span class="sale-price">' . custom_wc_price_without_symbol($variable_sale_price_text) . '</span>';
			}
        }
    } elseif ($product->is_type('simple')) {
		$product_price = $product->get_price();
		$display_price = '';
		if($product_price === '0' && $zero_price_text = alm_get_option('zero_price_text')){
			$display_price = $zero_price_text;
		}elseif(empty($product_price) && $product_price !== '0'){
			$display_price = alm_get_option('no_price_text');
		}else{
			$display_price = custom_wc_price_without_symbol($product->get_price());
		}
		if($display_price || $display_price === '0'){
			$price_html .= '<span class="sale-price">' . custom_wc_price_without_symbol($display_price) . '</span>';
		}
    } elseif ($product->is_type('grouped')) {

    }

	return $price_html;
}

function alm_wc_enable_show_currency($product){
	if($product->is_type('simple')){
		$price = $product->get_price();
		if(empty($price) && $price !== '0'){
			return false;
		}
		if($price === '0'){
			$zero_price_text = alm_get_option('zero_price_text');
			$regular_price = $product->get_regular_price();
			if(!empty($zero_price_text) && (!$product->is_on_sale() || $regular_price === '0')){
				return false;
			}
		}
	}elseif($product->is_type('variable')){
		$show_range = alm_wc_show_range_price($product);
		$variable_price = alm_wc_variation_price_format($product);
		if($show_range){
			$price_range = $variable_price['price_range'];
			if($price_range === '0' && !empty(alm_get_option('zero_price_text'))){
				return false;
			}
			if(empty($price_range) && $price_range !== '0'){
				return false;
			}
		}else{
			$variable_sale_price = $variable_price['sale_price'];
			if(empty($variable_sale_price) && $variable_sale_price !== '0'){
				return false;
			}
			if($variable_sale_price === '0'){
				$zero_price_text = alm_get_option('zero_price_text');
				if(!empty($zero_price_text) && (!$variable_price['is_on_sale'] || $variable_price['price'] === '0')){
					return false;
				}
			}
		}
	}
	return true;
}

add_filter('woocommerce_get_price_html', 'alm_wc_woocommerce_get_price_html_callback', 100, 2);
function alm_wc_woocommerce_get_price_html_callback( $price, $product ){
	$product_price = $product->get_price();
	if ('0' === $product_price && !$product->is_on_sale() ) {
		$price = alm_get_option('zero_price_text');
	}elseif(empty($product_price) && '0' !== $product_price){
		$price = alm_get_option('no_price_text');
	}
	return $price;
}

function custom_wc_price_without_symbol($price) {
	if(!is_numeric($price)){
		return $price;
	}
	return number_format( $price, wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator());
}

function alm_wc_get_total_sales($product_id){
	$total_sales = get_post_meta( $product_id, 'total_sales', true );
	if($total_sales>0){
		$total_sales = "+" . $total_sales;
		return $total_sales;
	}
	return "-";
}
function alm_wc_product_rate_percentage($product_id = null){
	if(is_null($product_id)){
		global $product;
	}else{
		$product = wc_get_product( $product_id );
	}
	$rating  = $product->get_average_rating();
	$percentage = round(100 * $rating / 5);
	return $percentage >0 ?"%$percentage":"-";
}
function alm_wc_product_stock_quantity($product_id = null){
	if(is_null($product_id)){
		global $product;
	}else{
		$product = wc_get_product( $product_id );
	}

	$output = '';

	if($product->get_manage_stock()){
		if ( $product->is_in_stock() ) {
			$stock_quantity = $product->get_stock_quantity();
			if($stock_quantity>0){
				$output = "+" . $stock_quantity;
			}else{
				$output = '-';
			}
		}
	}else{
		if ( $product->is_in_stock() ) {
			$output = "+" . alm_get_option('disabled_mange_stock_quantity');
		}else{
			$output = '-';
		}
	}

	return $output;
}

function alm_get_mini_cart_content()
{
	if (!WC()->cart->is_empty()) {
		?>
		<form method="post">
			<?php
			foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
				$_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
				$product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);

				if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key)) {

					$product_name = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
					$thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
					$product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
					$product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);

					$regular_price = $_product->get_regular_price();
					$price = $_product->get_price();

					?>
					<div class="alm-woocommerce-mini-cart-item">

						<div class="alm-product-thumbnail-title">
							<div class="alm-product-thumbnail">
								<?php if (empty($product_permalink)) : ?>
									<?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php else : ?>
									<a href="<?php echo esc_url($product_permalink); ?>">
										<?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</a>
								<?php endif; ?>
							</div>

							<div class="alm-product-title">
								<?php if (empty($product_permalink)) : ?>
									<?php echo wp_kses_post($product_name); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php else : ?>
									<a href="<?php echo esc_url($product_permalink); ?>">
										<?php echo wp_kses_post($product_name); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</a>
								<?php endif; ?>
							</div>

							<?php

							echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								'woocommerce_cart_item_remove_link',
								sprintf(
									'<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
  <path d="M3.18066 6.7384H5.18066M5.18066 6.7384H21.1807M5.18066 6.7384V20.7384C5.18066 21.2688 5.39138 21.7775 5.76645 22.1526C6.14152 22.5277 6.65023 22.7384 7.18066 22.7384H17.1807C17.7111 22.7384 18.2198 22.5277 18.5949 22.1526C18.9699 21.7775 19.1807 21.2688 19.1807 20.7384V6.7384H5.18066ZM8.18066 6.7384V4.7384C8.18066 4.20797 8.39138 3.69926 8.76645 3.32419C9.14152 2.94912 9.65023 2.7384 10.1807 2.7384H14.1807C14.7111 2.7384 15.2198 2.94912 15.5949 3.32419C15.9699 3.69926 16.1807 4.20797 16.1807 4.7384V6.7384M10.1807 11.7384V17.7384M14.1807 11.7384V17.7384" stroke="#D4D4D4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg></a>',
									esc_url(wc_get_cart_remove_url($cart_item_key)),
									/* translators: %s is the product name */
									esc_attr(sprintf(__('Remove %s from cart', 'woocommerce'), wp_strip_all_tags($product_name))),
									esc_attr($product_id),
									esc_attr($cart_item_key),
									esc_attr($_product->get_sku())
								),
								$cart_item_key
							);
							?>
						</div>


						<?php
						if ($_product->is_sold_individually()) {
							$min_quantity = 1;
							$max_quantity = 1;
						} else {
							$min_quantity = 0;
							$max_quantity = $_product->get_max_purchase_quantity();
						}

						$product_quantity = woocommerce_quantity_input(
							array(
								'input_name' => "cart[{$cart_item_key}][qty]",
								'input_value' => $cart_item['quantity'],
								'max_value' => $max_quantity,
								'min_value' => $min_quantity,
								'product_name' => $product_name,
							),
							$_product,
							false
						);

						?>
						<div class="alm-product-price-and-quantity">
							<?php
							echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); // PHPCS: XSS ok.
							?>

							<div class="alm-product-price">
								<?php if ($price < $regular_price && $regular_price > 0): ?>
									<div class="custom-price-row">
										<span class="regular-price"><?php echo $_product->get_regular_price(); ?></span>
										<span class="alm-product-discount">% <?php echo round(100 * ($regular_price - $price) / $regular_price) ?></span>
									</div>
								<?php endif; ?>
								<div class="sale-price-row">
									<span class="sale-price"><?php echo wc_price($price) ?></span>
								</div>
							</div>

						</div>

					</div>
					<?php
				}
			}
			?>
			<div class="alm-minicart-total">
				<div class="alm-minicart-total-price">
					<span class="alm-total-price-title"><?php echo __('قیمت:', 'alma-core') ?></span>
					<p class="alm-total-price">
						<?php
						echo WC()->cart->get_total();
						?>
					</p>
				</div>
				<div class="alm-minicart-buttons">
					<a class="alm-minicart-button"
					   href="<?php echo wc_get_checkout_url() ?>">
					   		<?php esc_html_e('ثبت سفارش', 'alma-core'); ?>
							   <svg xmlns="http://www.w3.org/2000/svg" width="34" height="28" viewBox="0 0 34 28" fill="none">
  <path d="M22.3861 26.3335C28.8002 26.3335 33.9999 20.9609 33.9999 14.3335C33.9999 7.70608 28.8002 2.3335 22.3861 2.3335C15.9719 2.3335 10.7722 7.70608 10.7722 14.3335C10.7722 20.9609 15.9719 26.3335 22.3861 26.3335Z" fill="white" fill-opacity="0.2"/>
  <path d="M14.1387 25.6668C20.6458 25.6668 25.9209 20.4435 25.9209 14.0002C25.9209 7.55684 20.6458 2.3335 14.1387 2.3335C7.63157 2.3335 2.35651 7.55684 2.35651 14.0002C2.35651 20.4435 7.63157 25.6668 14.1387 25.6668Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M18.2624 14H11.1931" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M13.5495 10.5L10.0148 14L13.5495 17.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
					</a>
				</div>

			</div>

		</form>
		<?php
	} else {
		?>
		<p class="alm-mini-cart__empty-message p-16-semibold text-gray-400"><?php esc_html_e('No products in the cart.', 'woocommerce'); ?></p>
		<?php
	}
}

add_action('wp_ajax_alm_update_mini_cart', 'alm_update_mini_cart');
add_action('wp_ajax_nopriv_alm_update_mini_cart', 'alm_update_mini_cart');

function alm_update_mini_cart()
{
	check_ajax_referer('alm-mini-cart-nonce', 'nonce');
	if (!isset($_POST['cart'])) {
		wp_send_json_error(__('خطا در به روزرسانی سبد!', 'alma-core'));
	}
	$cart_items = $_POST['cart'];
	foreach ($cart_items as $index => $cart_item) {
		WC()->cart->set_quantity($index, $cart_item['qty']);
	}
	ob_start();
	alm_get_mini_cart_content();
	$cart_content = ob_get_clean();
	wp_send_json_success([
		'cart_content' => $cart_content,
		'count' => WC()->cart->get_cart_contents_count(),
	]);
}

add_action('wp_ajax_alm_get_mini_cart_content', 'alm_get_mini_cart_content_callback');
add_action('wp_ajax_nopriv_alm_get_mini_cart_content', 'alm_get_mini_cart_content_callback');
function alm_get_mini_cart_content_callback()
{
	check_ajax_referer('alm-mini-cart-nonce', 'nonce');
	ob_start();
	alm_get_mini_cart_content();
	$cart_content = ob_get_clean();
	wp_send_json_success([
		'cart_content' => $cart_content,
		'count' => WC()->cart->get_cart_contents_count(),
	]);
}


/* wc_modifications */
function alm_wc_product_attributes_list(){
	if(!function_exists('wc_get_attribute_taxonomies')){
		return [];
	}
	$all_attributes = wc_get_attribute_taxonomies();
	$list = [];
	foreach($all_attributes as $attribute){
		$list[$attribute->attribute_name]=$attribute->attribute_label;
	}
	return $list;
}

function alm_wc_product_get_attribute_label($type){
	$types = alm_wc_product_attributes_list();
	if(isset($types[$type])){
		return $types[$type];
	}
	return '';
}

add_filter( 'loop_shop_per_page', 'alm_wc_change_loop_shop_per_page', 20 );

function alm_wc_change_loop_shop_per_page( $cols ) {
	$loop_shop_per_page = alm_get_option('loop_shop_per_page');
	return $loop_shop_per_page??$cols;
}

/* register product taxonomy */
function create_brand_taxonomy() {
    $labels = array(
        'name'              => __('برندها', 'alma-core'),
        'singular_name'     => __('برند', 'alma-core'),
        'search_items'      => __('Search Brands', 'alma-core'),
        'all_items'         => __('همه برندها', 'alma-core'),
        'parent_item'       => __('برند والد', 'alma-core'),
        'parent_item_colon' => __('برند والد:', 'alma-core'),
        'edit_item'         => __('ویرایش برند', 'alma-core'),
        'update_item'       => __('به روزرسانی برند', 'alma-core'),
        'add_new_item'      => __('افزودن برند جدید', 'alma-core'),
        'new_item_name'     => __('نام برند', 'alma-core'),
        'menu_name'         => __('برند', 'alma-core'),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'product_brand'),
    );

    register_taxonomy('alm_product_brand', array('product'), $args);
}
add_action('init', 'create_brand_taxonomy', 0);

function alm_wc_add_brand_custom_fields(){
	?>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="alm_brand_svg"><?php _e('فایل svg', 'alma-core'); ?></label></th>
			<td>
				<textarea name="alm_brand_svg" id="alm_brand_svg" rows="5" cols="50" class="large-text"></textarea>
				<p class="description"><?php _e('محتوای تصویر svg برند را وارد کنید..', 'alma-core'); ?></p>
			</td>
		</tr>
	<?php
}

add_action('alm_product_brand_add_form_fields', 'alm_wc_add_brand_custom_fields');

function alm_wc_edit_brand_custom_fields($term) {
    $brand_svg = alm_safe_svg(get_term_meta($term->term_id, 'alm_brand_svg', true));
    ?>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="alm_brand_svg"><?php _e('فایل svg', 'alma-core'); ?></label></th>
			<td>
				<textarea name="alm_brand_svg" id="alm_brand_svg" rows="5" cols="50" class="large-text"><?php echo $brand_svg; ?></textarea>
				<p class="description"><?php _e('محتوای تصویر svg برند را وارد کنید..', 'alma-core'); ?></p>
				<?php
				 if($brand_svg)
					echo $brand_svg;
				 ?>
			</td>
		</tr>
    <?php
}
add_action('alm_product_brand_edit_form_fields', 'alm_wc_edit_brand_custom_fields');

function alm_safe_svg($text){
	return wp_kses($text, array(
		'svg' => array(
			'xmlns' => array(),
			'viewbox' => array(),
			'width' => array(),
			'height' => array(),
			'fill' => array(),
			'stroke' => array(),
			'xmlns:xlink' => array(),
			'x' => array(),
			'y' => array(),
		),
		'g' => array(
			'fill' => array(),
			'stroke' => array(),
			'transform' => array(),
			'opacity' => array(),
		),
		'path' => array(
			'd' => array(),
			'fill' => array(),
			'stroke' => array(),
			'transform' => array(),
		),
		'defs' => array(),
		'rect' => array(
			'x' => array(),
			'y' => array(),
			'width' => array(),
			'height' => array(),
			'fill' => array(),
			'stroke' => array(),
			'rx' => array(),
			'ry' => array(),
		),
		'circle' => array(
			'cx' => array(),
			'cy' => array(),
			'r' => array(),
			'fill' => array(),
			'stroke' => array(),
		),
		'clipPath' => array(
			'id' => array(),
		),
		'use' => array(
			'xlink:href' => array(),
		),
		'line' => array(
			'x1' => array(),
			'y1' => array(),
			'x2' => array(),
			'y2' => array(),
			'stroke' => array(),
		),
		'polygon' => array(
			'points' => array(),
			'fill' => array(),
			'stroke' => array(),
		),
		'polyline' => array(
			'points' => array(),
			'fill' => array(),
			'stroke' => array(),
		),
		'ellipse' => array(
			'cx' => array(),
			'cy' => array(),
			'rx' => array(),
			'ry' => array(),
			'fill' => array(),
			'stroke' => array(),
		),
		'text' => array(
			'x' => array(),
			'y' => array(),
			'font-family' => array(),
			'font-size' => array(),
			'fill' => array(),
			'stroke' => array(),
			'text-anchor' => array(),
		),
		'tspan' => array(
			'x' => array(),
			'y' => array(),
			'dx' => array(),
			'dy' => array(),
			'font-family' => array(),
			'font-size' => array(),
			'fill' => array(),
			'stroke' => array(),
			'text-anchor' => array(),
		),
	));
}

function alm_wc_save_brand_custom_fields($term_id) {
    if (isset($_POST['alm_brand_svg']) && $_POST['alm_brand_svg']) {
        update_term_meta($term_id, 'alm_brand_svg', alm_safe_svg($_POST['alm_brand_svg']));
    }else{
		delete_term_meta($term_id, 'alm_brand_svg');
	}
}
add_action('edited_alm_product_brand', 'alm_wc_save_brand_custom_fields', 10, 2);
add_action('created_alm_product_brand', 'alm_wc_save_brand_custom_fields', 10, 2);

/* register block */
require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/blocks/brands-filter/brands-filter.php';

add_action('rest_api_init', 'alm_wc_add_rest_api_get_brands');

function alm_wc_add_rest_api_get_brands() {
	register_rest_route('alm/v1', '/brands', array(
		'methods' => 'GET',
		'callback' => 'alm_wc_get_brands',
		'permission_callback' => '__return_true'
	));
}

function alm_wc_get_brands(WP_REST_Request $request) {
	$args = array(
		'taxonomy' => 'alm_product_brand', // Replace with your taxonomy slug
		'hide_empty' => $request->get_param('hide_empty') ? true : false,
		'number' => $request->get_param('item_count') ? min(100,intval($request->get_param('item_count'))) : 5,
	);
	$terms = get_terms($args);

	// Optionally, add meta information to the terms if needed
	foreach ($terms as &$term) {
		$term->brand_svg = get_term_meta($term->term_id, 'alm_brand_svg', true); // Replace with your meta key
	}

	return new WP_REST_Response($terms, 200);
}


function alm_wc_filter_products_by_brand($query) {
    if (isset($_GET['brand']) && !is_admin() && $query->is_main_query() && (is_post_type_archive('product') || is_tax(get_object_taxonomies('product')))) {
        // Get the brand slug from query params
        $brand_slug = sanitize_title($_GET['brand']);

        if ($brand_slug) {
            // Modify the query to filter products by brand taxonomy
            $query->set('tax_query', array(
                array(
                    'taxonomy' => 'alm_product_brand', // Replace with your actual taxonomy
                    'field'    => 'slug',
                    'terms'    => $brand_slug,
                ),
            ));
        }
    }
}
add_action('pre_get_posts', 'alm_wc_filter_products_by_brand');

function alm_wc_single_get_shipping_description(){
	global $product;
	$html = '';
	$shipping_classes_settings = alm_get_option('shipping_classes_settings');
	if($shipping_classes_settings && isset($shipping_classes_settings['slug']) && isset($shipping_classes_settings['icon'])){
		$shipping_class_id   = $product->get_shipping_class_id();
		$shipping_class_term = get_term($shipping_class_id, 'product_shipping_class');

		if( ! is_wp_error($shipping_class_term) && is_a($shipping_class_term, 'WP_Term') ) {
			$shipping_class_name  = $shipping_class_term->name;
			$shipping_class_slug  = $shipping_class_term->slug;
			$shipping_class_icon = '';

			$search_slug = array_search($shipping_class_slug,$shipping_classes_settings['slug']);

			if($search_slug!==false){
				$shipping_class_icon = $shipping_classes_settings['icon'][$search_slug];
			}

			if($shipping_class_icon){
				$html .= '<div class="alm-shipping-image"><img src="' . $shipping_class_icon['url'] . '"/></div>';
			}
			$html .= '<div class="alm-shipping-title">' . $shipping_class_name . '</div>';
		}
	}
	return $html;
}

function alm_is_otp_enabled(){
	return alm_get_option('otp_enabled');
}

add_shortcode( 'alm_login', 'alm_login_shortcode_callback' );
function alm_login_shortcode_callback( $atts ) {
	if(!is_user_logged_in()){
		// check if otp is active
		$otp_enabled = alm_is_otp_enabled();
		if($otp_enabled){
			ob_start();
			?>
			<a href="#" class="alm-open-otp-modal alm-default-open-otp-modal" data-otp>
				<?php esc_html_e('حساب کاربری','alma-core')?>
				<svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
  					<path d="M12.511 12C15.2724 12 17.511 9.76142 17.511 7C17.511 4.23858 15.2724 2 12.511 2C9.74956 2 7.51099 4.23858 7.51099 7C7.51099 9.76142 9.74956 12 12.511 12Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  					<path d="M21.101 22C21.101 18.13 17.251 15 12.511 15C7.77102 15 3.92102 18.13 3.92102 22" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</a>
			<?php
			return ob_get_clean();
		}else{
			$account_link = get_dashboard_url();
			$user = wp_get_current_user();
			if(function_exists('wc_get_account_endpoint_url') && wc_get_account_endpoint_url('dashboard')){
				$account_link = wc_get_account_endpoint_url('dashboard');
			}
			?>
			<a href="<?php echo $account_link;?>" class="alm-open-otp-modal alm-default-open-otp-modal">
				<?php esc_html_e('حساب کاربری','alma-core')?>
				<svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
  					<path d="M12.511 12C15.2724 12 17.511 9.76142 17.511 7C17.511 4.23858 15.2724 2 12.511 2C9.74956 2 7.51099 4.23858 7.51099 7C7.51099 9.76142 9.74956 12 12.511 12Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  					<path d="M21.101 22C21.101 18.13 17.251 15 12.511 15C7.77102 15 3.92102 18.13 3.92102 22" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</a>
			<?php
		}
	}else{
		ob_start();
		$account_link = get_dashboard_url();
		$user = wp_get_current_user();
		if(function_exists('wc_get_account_endpoint_url') && wc_get_account_endpoint_url('dashboard')){
			$account_link = wc_get_account_endpoint_url('dashboard');
		}
		?>
			<a href="<?php echo $account_link ?>" class="alm-login-button alm-default-login-button">
				<p class="alm-default-otp-button-username"><?php echo $user->display_name;?></p>
				<p class="alm-default-otp-button-avatar"><?php echo get_avatar($user->ID);?></p>
			</a>
		<?php
		return ob_get_clean();
	}
}


add_action("wp_ajax_nopriv_alm_request_otp_token", "alm_request_otp_token_callback");
add_action("wp_ajax_nopriv_alm_request_resend_otp_token", "alm_request_otp_token_callback");

function alm_request_otp_token_callback(){
	check_ajax_referer('alma-theme-nonce', 'security');

	$otp_type_option = alm_get_option('otp_type');
    $otp_field_name = esc_html__('وارد کردن موبایل یا ایمیل ضروری است','alma-core');
    switch($otp_type_option){
        case 'mobile';
        $otp_field_name = esc_html__('وارد کردن موبایل ضروری است','alma-core');
        break;
        case 'email';
        $otp_field_name = esc_html__('وارد کردن ایمیل ضروری است','alma-core');
        break;
    }

	if(!isset($_POST['otp_input'])){
		wp_send_json_error($otp_field_name);
	}
	$otp_input = sanitize_text_field($_POST['otp_input']);
	$otp_type = '';

	if(in_array($otp_type_option,['both','email']) && is_email($otp_input)){
		$otp_input = trim(sanitize_email($otp_input));

		// todo add switch option for this check step
		if (alm_is_disposable_email($otp_input)) {
			wp_send_json_error(esc_html__('ایمیل وارد شده نامعتبر است','alma-core'));
		}

		$otp_type = 'email';

	}elseif(in_array($otp_type_option,['both','mobile'])){
		$phoneUtil = \libphonenumber\PhoneNumberUtil::getInstance();
		try {
			$phoneNumber = $phoneUtil->parse($otp_input, "IR");
			if(!$phoneUtil->isValidNumber($phoneNumber)){
				wp_send_json_error(esc_html__('شماره وارد شده نامعتبر است','alma-core'));
			}
			$otp_input = $phoneUtil->format($phoneNumber, \libphonenumber\PhoneNumberFormat::E164);
			$otp_type = 'mobile';
		} catch (\libphonenumber\NumberParseException $e) {
			wp_send_json_error(esc_html__('شماره وارد شده نامعتبر است','alma-core'));
		}
	}else{
        $error = esc_html__('موبایل یا ایمیل وارد شده نامعتبر است','alma-core');
        switch($otp_type_option){
            case 'mobile';
            $error = esc_html__('موبایل وارد شده نامعتبر است','alma-core');
            break;
            case 'email';
            $error = esc_html__('ایمیل وارد شده نامعتبر است','alma-core');
            break;
        }
        wp_send_json_error($error);
    }

	$token_expire_seconds = 90;
	$token = get_transient('alm_otp_token_' . $otp_input);



	if($token === false){
		$user_ip = alm_get_ip_address();

		$verification_code = rand(100000, 999999);

		// rate limit: any ip can only request 5 times per hour for getting new otp token
		$user_can_request_get_otp_token_count = 5000;
		$user_can_request_get_otp_token_seconds = 3600;
		$get_token_count = get_transient('alm_otp_get_token_by'.$user_ip);

		if($get_token_count === false){
			$get_token_count = 0;
		}

		if($get_token_count > $user_can_request_get_otp_token_count){
			wp_send_json_error(esc_html__('درخواست بیش از حد مجاز','alma-core'),429);
		}

		set_transient('alm_otp_get_token_by'.$user_ip, 1+$get_token_count,$user_can_request_get_otp_token_seconds);
		set_transient('alm_otp_token_' . $otp_input,$verification_code,$token_expire_seconds);
		set_transient('alm_otp_token_' . $otp_input . '_expires', time() + $token_expire_seconds, $token_expire_seconds);

		switch($otp_type){
			case 'mobile':
				alm_send_otp_token_by_sms($otp_input,$verification_code);
				wp_send_json_success([
					'otp_input'=>$otp_input,
					'verify_code'=>alm_otp_form_step_2_template([
						'otp_input'=>$otp_input,
						'otp_type'=>$otp_type
					]),
				]);
				break;
			case 'email':
				alm_send_otp_token_by_email($otp_input,$verification_code);
				wp_send_json_success([
					'otp_input'=>$otp_input,
					'verify_code'=>alm_otp_form_step_2_template([
						'otp_input'=>$otp_input,
						'otp_type'=>$otp_type
					]),
				]);
				break;
			default:
				wp_send_json_error(esc_html__('اطلاعات وارد شده نامعتبر است','alma-core'));
		}
	}else{
		wp_send_json_success([
			'otp_input'=>$otp_input,
			'verify_code'=>alm_otp_form_step_2_template([
				'otp_input'=>$otp_input,
				'otp_type'=>$otp_type
			]),
		]);
	}
}

add_action("wp_ajax_nopriv_alm_verify_otp_token", "alm_verify_otp_token_callback");
function alm_verify_otp_token_callback(){
	check_ajax_referer('alma-theme-nonce', 'security');
	if(!isset($_POST['otp_input']) || !isset($_POST['otp_verification_code'])){
		wp_send_json_error(esc_html__('اطلاعات وارد شده نامعتبر است','alma-core'));
	}
	$otp_input = sanitize_text_field($_POST['otp_input']);
	$otp_type = '';

	if(is_email($otp_input)){
		$otp_input = trim(sanitize_email($otp_input));

		// todo add switch option for this check step
		if (alm_is_disposable_email($otp_input)) {
			wp_send_json_error(esc_html__('ایمیل وارد شده نامعتبر است','alma-core'));
		}

		$otp_type = 'email';

	}else{
		$phoneUtil = \libphonenumber\PhoneNumberUtil::getInstance();
		try {
			$phoneNumber = $phoneUtil->parse($otp_input, "IR");
			if(!$phoneUtil->isValidNumber($phoneNumber)){
				wp_send_json_error(esc_html__('شماره وارد شده نامعتبر است','alma-core'));
			}
			$otp_input = $phoneUtil->format($phoneNumber, \libphonenumber\PhoneNumberFormat::E164);
			$otp_type = 'mobile';
		} catch (\libphonenumber\NumberParseException $e) {
			wp_send_json_error(esc_html__('شماره وارد شده نامعتبر است','alma-core'));
		}
	}

	$token = get_transient('alm_otp_token_' . $otp_input);
	$otp_verification_code = sanitize_text_field($_POST['otp_verification_code']);

	$max_verification_try = 2;

	$verification_try = get_transient('alm_otp_token_' . $otp_input . '_verification_try');
	if($verification_try === false){
		$verification_try = 0;
	}

	if($verification_try > $max_verification_try){
		delete_transient('alm_otp_token_' . $otp_input);
		delete_transient('alm_otp_token_' . $otp_input . '_expires');
		wp_send_json_error(esc_html__('درخواست بیش از حد مجاز','alma-core'),429);
	}

	if($token === false || $token !== $otp_verification_code){
		$token_expires = get_transient('alm_otp_token_' . $otp_input . '_expires');
		if($token_expires === false){
			$token_expires = time();
		}
		set_transient('alm_otp_token_' . $otp_input . '_verification_try' , 1 + $verification_try , $token_expires - time());
		wp_send_json_error(esc_html__('اطلاعات وارد شده نامعتبر است','alma-core'));
	}

	delete_transient('alm_otp_token_' . $otp_input);
	delete_transient('alm_otp_token_' . $otp_input . '_expires');
	delete_transient('alm_otp_token_' . $otp_input . '_verification_try');

	$username = sanitize_user($otp_input);
	$password = wp_generate_password();
	switch($otp_type){
		case 'email':
			$user = get_user_by('email', $otp_input);
			if(!$user){
				$user_id = wp_create_user($username, $password, $otp_input);

				if (is_wp_error($user_id)) {
					wp_send_json_error($user_id->get_error_message());
				}

				$user = get_user_by('id', $user_id);
			}
			break;
		case 'mobile':
			$user = alm_get_user_by_mobile($otp_input);
			if(!$user){
				$user_id = wp_create_user($username, $password,"mn" . ltrim($otp_input,'+') . "@alm.com");

				if (is_wp_error($user_id)) {
					wp_send_json_error($user_id->get_error_message());
				}

				update_user_meta($user_id,'otp_mobile_number',$otp_input);

				$user = get_user_by('id', $user_id);
			}
			break;
		default:
			wp_send_json_error(esc_html__('مشکلی در فرآیند ورود/ثبت نام پیش آمده است.','alma-core'));

	}

	wp_set_current_user($user->ID, $user->user_login);
	wp_set_auth_cookie($user->ID);
	do_action('wp_login', $user->user_login,$user);

	update_user_meta($user->ID, 'last_login', current_time('mysql'));

	// Success: Send back the user data
	wp_send_json_success(esc_html__('ورود با موفقیت انجام شد','alma-core'));

}


function alm_otp_form_step_1_template($data = []){
	ob_start();
	$otp_type = alm_get_option('otp_type');
    $otp_field_name = esc_html__('موبایل یا ایمیل خود را وارد کنید','alma-core');
    switch($otp_type){
        case 'mobile';
        $otp_field_name = esc_html__('موبایل خود را وارد کنید','alma-core');
        break;
        case 'email';
        $otp_field_name = esc_html__('ایمیل خود را وارد کنید','alma-core');
        break;
    }
	?>
	<form class="alm-otp-form-step-1" method="post">
		<h3 class="alm-otp-form-title"><?php esc_html_e('ورود/عضویت','alma-core')?></h3>
		<div class="alm-form-group">
			<label for="otp_input"><?php echo $otp_field_name;?></label>
			<input type="text" id="otp_input" name="otp_input" value="<?php echo $data['otp_input']??''?>" require>
		</div>
		<div class="alm-form-submit">
			<button type="submit"><?php esc_html_e('ورود/عضویت','alma-core')?></button>
		</div>
	</form>
	<?php
	return ob_get_clean();
}

function alm_otp_form_step_2_template($data = []){
	$otp_input = $data['otp_input']??'';
	$otp_token_expires = get_transient('alm_otp_token_' . $otp_input . '_expires');

	if(is_email($otp_input)){
		$otp_type = 'email';
	}else{
		$otp_type = 'mobile';
	}

	ob_start();
	?>
	<form class="alm-otp-form-step-2" method="post">
		<h3 class="alm-otp-form-title">
			<?php
			if($otp_type == 'email'){
				esc_html_e('کد تائید به ایمیل شما ارسال شد','alma-core');

			}else{
				esc_html_e('کد تائید به موبایل شما ارسال شد','alma-core');
			}
			?>
		</h3>
		<div class="alm-form-group">
			<label for="otp_verification_code">
				<?php
				if($otp_type == 'email'){
					esc_html_e('کد تائید به ایمیل شما ارسال شد','alma-core');
				}else{
					esc_html_e('کد تائید به موبایل شما ارسال شد','alma-core');
				}
				?>
			</label>
			<input type="text" id="otp_verification_code" name="otp_verification_code" require>
		</div>
		<input type="hidden" id="otp_input" name="otp_input" value="<?php echo $data['otp_input']??''?>">
		<div class="alm-form-submit">
			<button type="submit"><?php esc_html_e('ادامه','alma-core')?></button>
		</div>
		<div class="alm-otp-form-time-box">
			<?php if($otp_token_expires !== false && ($remain_time = $otp_token_expires - time()) > 0){?>
				<div class="alm-form-otp-timer-content">
					<span class="alm-form-otp-timer-description"><?php esc_html_e('ارسال مجدد کد تا ','alma-core')?></span>
					<span class="alm-form-otp-timer" data-remain="<?php echo $remain_time;?>"></span>
				</div>
			<?php }else{?>
				<button type="button" class="alm-otp-form-resend-button"><?php esc_html_e('ارسال مجدد کد برای شما','alma-core')?></button>
			<?php }?>
		</div>
	</form>
	<?php
	return ob_get_clean();
}

function alm_send_otp_token_by_sms($otp_input,$verification_code){
	$otp_template = alm_get_option('otp_mobile_text');
    $parameters = [
        '{code}'=>$verification_code,
        '{site_title}'=>get_bloginfo( 'name' ),
        '{domain}'=>get_site_url(),
    ];
    $message = str_replace(array_keys($parameters),array_values($parameters),$otp_template);

	$driver = '';
	$otp_pattern_code = '';

	$farazsms_active = get_option('farazsms_active');
	if($farazsms_active){
		$farazsms_username = get_option('farazsms_username');
		$farazsms_password = get_option('farazsms_password');
		$otp_pattern_code = get_option('farazsms_otp_pattern_code','');
		if(!empty($farazsms_username) && !empty($farazsms_password)){
			$driver = 'farazsms';
			try{
				$sms_gateway = \ALMA\SMS\SMSGatewayFactory::create($driver);
				if(!empty($otp_pattern_code) && $sms_gateway instanceof \ALMA\SMS\Drivers\FarazSMS){
					$sms_gateway->sendPatterns(
						$otp_input,
						$otp_pattern_code,
						[
							'code'=>$verification_code
						]
					);
				}else{
					$sms_gateway->sendSMS($otp_input,$message);
				}
			}catch(Exception $e){
				wp_send_json_error(esc_html__('مشکلی در ارسال پیامک پیش آمده است', 'alma-core'));
			}
			return;
		}
	}

	$melipayamak_active = get_option('melipayamak_active');
	if($melipayamak_active){
		$melipayamak_username = get_option('melipayamak_username');
		$melipayamak_password = get_option('melipayamak_password');
		$otp_pattern_code = get_option('melipayamak_otp_pattern_code','');
		if(!empty($melipayamak_username) && !empty($melipayamak_password)){
			$driver = 'melipayamak';
			try{
				$sms_gateway = \ALMA\SMS\SMSGatewayFactory::create($driver);
				if(!empty($otp_pattern_code) && $sms_gateway instanceof \ALMA\SMS\Drivers\MeliPayamak){
					$sms_gateway->sendByBaseNumber(
						[
							$verification_code
						],
						$otp_input,
						$otp_pattern_code
					);
				}else{
					$sms_gateway->sendSMS($otp_input,$message);
				}
			}catch(Exception $e){
				wp_send_json_error(esc_html__('مشکلی در ارسال پیامک پیش آمده است', 'alma-core'));
			}
			return;
		}
	}

	if(empty($driver)){
		wp_send_json_error(esc_html__('مشکلی در ارسال پیامک پیش آمده است', 'alma-core'));
	}
}

function alm_send_otp_token_by_email($otp_input, $verification_code) {
    $otp_subject = alm_get_option('otp_email_subject');
    $subject_parameters = [
        '{site_title}'=>get_bloginfo( 'name' ),
        '{domain}'=>get_site_url(),
    ];
    $subject = str_replace(array_keys($subject_parameters),array_values($subject_parameters),$otp_subject);

    $otp_template = alm_get_option('otp_email_text');
    $parameters = [
        '{code}'=>$verification_code,
        '{site_title}'=>get_bloginfo( 'name' ),
        '{domain}'=>get_site_url(),
    ];
    $message = str_replace(array_keys($parameters),array_values($parameters),$otp_template);

    $headers = array('Content-Type: text/html; charset=UTF-8');

    $mail_sent = wp_mail($otp_input, $subject, $message, $headers);

    if (!$mail_sent) {
        wp_send_json_error(esc_html__('مشکلی در ارسال ایمیل پیش آمده است', 'alma-core'));
    }
}

function alm_is_disposable_email($email) {
    $disposable_domains = array('tempmail.com', '10minutemail.com', 'mailinator.com'); // Add more known disposable domains
    $domain = substr(strrchr($email, "@"), 1);
    return in_array($domain, $disposable_domains);
}

function alm_get_ip_address(){
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key){
        if (array_key_exists($key, $_SERVER) === true){
            foreach (explode(',', $_SERVER[$key]) as $ip){
                $ip = trim($ip);

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false){
                    return $ip;
                }
            }
        }
    }
}

function alm_get_user_by_mobile($mobile) {
    $args = array(
        'meta_query' => array(
            array(
                'key' => 'otp_mobile_number', // The meta key for mobile number
                'value' => $mobile,
                'compare' => '='
            )
        ),
        'fields' => 'ID', // Only get user IDs
        'number' => 1, // Limit to one user
    );

    $users = get_users($args);

    return !empty($users) ? get_userdata($users[0]) : false; // Return user object or false
}


// Create a shortcode to display user reviews on My Account page
function alm_my_product_reviews_callback() {
    // Get the current user's ID
    $user_id = get_current_user_id();

    // Check if the user is logged in
    if (!$user_id) {
        return __('You need to be logged in to see your product reviews.', 'your-text-domain');
    }

	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1; // Current page
    $comments_per_page = 10; // Number of reviews per page

    // Get product reviews by the current user
    $args = array(
        'user_id' => $user_id,
        'post_type' => 'product',
		'number' => $comments_per_page, // Limit the number of reviews
        'paged' => $paged, // Set current page for pagination
    );

    // Query the reviews
    $reviews = get_comments($args);
	$total_reviews = get_comments(array(
        'user_id' => $user_id,
        'post_type' => 'product',
		'count'=>true,
    )); // No pagination arguments



    // Check if there are reviews
    if (empty($reviews)) {
		ob_start();
		?>
		<div class="alm-account-empty-downloads">
			<span class="alm-account-empty-downloads-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120" fill="none">
					<path d="M80 10H40C20 10 10 20 10 40V105C10 107.75 12.25 110 15 110H80C100 110 110 100 110 80V40C110 20 100 10 80 10Z" stroke="#F5683C" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M35 47.5H85" stroke="#F5683C" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
					<path d="M35 72.5H70" stroke="#F5683C" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</span>
			<span class="alm-account-empty-downloads-message"><?php esc_html_e('هنوز دیدگاهی درج نشده..','alma-core')?></span>
		</div>
		<?php
		return ob_get_clean();
    }

    // Start output buffering
    ob_start();

    echo '<ul class="alm-user-reviews">';

	$comment_rate_icon = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
  <path d="M4.30502 12C4.38752 11.6325 4.23752 11.1075 3.97502 10.845L2.15252 9.0225C1.58252 8.4525 1.35752 7.845 1.52252 7.32C1.69502 6.795 2.22752 6.435 3.02252 6.3L5.36252 5.91C5.70002 5.85 6.11252 5.55 6.27002 5.2425L7.56002 2.655C7.93502 1.9125 8.44502 1.5 9.00002 1.5C9.55502 1.5 10.065 1.9125 10.44 2.655L11.73 5.2425C11.8275 5.4375 12.03 5.625 12.2475 5.7525L4.17002 13.83C4.06502 13.935 3.88502 13.8375 3.91502 13.6875L4.30502 12Z" fill="#F5683C"/>
  <path d="M14.0246 10.845C13.7546 11.115 13.6046 11.6325 13.6946 12L14.2121 14.2575C14.4296 15.195 14.2946 15.9 13.8296 16.2375C13.6421 16.3725 13.4171 16.44 13.1546 16.44C12.7721 16.44 12.3221 16.2975 11.8271 16.005L9.62961 14.7C9.28461 14.4975 8.71461 14.4975 8.36961 14.7L6.17211 16.005C5.33961 16.4925 4.62711 16.575 4.16961 16.2375C3.99711 16.11 3.86961 15.9375 3.78711 15.7125L12.9071 6.59255C13.2521 6.24755 13.7396 6.09004 14.2121 6.17254L14.9696 6.30004C15.7646 6.43504 16.2971 6.79505 16.4696 7.32005C16.6346 7.84505 16.4096 8.45254 15.8396 9.02254L14.0246 10.845Z" fill="#F5683C"/>
</svg>';


    // Loop through each review and display it
    foreach ($reviews as $review) {
        $product = wc_get_product($review->comment_post_ID);
		$rating = get_comment_meta( $review->comment_ID, 'rating', true);

        echo '<li>';
		echo "<div class='alm-woocommerce-review-product-info'>";
		echo "<a class='alm-woocommerce-review-product-image' href='" . $product->get_permalink() . "'>" . $product->get_image() . "</a>";
        echo "<h3 class='alm-woocommerce-review-product-title'><a href='" . $product->get_permalink() . "'>" . esc_html($product->get_name()) . '</a></h3>';
        echo "</div>";

		echo "<div class='alm-woocommerce-review-product-comment'>";

		echo '<p class="alm-woocommerce-review-product-body">' . esc_html($review->comment_content) . '</p>';

		echo '<div class="alm-woocommerce-review-product-metas">';
		if(!empty($rating))
        	echo '<p class="alm-woocommerce-review-product-rating">' . intval($rating) . ' / 5' . $comment_rate_icon . '</p>'; // Assuming rating is stored

		if ( '0' == $review->comment_approved ) {
			echo '<p class="alm-woocommerce-review-product-awaiting-moderation">' . esc_html__( 'تایید نشده','alma-core') . '</p>';
		}

		echo "<p class='alm-woocommerce-review-product-date'>";
		comment_date('Y/m/d',$review->comment_ID);
		echo "</p>";

		echo "</div>";

		echo "</div>";

		echo '</li>';
    }

    echo '</ul>';

	// Pagination
	$total_pages = ceil($total_reviews / $comments_per_page);
	if ($total_pages > 1) {
		echo '<div class="alm-woocommerce-myaccount-pagination">';
		echo paginate_links(array(
			'current' => $paged,
			'total' => $total_pages,
			'format' => '?paged=%#%',
			'prev_text' => __('قبلی', 'alma-core'),
			'next_text' => __('بعدی', 'alma-core'),
		));
		echo '</div>';
	}

    // Return the buffered content
    return ob_get_clean();
}

add_shortcode('alm_my_product_reviews', 'alm_my_product_reviews_callback');

add_action('init', 'alm_wc_add_reviews_tab_to_myaccount_tabs');

function alm_wc_add_reviews_tab_to_myaccount_tabs()
{
	add_rewrite_endpoint('reviews', EP_ROOT | EP_PAGES);
}

add_action('init', 'alm_wc_add_notifications_tab_to_myaccount_tabs');

function alm_wc_add_notifications_tab_to_myaccount_tabs()
{
	add_rewrite_endpoint('notifications', EP_ROOT | EP_PAGES);
}

add_action('init', 'alm_wc_myaccount_display_reviews');
function alm_wc_myaccount_display_reviews()
{
	add_action('woocommerce_account_reviews_endpoint', function () {
		echo do_shortcode('[alm_my_product_reviews]');
	});
}

add_action('init', 'alm_wc_myaccount_display_notifications');
function alm_wc_myaccount_display_notifications()
{
	add_action('woocommerce_account_notifications_endpoint', function () {
		alm_wc_myaccount_show_notifications();
	});
}

add_filter('woocommerce_account_menu_items', 'alm_wc_add_reviews_my_account_menu_item');

function alm_wc_add_reviews_my_account_menu_item($menu_items){
	$menu_items['reviews'] = esc_html__('دیدگاه ها','alma-core');
	return $menu_items;
}

add_filter('woocommerce_account_menu_items', 'alm_wc_add_notifications_my_account_menu_item');

function alm_wc_add_notifications_my_account_menu_item($menu_items){
	$menu_items['notifications'] = esc_html__('اطلاع رسانی','alma-core');
	return $menu_items;
}

add_filter('alm_woocommerce_account_menu_item_icon',function($icons){
	$icons['reviews'] = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
  <path d="M12 1.5H6C3 1.5 1.5 3 1.5 6V15.75C1.5 16.1625 1.8375 16.5 2.25 16.5H12C15 16.5 16.5 15 16.5 12V6C16.5 3 15 1.5 12 1.5Z" stroke="#373254" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M5.25 7.125H12.75" stroke="#373254" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M5.25 10.875H10.5" stroke="#373254" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
	return $icons;
});

add_filter('alm_woocommerce_account_menu_item_icon',function($icons){
	$icons['notifications'] = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
  <path d="M9 4.83008V7.32758" stroke="#373254" stroke-miterlimit="10" stroke-linecap="round"/>
  <path d="M9.01419 1.5C6.25419 1.5 4.01919 3.735 4.01919 6.495V8.07C4.01919 8.58 3.80919 9.345 3.54669 9.78L2.59419 11.37C2.00919 12.3525 2.41419 13.4475 3.49419 13.8075C7.07919 15 10.9567 15 14.5417 13.8075C15.5542 13.47 15.9892 12.285 15.4417 11.37L14.4892 9.78C14.2267 9.345 14.0167 8.5725 14.0167 8.07V6.495C14.0092 3.75 11.7592 1.5 9.01419 1.5Z" stroke="#373254" stroke-miterlimit="10" stroke-linecap="round"/>
  <path d="M11.497 14.115C11.497 15.4875 10.372 16.6125 8.99945 16.6125C8.31695 16.6125 7.68695 16.3275 7.23695 15.8775C6.78695 15.4275 6.50195 14.7975 6.50195 14.115" stroke="#373254" stroke-miterlimit="10"/>
</svg>';
	return $icons;
});

function alm_wc_myaccount_show_notifications(){
	$current_user = wp_get_current_user();
	$user_roles = $current_user->roles;

	$role_meta_conditions = array('relation' => 'OR');

	foreach ($user_roles as $role) {
		$role_meta_conditions[] = array(
			'key' => '_user_roles',
			'value' => '"' . $role . '"',  // Add quotes because roles are stored in serialized array
			'compare' => 'LIKE'
		);
	}

	// Add condition for notices with no role restriction
	$role_meta_conditions[] = array(
		'key' => '_user_roles',
		'value' => '',
		'compare' => '='
	);
	$role_meta_conditions[] = array(
		'key' => '_user_roles',
		'value' => 'a:0:{}',  // Empty serialized array
		'compare' => '='
	);

	// Get the current page number
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

	// Set posts per page
	$posts_per_page = 10;

	$args = array(
		'post_type' => 'alm_notification',
		'posts_per_page' => $posts_per_page,
        'paged' => $paged, // Set the current page
		'post_status' => 'publish',
		'orderby' => 'date',
		'order' => 'DESC',
		'meta_query' => array(
			'relation' => 'AND',
			// Expiry date check
			array(
				'relation' => 'OR',
				array(
					'key' => '_expiry_date',
					'value' => current_time('Y-m-d'),
					'compare' => '>=',
					'type' => 'DATE'
				),
				array(
					'key' => '_expiry_date',
					'value' => '',
					'compare' => '='
				)
			),
			// User roles check
			$role_meta_conditions
		)
	);

	$notifications = new WP_Query($args);
	$counter = 0; // Initialize counter

	if ($notifications->have_posts()) {
		?>
			<div class="alm-woocommecre-notifications">
		<?php
		while($notifications->have_posts()){
			$notifications->the_post();
			if($counter < 2){
				$counter++; // Increment counter on each loop iteration
			}
			?>
				<div class="alm-woocommecre-notification <?php echo $counter==1?'alm-show-notification':'';?>">
					<header>
						<h2 class="alm-woocommecre-notification-title">
							<svg xmlns="http://www.w3.org/2000/svg" width="7" height="8" viewBox="0 0 7 8" fill="none">
  								<circle cx="3.5" cy="4" r="3.5" fill="#E76941"/>
							</svg>
							<?php the_title()?>
						</h2>
						<button class="alm-woocommecre-notification-toggle">
							<svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" fill="none">
								<path opacity="0.4" d="M25.6335 3.16675H12.3652C6.60185 3.16675 3.16602 6.60258 3.16602 12.3659V25.6184C3.16602 31.3976 6.60185 34.8334 12.3652 34.8334H25.6177C31.381 34.8334 34.8168 31.3976 34.8168 25.6342V12.3659C34.8327 6.60258 31.3968 3.16675 25.6335 3.16675Z" fill="#F9A48A"/>
								<path d="M25.3327 17.8126H20.1868V12.6667C20.1868 12.0176 19.6485 11.4792 18.9993 11.4792C18.3502 11.4792 17.8118 12.0176 17.8118 12.6667V17.8126H12.666C12.0168 17.8126 11.4785 18.3509 11.4785 19.0001C11.4785 19.6492 12.0168 20.1876 12.666 20.1876H17.8118V25.3334C17.8118 25.9826 18.3502 26.5209 18.9993 26.5209C19.6485 26.5209 20.1868 25.9826 20.1868 25.3334V20.1876H25.3327C25.9818 20.1876 26.5202 19.6492 26.5202 19.0001C26.5202 18.3509 25.9818 17.8126 25.3327 17.8126Z" fill="#F9A48A"/>
							</svg>
						</button>
						<time class="alm-woocommecre-notification-date"><?php the_date('Y/m/d')?></time>
					</header>
					<div class="alm-woocommecre-notification-content"><?php the_content()?></div>
				</div>
			<?php
		}
		?>
			</div>
		<?php


		$total_pages = $notifications->max_num_pages;
		if ($total_pages > 1) {
			$current_page = max(1, get_query_var('paged'));

			echo '<div class="alm-woocommerce-myaccount-pagination">';
			echo paginate_links(array(
				'current' => $current_page,
				'total' => $total_pages,
				'format' => '?paged=%#%',
				'prev_text' => __('قبلی', 'alma-core'),
				'next_text' => __('بعدی', 'alma-core'),
			));
			echo "</div>";
		}
	}else{
		?>
		<div class="alm-account-empty-notifications">
			<span class="alm-account-empty-notifications-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120" fill="none">
					<path d="M60 32.2V48.85" stroke="#F5683C" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round"/>
					<path d="M60.1005 10C41.7005 10 26.8005 24.9 26.8005 43.3V53.8C26.8005 57.2 25.4005 62.3 23.6505 65.2L17.3005 75.8C13.4005 82.35 16.1005 89.65 23.3005 92.05C47.2005 100 73.0505 100 96.9505 92.05C103.7 89.8 106.6 81.9 102.95 75.8L96.6005 65.2C94.8505 62.3 93.4505 57.15 93.4505 53.8V43.3C93.4005 25 78.4005 10 60.1005 10Z" stroke="#F5683C" stroke-width="4" stroke-miterlimit="10" stroke-linecap="round"/>
					<path d="M76.6496 94.1C76.6496 103.25 69.1496 110.75 59.9996 110.75C55.4496 110.75 51.2496 108.85 48.2496 105.85C45.2496 102.85 43.3496 98.65 43.3496 94.1" stroke="#F5683C" stroke-width="4" stroke-miterlimit="10"/>
				</svg>
			</span>
			<span class="alm-account-empty-notifications-message"><?php esc_html_e('هنوز اعلانی وجود ندارد.','alma-core')?></span>
		<?php
	}

	wp_reset_postdata();
}

add_action('init', 'alm_add_rewrite_rules');
function alm_add_rewrite_rules() {
    add_rewrite_rule('^my-account/reviews/page/([0-9]+)/?$', 'index.php?pagename=my-account&reviews=true&paged=$matches[1]', 'top');
	add_rewrite_rule('^my-account/notifications/page/([0-9]+)/?$', 'index.php?pagename=my-account&notifications=true&paged=$matches[1]', 'top');
}

/* add notices */
add_action('init', 'alm_wc_register_notification_post_type');
function alm_wc_register_notification_post_type() {
    $labels = array(

        'name' => esc_html__('اطلاعیه', 'alma-core'),
        'singular_name' => esc_html__('اطلاعیه', 'alma-core'),
        'add_new' => esc_html__('افزودن', 'alma-core'),
        'add_new_item' => esc_html__('افزودن اطلاعیه جدید', 'alma-core'),
        'edit_item' => esc_html__('ویرایش اطلاعیه', 'alma-core'),
        'new_item' => esc_html__('اطلاعیه جدید', 'alma-core'),
        'view_item' => esc_html__('مشاهده اطلاعیه', 'alma-core'),
        'view_items' => esc_html__('مشاهده اطلاعیه‌ها', 'alma-core'),
        'search_items' => esc_html__('جستجوی اطلاعیه‌ها', 'alma-core'),
        'not_found' => esc_html__('اطلاعیه‌ای یافت نشد.', 'alma-core'),
        'not_found_in_trash' => esc_html__('اطلاعیه‌ای در زباله دان یافت نشد.', 'alma-core'),
        'all_items' => esc_html__('همه اطلاعیه‌ها', 'alma-core'),
        'archives' => esc_html__('آرشیو اطلاعیه', 'alma-core'),
        'menu_name' => esc_html__('اطلاعیه‌ها', 'alma-core'),
    );

    $args = array(
        'labels' => $labels,
        'description' => esc_html__('مدیریت و سازماندهی اطلاعیه‌ها', 'alma-core'),
        'public' => true,
        'hierarchical' => false,
        'exclude_from_search' => true,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_in_admin_bar' => true,
        'show_in_rest' => true,
        'menu_position' => null,
        'menu_icon' => 'dashicons-megaphone',
        'capability_type' => 'post',
        'capabilities' => array(),
        'supports' => array('title', 'editor', 'revisions', 'thumbnail'),
        'taxonomies' => array('pzy_service'),
        'has_archive' => false,
        'rewrite' => array('slug' => 'notification'),
        'query_var' => true,
        'can_export' => true,
        'delete_with_user' => false,
        'template' => array(),
        'template_lock' => false,
    );
    register_post_type('alm_notification', $args);
}

add_action('add_meta_boxes_alm_notification', 'meta_boxes_alm_notification_callback');
function meta_boxes_alm_notification_callback() {
    add_meta_box(
        'alm_notification_settings',
        esc_html__('تنظیمات اطلاعیه','alma-core'),
        'alm_render_notification_settings_meta_boxes',
    );
}

function alm_render_notification_settings_meta_boxes($post){

	wp_nonce_field('alm_notification_settings_action', 'alm_notification_settings_nonce');

    // Get existing values
    $expiry_date = get_post_meta($post->ID, '_expiry_date', true);
    $user_roles = get_post_meta($post->ID, '_user_roles', true);
    if (!is_array($user_roles)) {
        $user_roles = array();
    }

    // Get all user roles
    $all_roles = wp_roles()->get_names();

	?>
    <p>
		<input type="checkbox" name="limit_notification_time" <?php echo $expiry_date?'checked':''?>>
		<label for="alm-pdate-alt"><?php esc_html_e('محدود کردن زمان اطلاعیه','alma-core')?></label><br>
        <input type="text" id="alm-pdate-alt" name="expiry_date"class="alm-pdate-alt">
		<div class="alm-pdate" data-date="<?php echo $expiry_date?>"></div>
    </p>

    <p>
        <label><?php esc_html_e('نوع کاربران','alma-core') ?></label><br>
        <?php foreach ($all_roles as $role_key => $role_name) : ?>
            <label>
                <input type="checkbox" name="user_roles[]"
                       value="<?php echo esc_attr($role_key); ?>"
                       <?php checked(in_array($role_key, $user_roles)); ?>>
                <?php echo esc_html($role_name); ?>
            </label><br>
        <?php endforeach; ?>
    </p>
    <?php
}

add_action('save_post_alm_notification', 'alm_save_notification_meta_callback');
function alm_save_notification_meta_callback($post_id) {
    // Security checks
    if (!isset($_POST['alm_notification_settings_nonce']) ||
        !wp_verify_nonce($_POST['alm_notification_settings_nonce'], 'alm_notification_settings_action')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Save expiry date
    if (isset($_POST['expiry_date']) && isset($_POST['limit_notification_time'])) {
		$time = date('Y-m-d',$_POST['expiry_date']/1000);
		update_post_meta($post_id, '_expiry_date',$time);
    }else{
		update_post_meta($post_id, '_expiry_date','');
	}

    // Save user roles
    if (isset($_POST['user_roles'])) {
        $user_roles = array_map('sanitize_text_field', $_POST['user_roles']);
        update_post_meta($post_id, '_user_roles', $user_roles);
    } else {
        delete_post_meta($post_id, '_user_roles');
    }
}

/* install plugin */
register_activation_hook(__FILE__, 'alm_update_core_version');

function alm_core_check_db_update(){
    $installed_version = get_option('alm_core_db_version');

    if($installed_version != ALMA_CORE_VERSION){
        alm_update_core_version();
    }
}

add_action('admin_init', 'alm_core_check_db_update');

function alm_update_core_version()
{
	// do anything is needed for new update
	alm_create_newsletter_subscribers_table();

    add_option('alm_core_db_version', ALMA_CORE_VERSION);
}
/* install plugin */


/* newsletter */
function alm_create_newsletter_subscribers_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'alm_newsletter_subscribers';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        contact varchar(255) NOT NULL,
        subscribed_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        active tinyint(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

add_action('wp_ajax_nopriv_alm_register_newsletter', 'alm_register_newsletter');
add_action('wp_ajax_alm_register_newsletter', 'alm_register_newsletter');

function alm_register_newsletter()
{
    check_ajax_referer('alm-ajax-nonce', 'security');
    if (!isset($_POST['contact'])) {
        wp_send_json_error(__('ایمیل خود را واردکنید.', 'alma-core'));
    }
    global $wpdb;
    $table_name = $wpdb->prefix . 'alm_newsletter_subscribers';
    $contact = sanitize_text_field($_POST['contact']);

    // Check if the contact already exists
    $contact_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE contact = %s",
        $contact
    ));

    if ($contact_exists) {
        wp_send_json_error(__('شما قبلا ثبت نام کرده اید.', 'alma-core'));
    } else {
        $inserted = $wpdb->insert(
            $table_name,
            array(
                'contact' => $contact,
                'subscribed_at' => current_time('mysql', 1) // 1 = GMT/UTC time
            )
        );

        if ($inserted) {
            wp_send_json_success(__('از عضویت شما متشکریم', 'alma-core'));
        } else {
            wp_send_json_error(__('مشکلی در فرآیند ثبت نام رخ داده است کمی بعد امتحان کنید.', 'alma-core'));
        }
    }
}

/* newsletter */

add_filter('alm_head_style',function($style){
	$default_blog_carts_customize = alm_get_option('default_blog_carts_customize');
	if($default_blog_carts_customize && $count = alm_get_option('default_blog_carts_count')){
		$width = (100 - max(0 , $count - 1) * 2)/$count;
		$style .= <<<EOL
		.alm-archive .alm-post-card{
			width: {$width}%;
		}
EOL;
	}

	$blog_carts_show_first_breakpoint = alm_get_option('blog_carts_show_first_breakpoint');
	if($blog_carts_show_first_breakpoint){
		$count = alm_get_option('blog_carts_first_breakpoint_count');
		$breakpoint = alm_get_option('blog_carts_first_breakpoint_width');
		if($count && $breakpoint){
			$width = (100 - max(0 , $count - 1) * 2)/$count;
			$style .= <<<EOL
			@media (max-width: {$breakpoint}px) {
				.alm-archive .alm-post-card{
					width: {$width}%;
				}
			}
EOL;
		}
	}

	$blog_carts_show_second_breakpoint = alm_get_option('blog_carts_show_second_breakpoint');
	if($blog_carts_show_second_breakpoint){
		$count = alm_get_option('blog_carts_second_breakpoint_count');
		$breakpoint = alm_get_option('blog_carts_second_breakpoint_width');
		if($count && $breakpoint){
			$width = (100 - max(0 , $count - 1) * 2)/$count;
			$style .= <<<EOL
			@media (max-width: {$breakpoint}px) {
				.alm-archive .alm-post-card{
					width: {$width}%;
				}
			}
EOL;
		}
	}

	$blog_carts_show_third_breakpoint = alm_get_option('blog_carts_show_third_breakpoint');
	if($blog_carts_show_third_breakpoint){
		$count = alm_get_option('blog_carts_third_breakpoint_count');
		$breakpoint = alm_get_option('blog_carts_third_breakpoint_width');
		if($count && $breakpoint){
			$width = (100 - max(0 , $count - 1) * 2)/$count;
			$style .= <<<EOL
			@media (max-width: {$breakpoint}px) {
				.alm-archive .alm-post-card{
					width: {$width}%;
				}
			}
EOL;
		}
	}

	$blog_carts_show_fourth_breakpoint = alm_get_option('blog_carts_show_fourth_breakpoint');
	if($blog_carts_show_fourth_breakpoint){
		$count = alm_get_option('blog_carts_fourth_breakpoint_count');
		$breakpoint = alm_get_option('blog_carts_fourth_breakpoint_width');
		if($count && $breakpoint){
			$width = (100 - max(0 , $count - 1) * 2)/$count;
			$style .= <<<EOL
			@media (max-width: {$breakpoint}px) {
				.alm-archive .alm-post-card{
					width: {$width}%;
				}
			}
EOL;
		}
	}
	return $style;
});

add_filter('alm_head_style',function($style){
	if(function_exists('alm_wc_get_archive_display_types')){
		$archive_display_types = alm_wc_get_archive_display_types();
		$breakpoints =['first','second','third','fourth','fifth'];
		foreach($archive_display_types as $type=>$display_value){
			$default_product_carts_customize = alm_get_option('default_shop_archive_carts_' . $type . '_customize');
			if($default_product_carts_customize){
				$count = alm_get_option('default_shop_archive_carts_' . $type . '_count');
				if($count){
					$width = (100 - max(0 , $count - 1) * 2)/$count;
					$style .= <<<EOL
					.alm-archive-products .product.{$type}{
						width: {$width}%;
					}
			EOL;
				}
			}

			foreach($breakpoints as $key){
				$archive_carts_show_breakpoint = alm_get_option('shop_archive_carts_' . $type . '_show_' . $key . '_breakpoint');
				if($archive_carts_show_breakpoint){
					$count = alm_get_option('shop_archive_carts_' . $type . '_' . $key . '_breakpoint_count');
					$breakpoint = alm_get_option('shop_archive_carts_' . $type . '_' . $key . '_breakpoint_width');
					if($count && $breakpoint){
						$width = (100 - max(0 , $count - 1) * 2)/$count;
						$style .= <<<EOL
						@media (max-width: {$breakpoint}px) {
							.alm-archive-products .product.{$type}{
								width: {$width}%;
							}
						}
			EOL;
					}
				}
			}
		}
	}


	return $style;
});

add_filter('alm_head_style',function($style){
	$customize_padding = alm_get_option('post_content_default_customize_padding');
	if($customize_padding){
		$padding = alm_get_option('post_content_default_padding');
		if($padding && isset($padding['top']) && isset($padding['right']) && isset($padding['bottom']) && isset($padding['left'])){
			$style .= <<<EOL
			.alm-post-wrapper{
				padding: {$padding['top']} {$padding['right']} {$padding['bottom']} {$padding['left']};
			}
	EOL;
		}
	}

	$breakpoints = ['first','second','third','fourth','fifth','sixth'];

	foreach($breakpoints as $key){
		$customize_padding = alm_get_option('post_content_' . $key . '_breakpoint_customize_padding');
		if($customize_padding){
			$breakpoint = alm_get_option('post_content_' . $key . '_breakpoint_width');
			$padding = alm_get_option('post_content_' . $key . '_breakpoint_padding');
			if($breakpoint && $padding && isset($padding['top']) && isset($padding['right']) && isset($padding['bottom']) && isset($padding['left'])){
				$style .= <<<EOL
				@media (max-width: {$breakpoint}px) {
					.alm-post-wrapper{
						padding: {$padding['top']} {$padding['right']} {$padding['bottom']} {$padding['left']};
					}
				}
				EOL;
			}

		}
	}


	return $style;
});

add_filter('alm_head_style',function($style){
	$content_box_size = alm_get_option('content_box_size');
	if($content_box_size){
		$inner_content_width = alm_get_option('inner_content_width');
		if($inner_content_width){
			$style .= ".alm-post-wrapper{max-width: min(100%, {$inner_content_width}px);}";
		}
	}
	return $style;
});

add_action('wp_head', 'alm_custom_styles');

function alm_custom_styles(){
	$style = apply_filters('alm_head_style','');
	if($style){
		?>
		<style><?php echo $style;?></style>
		<?php
	}
}

function alm_post_content_all_breakpoint_options(){
	$before_breakpoints = [
		array(
			'id'        => 'post_content_default_padding_accordion_start',
			'type'      => 'accordion',
			'title'     => esc_html__('حالت پیش فرض', 'alma-core'),
			'position'  => 'start',
		),
		array(
			'id'       => 'post_content_default_customize_padding',
			'type'     => 'switch',
			'title'    => esc_html__('تنظیم فاصله داخلی', 'alma-core'),
			'default'  => false,
		),
		array(
			'id' => 'post_content_default_padding',
			'type' => 'text',
			'data' => array(
				'top' => esc_html__('بالا', 'alma-core'),
				'left' => esc_html__('چپ', 'alma-core'),
				'bottom' => esc_html__('پایین', 'alma-core'),
				'right' => esc_html__('راست', 'alma-core')
			),
			'title'    => esc_html__('فاصله داخلی', 'alma-core'),
			'required' => array( 'post_content_default_customize_padding', '=', true ),
			'default' => array(
				'top' => "0px",
				'left' => "0px",
				'bottom' => "0px",
				'right' => "0px"
			),
		),
		array(
			'id'        => 'post_content_default_padding_accordion_end',
			'type'      => 'accordion',
			'position'  => 'end'
		),
	];

	return array_merge(
		$before_breakpoints,
		alm_post_content_breakpoint_options('first',esc_html__('نقطه شکست 1', 'alma-core')),
		alm_post_content_breakpoint_options('second',esc_html__('نقطه شکست 2', 'alma-core')),
		alm_post_content_breakpoint_options('third',esc_html__('نقطه شکست 3', 'alma-core')),
		alm_post_content_breakpoint_options('fourth',esc_html__('نقطه شکست 4', 'alma-core')),
		alm_post_content_breakpoint_options('fifth',esc_html__('نقطه شکست 5', 'alma-core')),
		alm_post_content_breakpoint_options('sixth',esc_html__('نقطه شکست 6', 'alma-core')),
	);
}

function alm_post_content_breakpoint_options($key,$title){
	return [
		array(
			'id'        => 'post_content_' . $key . '_breakpoint_padding_accordion_start',
			'type'      => 'accordion',
			'title'     => $title,
			'position'  => 'start',
		),
		array(
			'id'       => 'post_content_' . $key . '_breakpoint_customize_padding',
			'type'     => 'switch',
			'title'    => esc_html__('تنظیم فاصله داخلی', 'alma-core'),
			'default'  => false,
		),
		array(
			'id' => 'post_content_' . $key . '_breakpoint_width',
			'type' => 'text',
			'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
			'required' => array( 'post_content_' . $key . '_breakpoint_customize_padding', '=', true ),
		),
		array(
			'id' => 'post_content_' . $key . '_breakpoint_padding',
			'type' => 'text',
			'data' => array(
				'top' => esc_html__('بالا', 'alma-core'),
				'right' => esc_html__('راست', 'alma-core'),
				'bottom' => esc_html__('پایین', 'alma-core'),
				'left' => esc_html__('چپ', 'alma-core'),
			),
			'title'    => esc_html__('فاصله داخلی', 'alma-core'),
			'required' => array( 'post_content_' . $key . '_breakpoint_customize_padding', '=', true ),
			'default' => array(
				'top' => "0px",
				'left' => "0px",
				'bottom' => "0px",
				'right' => "0px"
			),
		),
		array(
			'id'        => 'post_content_' . $key . '_breakpoint_padding_accordion_end',
			'type'      => 'accordion',
			'position'  => 'end'
		),
	];
}

function alm_show_archive_product_grid_options($type,$title){
	$before_breakpoints_options = [
		array(
			'id'        => 'default_shop_archive_carts_' . $type . '_accordion_start',
			'type'      => 'accordion',
			'title'     => $title,
			'position'  => 'start',
		),
	];
	if(in_array($type,['type1','type3','type4','type5'])){
		$before_breakpoints_options[]= 		array(
			'id'       => 'show_add_to_wishlist_' . $type . '_archive_carts',
			'type'     => 'switch',
			'title'    => esc_html__('نمایش افزودن به علاقه‌مندی‌ها', 'alma-core'),
			'default'  => false,
		);
	}
	if($type == 'type3'){
		$before_breakpoints_options[]= array(
			'id' => 'archive_product_type3_attributes',
			'type' => 'select',
			'title'    => esc_html__('کدام ویژگی های محصول نمایش داده شود؟', 'alma-core'),
			'multi' => true,
			'options'=>alm_wc_product_attributes_list()
		);
	}

	$before_breakpoints_options = array_merge($before_breakpoints_options,[
		array(
			'id'       => 'default_shop_archive_carts_' . $type . '_customize',
			'type'     => 'switch',
			'title'    => esc_html__('تنظیم تعداد کارت در ردیف', 'alma-core'),
			'default'  => false,
		),
		array(
			'id'       => 'default_shop_archive_carts_' . $type . '_count',
			'type'     => 'text',
			'validate' => array( 'numeric', 'not_empty' ),
			'title'    => esc_html__('تعداد کارت', 'alma-core'),
			'required' => array( 'default_shop_archive_carts_' . $type . '_customize', '=', true )
		),
	]);
	$breakpoints_options = array_merge(
		alm_show_archive_product_grid_options_on_breakpoint($type,'first',esc_html__('فعالسازی نقطه شکست 1', 'alma-core')),
		alm_show_archive_product_grid_options_on_breakpoint($type,'second',esc_html__('فعالسازی نقطه شکست 2', 'alma-core')),
		alm_show_archive_product_grid_options_on_breakpoint($type,'third',esc_html__('فعالسازی نقطه شکست 3', 'alma-core')),
		alm_show_archive_product_grid_options_on_breakpoint($type,'fourth',esc_html__('فعالسازی نقطه شکست 4', 'alma-core')),
		alm_show_archive_product_grid_options_on_breakpoint($type,'fifth',esc_html__('فعالسازی نقطه شکست 5', 'alma-core')),
	);
	$after_breakpoints_options = [
		array(
			'id'        => 'default_shop_archive_carts_' . $type . '_accordion_end',
			'type'      => 'accordion',
			'position'  => 'end'
		),
	];

	return array_merge($before_breakpoints_options,$breakpoints_options,$after_breakpoints_options);
}

function alm_show_archive_product_grid_options_on_breakpoint($type,$key,$title){
	return [
		array(
			'id'       => 'shop_archive_carts_' . $type . '_show_' . $key . '_breakpoint',
			'type'     => 'switch',
			'title'    => $title,
			'default'  => false,
		),
		array(
			'id'       => 'shop_archive_carts_' . $type . '_' . $key . '_breakpoint_count',
			'type'     => 'text',
			'validate' => array( 'numeric' ),
			'title'    => esc_html__('تعداد کارت', 'alma-core'),
			'required' => array( 'shop_archive_carts_' . $type . '_show_' . $key . '_breakpoint', '=', true )
		),
		array(
			'id'       => 'shop_archive_carts_' . $type . '_' . $key . '_breakpoint_width',
			'type'     => 'text',
			'validate' => array( 'numeric' ),
			'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
			'required' => array( 'shop_archive_carts_' . $type . '_show_' . $key . '_breakpoint', '=', true )
		),
	];
}
