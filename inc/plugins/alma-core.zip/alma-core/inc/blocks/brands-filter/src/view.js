/**
 * Use this file for JavaScript code that you want to run in the front-end
 * on posts/pages that contain this block.
 *
 * When this file is defined as the value of the `viewScript` property
 * in `block.json` it will be enqueued on the front end of the site.
 *
 * Example:
 *
 * ```js
 * {
 *   "viewScript": "file:./view.js"
 * }
 * ```
 *
 * If you're not making any changes to this file because your project doesn't need any
 * JavaScript running in the front-end, then you should delete this file and remove
 * the `viewScript` property from `block.json`.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-metadata/#view-script
 */

/* eslint-disable no-console */
document.addEventListener('DOMContentLoaded', function() {
	const blocks = document.querySelectorAll('.wp-block-alm-brands-filter');
	blocks.forEach((block) => {
		const itemCount = block.getAttribute('data-item-count');
		const hideEmpty = block.getAttribute('data-hide-empty');

		const currentUrl = new URL(window.location.href);
		const activeBrand = currentUrl.searchParams.get('brand');

		fetch(`${wpApiSettings.root}alm/v1/brands?hide_empty=${hideEmpty?1:0}&item_count=${itemCount}`)
			.then((response) => {
				if (!response.ok) {
					throw new Error('Network response was not ok');
				}
				return response.json();
			})
			.then((brands) => {
				const brandList = brands.map((brand) => {
					const brandElement = document.createElement('div');
					brandElement.className = 'alm-brand-item';
					brandElement.innerHTML = '';

					if (brand.brand_svg) {
						brandElement.innerHTML += `<div class="alm-brand-logo-container">${brand.brand_svg}</div>`;
					}

					brandElement.innerHTML += `<h4 class="alm-brand-title">${brand.name}</h4>`;

					if (brand.slug === activeBrand) {
						brandElement.classList.add('alm-brand-active');
					}

					brandElement.addEventListener('click', () => {
						filterProductsByBrand(brand.slug,brandElement);
					});

					return brandElement;
				});
				block.innerHTML = '';
				brandList.forEach((brandElement) => block.appendChild(brandElement));
			})
			.catch((error) => {
				console.error('Error fetching posts:', error);
			});
	});
});

function filterProductsByBrand(brandId,brandElement) {
	const currentUrl = new URL(window.location.href);
	const activeBrand = currentUrl.searchParams.get('brand'); // Get the active brand from the URL

	if (activeBrand === brandId) {
		// If the clicked brand is already active, remove it from the URL
		currentUrl.searchParams.delete('brand');
		brandElement.classList.remove('alm-brand-active'); // Remove the active class
	} else {
		// If it's not active, set it as the active filter
		currentUrl.searchParams.set('brand', brandId);
		brandElement.classList.add('alm-brand-active'); // Add the active class
	}

	window.location.href = currentUrl.toString();

}

/* eslint-enable no-console */
