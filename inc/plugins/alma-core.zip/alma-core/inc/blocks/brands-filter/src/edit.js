/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import {__} from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import {InspectorControls} from '@wordpress/block-editor';
import { PanelBody,ToggleControl,RangeControl } from '@wordpress/components';
import { Fragment, useEffect, useState } from '@wordpress/element';




/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @return {Element} Element to render.
 */
export default function Edit(props) {
	const { attributes:{itemCount,hideEmpty},setAttributes } = props;

	const [brands, setBrands] = useState([]);

	useEffect(() => {
		const fetchBrands = async () => {
			const response = await fetch(`${wpApiSettings.root}alm/v1/brands?hide_empty=${hideEmpty?1:0}&item_count=${itemCount}`);
			if (!response.ok) {
				console.error('Error fetching brands:', response.statusText);
				return;
			}
			const data = await response.json();
			setBrands(data);
		};

		fetchBrands();
	}, [itemCount, hideEmpty]); // Run fetch when itemCount or hideEmpty changes

	return (
		<Fragment>
			<InspectorControls>
				<PanelBody title={__('تنظیمات', 'alma-core')} initialOpen={true}>
					<ToggleControl
                            label={__('برندهای خالی را نشان نده', 'alma-core')}
                            checked={hideEmpty}
                            onChange={(value) => setAttributes({ hideEmpty: value })}
                        />
					<RangeControl
						label={__('تعداد برندها', 'alma-core')}
						value={itemCount}
						onChange={(newCount) => setAttributes({ itemCount: newCount })}
						min={1}
						max={60}
					/>
				</PanelBody>
			</InspectorControls>
			<Fragment>
				{brands && brands.length > 0 ? (
					brands.map((brand) => (
						<div className='alm-brand-item' key={brand.id}>
							{brand.brand_svg && <div className='alm-brand-logo-container' dangerouslySetInnerHTML={{ __html: brand.brand_svg }} />}
							<h4 className='alm-brand-title'>{brand.name}</h4>
						</div>
					))
				) : (
					<Fragment>{__('برندی جهت نمایش وجود ندارد.', 'alma-core')}</Fragment>
				)}
			</Fragment>
		</Fragment>
	);
}
