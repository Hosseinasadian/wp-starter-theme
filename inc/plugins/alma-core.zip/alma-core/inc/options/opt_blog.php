<?php
Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('وبلاگ', 'alma-core'),
		'id' => 'blog',
		'icon' => 'dashicons dashicons-admin-post',
	)
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('صفحه تکی', 'alma-core'),
		'id' => 'blog_single_page',
		'icon' => '',
		'subsection' => true,
		'fields' => array(
			array(
				'id' => 'post_metas_start',
				'type' => 'section',
				'title' => esc_html__('داده‌های متای نوشته', 'alma-core'),
				'indent' => true
			),
			array(
				'id'       => 'post_date_meta_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('تاریخ', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'post_date_comments_count_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('تعداد دیدگاه', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'post_date_author_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('نویسنده', 'alma-core'),
				'default'  => true,
			),
			 array(
				'id'     => 'post_metas_end',
				'type'   => 'section',
				'indent' => false,
			 ),

			 array(
				'id' => 'post_social_like_start',
				'type' => 'section',
				'title' => esc_html__('اشتراک گذاری و لایک نوشته', 'alma-core'),
				'indent' => true
			),
			array(
				'id'       => 'post_date_before_social_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('تاریخ', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'post_share_socials',
				'type'     => 'select',
				'multi'    => true,
				'sortable'    => true,
				'title'    => esc_html__('شبکه های اجتماعی جهت اشتراک ‌گذاری مقاله', 'alma-core'),
				'options'  => array(
					'instagram' => esc_html__('اینستاگرام', 'alma-core'),
					'whatsapp' => esc_html__('واتس‌اپ', 'alma-core'),
					'facebook' => esc_html__('فیسبوک', 'alma-core'),
					'telegram' => esc_html__('تلگرام', 'alma-core'),
				),
				'default'  => [],
			),
			array(
				'id'       => 'post_like_after_social_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('لایک و دیسلایک نوشته', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'     => 'post_social_like_end',
				'type'   => 'section',
				'indent' => false,
			 ),

			array(
				'title' => esc_html__('نمایش قالب بعد از محتوای پست', 'alma-core'),
				'id' => 'blog_after_content',
				'type' => 'select',
				'options' => alm_elementor_template(),
			),
		)
	)
);


Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('صفحات آرشیو', 'alma-core'),
		'id' => 'blog_archive_page',
		'icon' => '',
		'subsection' => true,
		'fields' => array(
			array(
				'id' => 'blog_title',
				'type' => 'text',
				'title' => __('عنوان صفحه وبلاگ', 'alma-core'),
				'default'=>'آرشیو مقاله'
			),
			array(
				'id'   => 'blog_archive_grid_title',
				'type' => 'info',
				'style' => 'warning',
				'title' => esc_html__('گریدبندی کارتهای نوشته', 'alma-core'),
				'desc'  => esc_html__( 'میتوانید تعداد کارت‌های نوشته در صفحات آرشیو را در نقاط شکست دلخواه تنظیم کنید.', 'alma-core')
			),
            array(
                'id'        => 'default_blog_carts_accordion_start',
                'type'      => 'accordion',
                'title'     => esc_html__('حالت پیش فرض', 'alma-core'),
                'position'  => 'start',
                ),
			array(
				'id'       => 'default_blog_carts_customize',
				'type'     => 'switch',
				'title'    => esc_html__('سفارشی سازی', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'default_blog_carts_count',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('تعداد کارت', 'alma-core'),
				'required' => array( 'default_blog_carts_customize', '=', true )
			),
            array(
                'id'        => 'default_blog_carts_accordion_end',
                'type'      => 'accordion',
                'position'  => 'end'
            ),

            array(
                'id'        => 'blog_carts_show_first_breakpoint_accordion_start',
                'type'      => 'accordion',
                'title'     => esc_html__('نقطه شکست 1', 'alma-core'),
                'position'  => 'start',
                ),
			array(
				'id'       => 'blog_carts_show_first_breakpoint',
				'type'     => 'switch',
				'title'    => esc_html__('سفارشی سازی', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'blog_carts_first_breakpoint_count',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('تعداد کارت', 'alma-core'),
				'required' => array( 'blog_carts_show_first_breakpoint', '=', true )
			),
			array(
				'id'       => 'blog_carts_first_breakpoint_width',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
				'required' => array( 'blog_carts_show_first_breakpoint', '=', true )
			),
			array(
				'id'        => 'blog_carts_show_first_breakpoint_accordion_end',
				'type'      => 'accordion',
				'position'  => 'end'
			),

			array(
                'id'        => 'blog_carts_show_second_breakpoint_accordion_start',
                'type'      => 'accordion',
                'title'     => esc_html__('نقطه شکست 2', 'alma-core'),
                'position'  => 'start',
                ),
			array(
				'id'       => 'blog_carts_show_second_breakpoint',
				'type'     => 'switch',
				'title'    => esc_html__('سفارشی سازی', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'blog_carts_second_breakpoint_count',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('تعداد کارت', 'alma-core'),
				'required' => array( 'blog_carts_show_second_breakpoint', '=', true )
			),
			array(
				'id'       => 'blog_carts_second_breakpoint_width',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
				'required' => array( 'blog_carts_show_second_breakpoint', '=', true )
			),
			array(
				'id'        => 'blog_carts_show_second_breakpoint_accordion_end',
				'type'      => 'accordion',
				'position'  => 'end'
			),

			array(
                'id'        => 'blog_carts_show_third_breakpoint_accordion_start',
                'type'      => 'accordion',
                'title'     => esc_html__('نقطه شکست 3', 'alma-core'),
                'position'  => 'start',
                ),
			array(
				'id'       => 'blog_carts_show_third_breakpoint',
				'type'     => 'switch',
				'title'    => esc_html__('سفارشی سازی', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'blog_carts_third_breakpoint_count',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('تعداد کارت', 'alma-core'),
				'required' => array( 'blog_carts_show_third_breakpoint', '=', true )
			),
			array(
				'id'       => 'blog_carts_third_breakpoint_width',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
				'required' => array( 'blog_carts_show_third_breakpoint', '=', true )
			),
			array(
				'id'        => 'blog_carts_show_third_breakpoint_accordion_end',
				'type'      => 'accordion',
				'position'  => 'end'
			),

			array(
                'id'        => 'blog_carts_show_fourth_breakpoint_accordion_start',
                'type'      => 'accordion',
                'title'     => esc_html__('نقطه شکست 4', 'alma-core'),
                'position'  => 'start',
                ),
			array(
				'id'       => 'blog_carts_show_fourth_breakpoint',
				'type'     => 'switch',
				'title'    => esc_html__('سفارشی سازی', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'blog_carts_fourth_breakpoint_count',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('تعداد کارت', 'alma-core'),
				'required' => array( 'blog_carts_show_fourth_breakpoint', '=', true )
			),
			array(
				'id'       => 'blog_carts_fourth_breakpoint_width',
				'type'     => 'text',
				'validate' => array( 'numeric', 'not_empty' ),
				'title'    => esc_html__('عرض نقطه شکست', 'alma-core'),
				'required' => array( 'blog_carts_show_fourth_breakpoint', '=', true )
			),
			array(
				'id'        => 'blog_carts_show_fourth_breakpoint_accordion_end',
				'type'      => 'accordion',
				'position'  => 'end'
			),
		),
	)
);
