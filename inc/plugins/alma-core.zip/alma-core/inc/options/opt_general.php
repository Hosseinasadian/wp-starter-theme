<?php

$templates = alm_elementor_template();

Redux::set_section(
    'alma_options',
    array(
        'title' => esc_html__('عمومی', 'alma-core'),
        'id' => 'general',
        'icon' => 'el el-home',
        'fields' => array(		)
    )
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('تنظیمات کلی', 'alma-core'),
		'id' => 'general_primary_settings',
		'icon' => '',
		'subsection' => true,
        'fields' => array(
			array(
				'id' => 'content_width',
				'type' => 'slider',
				'title' => __('عرض سایت', 'alma-core'),
				'subtitle' => __('عرض سایت را انتخاب کنید', 'alma-core'),
				"default" => 1216,
				"min" => 700,
				"step" => 1,
				"max" => 2000,
				'display_value' => 'text'
			),
			array(
				'id'       => 'breadcrumb_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('نمایش راهنمای صفحات', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'otp_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('ورود و ثبت نام با رمز یکبار مصرف', 'alma-core'),
				'default'  => true,
			),
			array(
                'id'=>'otp_email_subject',
                'title'    => esc_html__('موضوع ایمیل', 'pezeshkyar-core'),
                'type'=>'textarea',
                "default" => "کد تایید جهت ورود به {site_title}",
                'required' => array( 'otp_enabled', '=', true ),
            ),
            array(
                'id'=>'otp_email_text',
                'title'    => esc_html__('متن ایمیل', 'pezeshkyar-core'),
                'type'=>'textarea',
                "default" => "کد تایید: {code}",
                'required' => array( 'otp_enabled', '=', true ),
            ),
            array(
                'id'=>'otp_mobile_text',
                'title'    => esc_html__('متن پیامک', 'pezeshkyar-core'),
                'type'=>'textarea',
                "default" => "کد تایید: {code}",
                'required' => array( 'otp_enabled', '=', true ),
            ),
            array(
				'id'       => 'otp_type',
				'type'     => 'select',
				'title'    => esc_html__('نحوه ورود', 'pezeshkyar-core'),
				'default'  => 'both',
                'options'  => array(
                    'both' => esc_html__('ایمیل یا موبایل', 'pezeshkyar-core'),
                    'email' => esc_html__('ایمیل', 'pezeshkyar-core'),
                    'mobile' => esc_html__('موبایل', 'pezeshkyar-core')
                ),
                'required' => array( 'otp_enabled', '=', true ),
			),
			array(
				'id'       => 'otp_modal_logo',
				'type'     => 'media',
				'title'    => esc_html__('لوگوی پاپ‌آپ ورود با رمز یکبار مصرف', 'alma-core'),
				'required' => array( 'otp_enabled', '=', true ),

			),
		)
	)
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('محتوا', 'alma-core'),
		'id' => 'general_content_settings',
		'icon' => '',
		'subsection' => true,
		'fields' => array_merge(
			array(
				array(
					'id'       => 'content_box_size',
					'type'     => 'switch',
					'title'    => esc_html__('محدود کردن عرض محتوا', 'alma-core'),
					'default'  => false,
				),
				array(
					'id' => 'inner_content_width',
					'type' => 'slider',
					'title' => __('عرض محتوای سایت', 'alma-core'),
					'subtitle' => __('عرض محتوای سایت را انتخاب کنید', 'alma-core'),
					"default" => 1114,
					"min" => 700,
					"step" => 1,
					"max" => 2000,
					'display_value' => 'text',
					'required' => array( 'content_box_size', '=', true )
				),
				array(
					'id'   => 'inner_content_title',
					'type' => 'info',
					'style' => 'warning',
					'title' => esc_html__('فاصله داخلی محتوای سایت', 'alma-core'),
					'desc'  => esc_html__( 'این فاصله را متناسب با فاصله داخلی هدر و فوتر میتوانید در نقاط شکست دلخواه تنظیم کنید.', 'alma-core')
				),
			),
			alm_post_content_all_breakpoint_options()
		)
	)
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('هدر', 'alma-core'),
		'id' => 'alma_header_settings',
		'icon' => '',
		'subsection' => true,
        'fields' => array(
			array(
				'id'       => 'header_type',
				'type'     => 'radio',
				'title'    => esc_html__('نوع هدر', 'alma-core'),
				'data'  => array(
					'default' => esc_html__('پیش فرض', 'alma-core'),
					'elementor' => esc_html__('المنتوری', 'alma-core'),
				),
				'default' => 'default'
			),
			array(
				'title' => esc_html__('انتخاب هدر', 'pezeshkyar-core'),
				'id' => 'alm_header_template',
				'type' => 'select',
				'options' => $templates,
				'required' => array( 'header_type', '=', 'elementor' )
			),
			array(
				'id'       => 'header_desktop_logo',
				'type'     => 'media',
				'title'    => esc_html__('لوگوی دسکتاپ', 'alma-core'),
				'required' => array( 'header_type', '=', 'default' )
			),
			array(
				'id' => 'header_phone_part1',
				'type' => 'text',
				'title' => __('بخش اول شماره تلفن', 'alma-core'),
				'default'=>'',
				'required' => array( 'header_type', '=', 'default' )
			),
			array(
				'id' => 'header_phone_part2',
				'type' => 'text',
				'title' => __('بخش دوم شماره تلفن', 'alma-core'),
				'default'=>'',
				'required' => array( 'header_type', '=', 'default' )
			),
			array(
				'id'=>'header_support_text',
				'type' => 'text',
				'title' => __('بخش دوم شماره تلفن', 'alma-core'),
				'default'=>esc_html__('همین حالا با پشتیبانی ما تماس بگیر','alma-core'),
				'required' => array( 'header_type', '=', 'default' )
			),
			array(
				'id'       => 'header_mobile_logo',
				'type'     => 'media',
				'title'    => esc_html__('لوگوی موبایل', 'alma-core'),
				'required' => array( 'header_type', '=', 'default' )
			),
		)
	)
);
Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('فوتر', 'alma-core'),
		'id' => 'alma_footer_settings',
		'icon' => '',
		'subsection' => true,
        'fields' => array(
			array(
				'id'       => 'footer_type',
				'type'     => 'radio',
				'title'    => esc_html__('نوع فوتر', 'alma-core'),
				'data'  => array(
					'default' => esc_html__('پیش فرض', 'alma-core'),
					'elementor' => esc_html__('المنتوری', 'alma-core'),
				),
				'default' => 'default'
			),
			array(
				'title' => esc_html__('انتخاب فوتر', 'pezeshkyar-core'),
				'id' => 'alm_footer_template',
				'type' => 'select',
				'options' => $templates,
				'required' => array( 'footer_type', '=', 'elementor' )
			),
			array(
				'id'       => 'footer_logo',
				'type'     => 'media',
				'title'    => esc_html__('لوگو', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_introduction',
				'type' => 'textarea',
				'title' => __('معرفی کسب و کار', 'alma-core'),
				'default'=>esc_html__('یک معرفی کوتاه از کسب و کار خود بنویسید.','alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_list_1_title',
				'type' => 'text',
				'title' => __('عنوان منوی اول', 'alma-core'),
				'default'=>esc_html__('دسترسی سریع', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id'       => 'footer_list_1_icon',
				'type'     => 'media',
				'title'    => esc_html__('آیکن منوی اول', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_list_1_items',
				'type' => 'repeater',
				'group_values'=>true,
				'title' => __('آیتم های منو را وارد کنید', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' ),
				'fields'         => array(
			       array(
                        'id'          => 'link_title',
                        'type'        => 'text',
                        'placeholder' => esc_html__( 'عنوان آیتم', 'alma-core' ),
                    ),
					array(
                        'id'          => 'link_href',
                        'type'        => 'text',
						'validate' => array('url'),
                        'placeholder' => esc_html__( 'لینک آیتم', 'alma-core' ),
                    ),
				)
			),
			array(
				'id' => 'footer_list_2_title',
				'type' => 'text',
				'title' => __('عنوان منوی دوم', 'alma-core'),
				'default'=>esc_html__('دسته بندی ها', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id'       => 'footer_list_2_icon',
				'type'     => 'media',
				'title'    => esc_html__('آیکن منوی دوم', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_list_2_items',
				'type' => 'repeater',
				'group_values'=>true,
				'title' => __('آیتم های منو را وارد کنید', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' ),
				'fields'         => array(
			       array(
                        'id'          => 'link_title',
                        'type'        => 'text',
                        'placeholder' => esc_html__( 'عنوان آیتم', 'alma-core' ),
                    ),
					array(
                        'id'          => 'link_href',
                        'type'        => 'text',
						'validate' => array('url'),
                        'placeholder' => esc_html__( 'لینک آیتم', 'alma-core' ),
                    ),
				)
			),
			array(
				'id' => 'footer_socials_title',
				'type' => 'text',
				'title' => __('عنوان شبکه های اجتماعی', 'alma-core'),
				'default'=>esc_html__('ما را در شبکه های اجتماعی دنبال کنید', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_socials_list',
				'type' => 'repeater',
				'group_values'=>true,
				'title' => __('لیست شبکه های اجتماعی را وارد کنید', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' ),
				'fields'         => array(
					array(
                        'id'          => 'social_icon',
                        'type'        => 'select',
						'options' => array(
							'instagram'=>esc_html__('اینستاگرام','alma-core'),
							'youtube'=>esc_html__('یوتیوب','alma-core'),
							'whatsapp'=>esc_html__('واتس‌اپ','alma-core'),
							'facebook'=>esc_html__('فیسبوک','alma-core'),
							'google'=>esc_html__('گوگل','alma-core'),
							'other'=>esc_html__('سفارشی','alma-core'),
						),
                        'title' => esc_html__( 'آیکن', 'alma-core' ),
                    ),
					array(
						'id' => 'social_custom_icon',
						'type' => 'textarea',
						'title' => __('کد svg', 'alma-core'),
						'required' => array( 'social_icon', '=', 'other' )
					),
					array(
                        'id'          => 'social_link',
                        'type'        => 'text',
                        'placeholder' => esc_html__( 'لینک', 'alma-core' ),
                    ),
				)
			),

			array(
				'id' => 'footer_newsletter_title',
				'type' => 'text',
				'title' => __('عنوان خبرنامه', 'alma-core'),
				'default'=>esc_html__('خبرنامه', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),

			array(
				'id' => 'footer_copyright',
				'type' => 'textarea',
				'title' => __('متن کپی‌رایت', 'alma-core'),
				'default'=>esc_html__('تمامی حقوق این وبسایت متعلق به آلما می باشد','alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_address1',
				'type' => 'text',
				'title' => __('آدرس اول', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_address2',
				'type' => 'text',
				'title' => __('آدرس دوم', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_phone',
				'type' => 'text',
				'title' => __('شماره تماس', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
			array(
				'id' => 'footer_phone_text',
				'type' => 'text',
				'title' => __('متن پایین شماره تماس', 'alma-core'),
				'required' => array( 'footer_type', '=', 'default' )
			),
		)
	)
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('404', 'alma-core'),
		'id' => '404_settings',
		'icon' => '',
		'subsection' => true,
		'fields' =>array(
			array(
				'id'       => '404_image',
				'type'     => 'media',
				'title'    => esc_html__('تصویر 404', 'alma-core'),
			),
			array(
				'id' => '404_message',
				'type' => 'text',
				'title' => __('پیام خطا', 'alma-core'),
				'default'=>''
			),
			array(
				'id'       => '404_show_prev_button',
				'type'     => 'switch',
				'title'    => esc_html__('دکمه صفحه قبلی نشان داده شود؟', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => '404_show_home_button',
				'type'     => 'switch',
				'title'    => esc_html__('دکمه صفحه اصلی نشان داده شود؟', 'alma-core'),
				'default'  => true,
			),
		)
	)
);
