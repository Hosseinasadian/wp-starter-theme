<?php
// Color option
Redux::set_section('alma_options', array(
    'title' => esc_html__('رنگ بندی', 'alma-core'),
    'id' => 'color',
    'icon' => 'dashicons dashicons-admin-appearance',
    'fields' => array()
));

Redux::set_section('alma_options', array(
    'title' => esc_html__('رنگ اصلی', 'alma-core'),
    'id' => 'alm_primary_opt',
    'icon' => '',
    'subsection' => true,
    'fields' => array(
		array(
            'id' => 'color-primary300',
            'type' => 'color',
            'title' => esc_html__('وزن 300', 'alma-core'),
            'output_variables' => true,
            'default' => '#373254',
        ),
		array(
            'id' => 'color-primary200',
            'type' => 'color',
            'title' => esc_html__('وزن 200', 'alma-core'),
            'output_variables' => true,
            'default' => '#C1B6DE',
        ),
		array(
            'id' => 'color-primary100',
            'type' => 'color',
            'title' => esc_html__('وزن 100', 'alma-core'),
            'output_variables' => true,
            'default' => '#F1E4F0',
        ),
	)
));

Redux::set_section('alma_options', array(
    'title' => esc_html__('رنگ ثانویه', 'alma-core'),
    'id' => 'alm_secondary_opt',
    'icon' => '',
    'subsection' => true,
    'fields' => array(
        array(
            'id' => 'color-secondary300',
            'type' => 'color',
            'title' => esc_html__('وزن 300', 'alma-core'),
            'output_variables' => true,
            'default' => '#F5683C',
        ),
		array(
            'id' => 'color-secondary200',
            'type' => 'color',
            'title' => esc_html__('وزن 200', 'alma-core'),
            'output_variables' => true,
            'default' => '#F9A48A',
        ),
		array(
            'id' => 'color-secondary100',
            'type' => 'color',
            'title' => esc_html__('وزن 100', 'alma-core'),
            'output_variables' => true,
            'default' => '#FDE1D8',
        )
	)
));
