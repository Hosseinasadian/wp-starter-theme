<?php
if (!class_exists('Redux')) {
    return;
}

$opt_name = 'alma_options';

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    'display_name' => $theme->get('Name'),
    'display_version' => $theme->get('Version'),
    'menu_title' => esc_html__('تنطیمات قالب', 'alma-core'),
    'page_title' => esc_html__('تنطیمات قالب', 'alma-core'),
    'page_priority'=>2,
    'customizer' => true,
    'footer_credit'=>esc_html__('قالب آلما', 'alma-core'),
);

Redux::set_args($opt_name, $args);

require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/options/opt_general.php';
require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/options/opt_typo.php';
require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/options/opt_color.php';
require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/options/opt_blog.php';
require_once trailingslashit(ALMA_CORE_ROOT) . 'inc/options/opt_shop.php';
