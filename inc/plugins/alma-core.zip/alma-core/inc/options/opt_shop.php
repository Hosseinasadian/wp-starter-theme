<?php


Redux::set_section('alma_options', array(
    'title' => esc_html__('فروشگاه', 'alma-core'),
    'id' => 'shop',
    'icon' => 'dashicons dashicons-cart',
));

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('عمومی', 'alma-core'),
		'id' => 'shop_general_settings',
		'icon' => '',
		'subsection' => true,
		'fields' => array(
			array(
				'id'          => 'zero_price_text',
				'title' => esc_html__('برای قیمت صفر متن دلخواه تنظیم کنید.','alma-core'),
				'type'        => 'text',
				'default' => esc_html__( 'رایگان', 'alma-core' ),
			),
			array(
				'id'          => 'no_price_text',
				'title' => esc_html__('در صورتی که قیمت تنظیم نشده متن دلخواه تنظیم کنید.','alma-core'),
				'type'        => 'text',
				'default' => esc_html__( 'تماس بگیرید', 'alma-core' ),
			),
		)
	)
);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('صفحه تکی', 'alma-core'),
		'id' => 'shop_single_page',
		'icon' => '',
		'subsection' => true,
		'fields' => array(
			array(
				'id' => 'product_images_start',
				'type' => 'section',
				'title' => esc_html__('تصویر محصول', 'alma-core'),
				'indent' => true
			),
			array(
				'id'       => 'product_gallery_full_size',
				'type'     => 'switch',
				'title'    => esc_html__('نمایش تصویر کامل', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'product_gallery_zoom_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('بزرگنمایی تصویر', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'product_gallery_lightbox_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('نمایش لایت‌باکس', 'alma-core'),
				'default'  => false,
			),
			array(
				'id'       => 'product_gallery_slider_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('اسلایدر تصاویر', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'     => 'product_images_end',
				'type'   => 'section',
				'indent' => false,
			 ),

			array(
				'id' => 'product_metas_start',
				'type' => 'section',
				'title' => esc_html__('داده‌های متای محصول', 'alma-core'),
				'indent' => true
			),
			array(
				'id'       => 'product_category_meta_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('دسته بندی', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'product_brand_meta_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('برند', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'       => 'product_rate_meta_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('امتیاز', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'     => 'product_metas_end',
				'type'   => 'section',
				'indent' => false,
			 ),

			 array(
				'id' => 'product_sell_info_start',
				'type' => 'section',
				'title' => esc_html__('اطلاعات تکمیلی محصول', 'alma-core'),
				'indent' => true
			),
			array(
				'id'       => 'product_sell_info_shipping_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('کلاس حمل و نقل', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'             => 'shipping_classes_settings',
				'type'           => 'repeater',
				'group_values'=>true,
				'title'    => esc_html__('کلاس های حمل و نقل', 'alma-core'),
				'fields'         => array(
					array(
						'id'          => 'slug',
						'type'        => 'text',
						'placeholder' => esc_html__( 'نامک کلاس حمل و نقل', 'alma-core' ),
					),
					array(
						'id'       => 'icon',
						'type'     => 'media',
						'url'      => true,
						'title'    => esc_html__('آیکن حمل و نقل', 'alma-core')
					)
				)
			),
			array(
				'id'       => 'product_sell_info_stock_enabled',
				'type'     => 'switch',
				'title'    => esc_html__('موجود بودن محصول', 'alma-core'),
				'default'  => true,
			),
			array(
				'id'     => 'product_sell_info_end',
				'type'   => 'section',
				'indent' => false,
			 ),

			array(
				'title' => esc_html__('نمایش قالب کنار دیدگاه محصولات', 'alma-core'),
				'id' => 'template_beside_product_reviews',
				'type' => 'select',
				'options' => alm_elementor_template(),
			),

		)
	)
	);

Redux::set_section(
	'alma_options',
	array(
		'title' => esc_html__('صفحات آرشیو', 'alma-core'),
		'id' => 'shop_archive_page',
		'icon' => '',
		'subsection' => true,
		'fields' => array_merge(
			array(
				array(
					'id'       => 'product_archive_images_full_size',
					'type'     => 'switch',
					'title'    => esc_html__('نمایش تصویر کامل', 'alma-core'),
					'default'  => false,
				),
				array(
					'id' => 'loop_shop_per_page',
					'type' => 'slider',
					'title' => esc_html__('تعداد محصولات در هر صفحه', 'alma-core'),
					"default" => 12,
					"min" => 3,
					"step" => 1,
					"max" => 50,
					'display_value' => 'text'
				),
				array(
					'id'       => 'products_display_type',
					'type'     => 'select',
					'title'    => esc_html__('نمایش پیش فرض کارت محصولات', 'alma-core'),
					'options'  => array(
						'type1' => esc_html__('آرشیو 1','alma-core'),
						'type2' => esc_html__('آرشیو 2','alma-core'),
						'type3' => esc_html__('آرشیو 3','alma-core'),
						'type4' => esc_html__('آرشیو 4','alma-core'),
						'type5' => esc_html__('آرشیو 5','alma-core'),
					),
					'default'  => 'type1',
				),
				array(
					'id'          => 'disabled_mange_stock_quantity',
					'title' => esc_html__('برای محصولاتی که مدیریت موجودی فعال نیست موجودی پیش فرض چند عدد است؟','alma-core'),
					'type'        => 'text',
					'default' => 100,
					'validate' => array( 'numeric', 'not_empty' )
				),
				array(
					'id'       => 'variant_range_price',
					'type'     => 'switch',
					'title'    => esc_html__('نمایش بازه ای قیمت محصولات متغیر', 'alma-core'),
					'default'  => false,
				),
				array(
					'id'   => 'shop_archive_grid_title',
					'type' => 'info',
					'style' => 'warning',
					'title' => esc_html__('تنظیمات کارتهای محصول', 'alma-core'),
					'desc'  => esc_html__( 'میتوانید تنظیمات کارت‌های محصول در انواع صفحات آرشیو را تنظیم کنید.', 'alma-core')
				)
			),
			alm_show_archive_product_grid_options('type1',esc_html__('آرشیو 1', 'alma-core')),
			alm_show_archive_product_grid_options('type2',esc_html__('آرشیو 2', 'alma-core')),
			alm_show_archive_product_grid_options('type3',esc_html__('آرشیو 3', 'alma-core')),
			alm_show_archive_product_grid_options('type4',esc_html__('آرشیو 4', 'alma-core')),
			alm_show_archive_product_grid_options('type5',esc_html__('آرشیو 5', 'alma-core')),
		)
	)
);
