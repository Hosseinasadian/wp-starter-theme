window.addEventListener('elementor/init', () => {

    const select2ControlView = elementor.modules.controls.BaseData.extend({
        onReady() {
            const self = this;
            const $select = this.$el.find('.elementor-control-select-post');

            const selectedPosts = self.getControlValue();

			const post_type = this.model.attributes.post_type;


            if (selectedPosts) {
                jQuery.ajax({
                    url: `${alm_select_post_object.rest_url}alm/v1/posts`,
					method: 'POST',
                    dataType: 'json',
                    data: {
                        id: Array.isArray(selectedPosts) ? selectedPosts : [selectedPosts]
                    },
                    success: function (response) {
                        if (response.posts) {
                            const posts = response.posts;

							posts.forEach(post => {
								const option = new Option(post.post_title, post.ID, true, true);
								$select.append(option);
							});

							// Trigger change to update Select2
							$select.trigger('change');
                        }
                    }
                });
            }

            $select.select2({
                placeholder: alm_select_post_object.translations.select_post_placeholder,
                allowClear: true,
                ajax: {
                    url: `${alm_select_post_object.rest_url}alm/v1/posts`,
					method: 'POST',
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            search: params.term,
                            page: params.page || 1, // Page number, default to 1
							post_type: post_type
                        };
                    },
                    processResults: function (data, params) {
                        params.page = params.page || 1;

                        return {
                            results: data.results || [],
                            pagination: {
                                more: data.pagination && data.pagination.more
                            }
                        };
                    },
                    cache: true
                }
            }).on('change', function () {
                self.saveValue();
            });
        },

        saveValue() {
			const isMultiple = this.model.attributes.multiple;

            let selectedPosts = this.$el.find('.elementor-control-select-post').val();
			selectedPosts = Array.isArray(selectedPosts) ? selectedPosts : [selectedPosts];

			if(!isMultiple){
				selectedPosts = selectedPosts.slice(0, 2);
			}

            this.setValue(selectedPosts);
        },

        onBeforeDestroy() {
            this.saveValue();
            this.$el.find('.elementor-control-select-post').select2('destroy');
        }
    });

    elementor.addControlView('alm_select_post', select2ControlView);

});
