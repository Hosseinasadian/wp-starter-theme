<?php

class ALM_Select_Post extends \Elementor\Base_Data_Control{
    public function get_type()
    {
        return 'alm_select_post';
    }

    protected function get_default_settings()
    {
        return [
            'label_block' => true,
            'separator' => 'after',
            'input_type' => 'text',
            'label' => 'label',
            'title' => 'title',
            'placeholder' => 'placeholder',
            'description' => 'description',
			'multiple'=>false,
			'post_type'=>[],
        ];
    }

	public function get_default_value()
    {
        return [];
    }

    public function content_template()
    {
        $control_uid = $this->get_control_uid();
        ?>
        <div class="elementor-control-field">

			<# if ( data.label ) {#>
				<label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<# } #>


            <div class="elementor-control-input-wrapper elementor-control-select-post-wrapper">
                <select
					id="<?php echo $control_uid; ?>"
					class="elementor-control-select-post"
					<# if ( data.multiple ) {#>
						multiple="multiple"
					<# } #>
					>
				</select>
            </div>
        </div>

        <?php
    }

	public function enqueue()
    {
        // Styles
        wp_register_style('alm-select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
        wp_enqueue_style('alm-select2');


        // Scripts
        wp_register_script('alm-select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js');
        wp_enqueue_script('alm-select2');
        wp_register_script('alm-select-post', trailingslashit(ALMA_CORE_URL) . 'elementor/controls/alm-select-post.js', array('jquery', 'alm-select2'), null, true);
        wp_enqueue_script('alm-select-post');
        wp_localize_script('alm-select-post', 'alm_select_post_object', array(
            'rest_url'=>rest_url(),
            'translations' => [
				'select_post_placeholder'=>'انتخاب کنید...'
            ]
        ));
    }
}
