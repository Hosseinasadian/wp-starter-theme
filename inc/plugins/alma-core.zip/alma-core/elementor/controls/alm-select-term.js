window.addEventListener('elementor/init', () => {

    const select2ControlView = elementor.modules.controls.BaseData.extend({
        onReady() {
            const self = this;
            const $select = this.$el.find('.elementor-control-select-term');

            const selectedTerms = self.getControlValue();

			const taxonomy = this.model.attributes.taxonomy;


            if (selectedTerms) {
                jQuery.ajax({
                    url: `${alm_select_term_object.rest_url}alm/v1/terms`,
					method: 'POST',
                    dataType: 'json',
                    data: {
                        id: Array.isArray(selectedTerms) ? selectedTerms : [selectedTerms]
                    },
                    success: function (response) {
                        if (response.terms) {
                            const terms = response.terms;

							terms.forEach(term => {
								const option = new Option(term.name, term.term_id, true, true);
								$select.append(option);
							});

							// Trigger change to update Select2
							$select.trigger('change');
                        }
                    }
                });
            }

            $select.select2({
                placeholder: alm_select_term_object.translations.select_term_placeholder,
                allowClear: true,
                ajax: {
                    url: `${alm_select_term_object.rest_url}alm/v1/terms`,
					method: 'POST',
                    dataType: 'json',
                    delay: 250,
                    data: function (params) {
                        return {
                            search: params.term,
                            page: params.page || 1, // Page number, default to 1
							taxonomy: taxonomy
                        };
                    },
                    processResults: function (data, params) {
                        params.page = params.page || 1;

                        return {
                            results: data.results || [],
                            pagination: {
                                more: data.pagination && data.pagination.more
                            }
                        };
                    },
                    cache: true
                }
            }).on('change', function () {
                self.saveValue();
            });
        },

        saveValue() {
			const isMultiple = this.model.attributes.multiple;

            let selectedTerms = this.$el.find('.elementor-control-select-term').val();
			selectedTerms = Array.isArray(selectedTerms) ? selectedTerms : [selectedTerms];

			if(!isMultiple){
				selectedTerms = selectedTerms.slice(0, 2);
			}

            this.setValue(selectedTerms);
        },

        onBeforeDestroy() {
            this.saveValue();
            this.$el.find('.elementor-control-select-term').select2('destroy');
        }
    });

    elementor.addControlView('alm_select_term', select2ControlView);

});
