$(document).ready(function (){
    $('.newsletter-form').on('submit',function (e){
        e.preventDefault();
        let data = $(this).serialize();
        let messages_box = $(this).find('.alm-newsletter-message');
        data += "&action=alm_register_newsletter&security=" + alm_newsletter_obj.security
        $.ajax({
            type:'post',
            url:alm_newsletter_obj.ajax_url,
            dataType:'json',
            data:data,
            success:function (response){
                let message_html;
                if (messages_box) {
                    let messages_html = '';
                    if (response.success) {
                        message_html = `<div class="alm-success-message">${response.data}</div>`;
                    } else {
                        message_html = `<div class="alm-error-message">${response.data}</div>`;
                    }
                    messages_box.html(message_html);
                    messages_box.removeClass('alm-hide');
                }

            }
        });
    })
})
