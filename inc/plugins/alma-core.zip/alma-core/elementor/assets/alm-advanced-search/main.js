jQuery(window).on('elementor/frontend/init', function () {
	jQuery(document).click(function(){
		jQuery(document).click(function(event){
			let target = jQuery(event.target);
			let count = target.closest('.alm-advanced-search').length;
			if(count < 1){
				jQuery('.alm-search-results:not(.alm-hide)').addClass('alm-hide');
			}
		})
	});
	elementorFrontend.hooks.addAction('frontend/element_ready/alm_advanced_search.default', function ($scope) {
		let timer;
		let currentRequest = null;
		let resultsContainer = $scope.find('.alm-search-results');
		let loader_html = '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
		$scope.on('input','.alm-search-box-input',function(event){
			let el = jQuery(this);
			let searchTerm = el.val();
			timer = setTimeout(function() {
				if(searchTerm.length<1){
					return;
				}
				clearTimeout(timer);
				if (currentRequest !== null) {
                    currentRequest.abort();
                }
				currentRequest = jQuery.ajax({
					url: alm_advanced_search.ajaxurl,
					type: 'post',
					data: {
						action: 'alm_ajax_search',
						post_type: ['product'],
						search: searchTerm
					},
					beforeSend: function() {
						resultsContainer.html(loader_html);
						resultsContainer.removeClass('alm-hide');
					},
					success: function(response) {
						resultsContainer.html(response);
					},
					error: function(){
						resultsContainer.html(`<p>${alm_advanced_search.translations.failed}</p>`);
					},
					complete: function() {
						currentRequest = null;
					}
				});
			},500);
		});
		$scope.on('focus','.alm-search-box-input',function(event){
			let result_html = resultsContainer.html();
			if(result_html){
				resultsContainer.removeClass('alm-hide');
			}
		});
	})
})
