$(document).ready(function () {
    $(document).on('click', '.alm-card-button', function () {
        $(this).parent().find('.alm-minicart').toggleClass('alm-hide')
    })

    $(document).on('change', '.alm-minicart form', function (e) {
        e.preventDefault();

        let form = $(this);
        let form_data = form.serialize();
        form_data += `&action=alm_update_mini_cart&nonce=${alm_mini_crt_obj.security}`;

        $.ajax({
            type: 'POST',
            url: alm_mini_crt_obj.ajax_url,
            dataType: 'json',
            data: form_data,
			beforeSend: function() {
				$('.alm-minicart:not(.alm-loading-minicart)').each(function(index){
					let minicart = $(this);
					minicart.addClass('alm-loading-minicart');
				});
			},
            success: function (response) {
                if (response.success) {
                    let card_count = form.parent().parent().find('.card-count');
                    form.replaceWith(response.data.cart_content)
                    if (card_count){
                        card_count.html(response.data.count)
                    }
                }
            },
			complete: function() {
				$('.alm-minicart.alm-loading-minicart').each(function(index){
					let minicart = $(this);
					minicart.removeClass('alm-loading-minicart');
				});
			}
        });
    })

	function alm_update_minicart(){
		let form_data = `&action=alm_get_mini_cart_content&nonce=${alm_mini_crt_obj.security}`;
		$.ajax({
            type: 'POST',
            url: alm_mini_crt_obj.ajax_url,
            dataType: 'json',
            data: form_data,
			beforeSend: function() {
				$('.alm-minicart:not(.alm-loading-minicart)').each(function(index){
					let minicart = $(this);
					minicart.addClass('alm-loading-minicart');
				});
			},
            success: function (response) {
                if (response.success) {
					$('.alm-minicart').each(function(index){
						let minicart = $(this);
						let card_count = minicart.parent().find('.card-count');
						minicart.html(response.data.cart_content)
						if (card_count){
							card_count.html(response.data.count)
						}
					});
                }
            },
			complete: function() {
				$('.alm-minicart.alm-loading-minicart').each(function(index){
					let minicart = $(this);
					minicart.removeClass('alm-loading-minicart');
				});
			}
        });
	}

	$(document.body).on('added_to_cart',function(x,y){
		alm_update_minicart();
	});
	$(document.body).on('removed_from_cart',function(x,y){
		alm_update_minicart();
	});
})

