jQuery(window).on('elementor/frontend/init', function () {
	elementorFrontend.hooks.addAction('frontend/element_ready/alma_mobile_menu.default', function ($scope) {
		$scope.on('click','.alm-mobile-menu li a',function(event){
		let el = jQuery(this)
		if (!jQuery(event.target).closest('.alm-link-content').length) {
			event.preventDefault();
			el.closest('li').toggleClass('alm-extend-mobile-menu-item');
			// el.next('ul').toggleClass('show-sub-menu');
			// el.find('.toggle-menu-item').toggleClass('open-mode');
		}
	});

	})
})
