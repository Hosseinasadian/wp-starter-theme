jQuery(window).on('elementor/frontend/init', function () {
	elementorFrontend.hooks.addAction('frontend/element_ready/alm_comments_slider.default', function ($scope) {
		let btn_icon = `					<svg xmlns="http://www.w3.org/2000/svg" width="26" height="20" viewBox="0 0 26 20" fill="none">
						<path opacity="0.15" d="M16.8471 18.8098C21.4287 18.8098 25.1427 14.9723 25.1427 10.2384C25.1427 5.50455 21.4287 1.66699 16.8471 1.66699C12.2656 1.66699 8.55151 5.50455 8.55151 10.2384C8.55151 14.9723 12.2656 18.8098 16.8471 18.8098Z" fill="#F5683C"/>
						<path d="M10.9561 18.3337C15.6041 18.3337 19.372 14.6027 19.372 10.0003C19.372 5.39795 15.6041 1.66699 10.9561 1.66699C6.30818 1.66699 2.54028 5.39795 2.54028 10.0003C2.54028 14.6027 6.30818 18.3337 10.9561 18.3337Z" stroke="#F5683C" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M13.9017 10H8.85217" stroke="#F5683C" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M10.5353 7.5L8.0105 10L10.5353 12.5" stroke="#F5683C" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>`;

		$scope.on('click','.alm-comments-show-more',function(){
			let el = $(this);
			el.parent().find('.alm-comment-card-extra').toggleClass('alm-comment-card-extra-hide');

			if(el.is('.alm-comments-show-more-extended')){
				el.replaceWith(`<button class="alm-comments-show-more">${alm_comments_slider_object.translations.show_all}${btn_icon}</button>`);
			}else{
				el.replaceWith(`<button class="alm-comments-show-more alm-comments-show-more-extended">${alm_comments_slider_object.translations.show_less}${btn_icon}</button>`);
			}
		});

	})
})
