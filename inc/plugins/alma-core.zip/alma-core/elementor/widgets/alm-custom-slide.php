<?php
class ALM_Custom_Slide extends \Elementor\Widget_Base{
	public function get_name() {
        return 'alm_custom_slide';
    }

    public function get_title() {
        return __('اسلاید سفارشی', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-search';
    }

	public function get_categories()
    {
        return ['alma'];
    }

	public function get_keywords()
    {
        return ['alma', 'slide', 'custom'];
    }

	public function get_style_depends()
    {
        return ["alm-custom-slide"];
    }

	protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('محتوا', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
			'content_tag',
			[
				'label' => esc_html__( 'تگ محتوا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'div',
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'p' => 'p',
					'span'=>'span'
				],
			]
		);
		$this->add_control(
			'description',
			[
				'label' => esc_html__( 'توضیح', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'placeholder' => esc_html__( 'متن دلخواه خود را وارد کنید', 'alma-core' ),
			]
		);
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'انتخاب تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'style_section',
            [
                'label' => __('استایل', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'رنگ پس زمینه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default'=>'#C1B6DE',
				'selectors' => [
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-image' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description svg [fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description svg [stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-image svg [fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-image svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-image svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-image svg [stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',

				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'description_style',
            [
                'label' => __('توضیحات', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'description_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'selector' => '{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'description_ems_style',
            [
                'label' => __('بخش های متمایز متن تگ em', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'description_ems_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description em' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_ems_typography',
				'selector' => '{{WRAPPER}} .alm-custom-slide .alm-custom-slide-description em',
			]
		);

		$this->end_controls_section();
	}

	protected function render(){
		$description = $this->get_settings_for_display('description');
		$image = $this->get_settings_for_display('image');
		$content_tag = $this->get_settings_for_display('content_tag');

		?>
		<div class="alm-custom-slide">
			<div class="alm-custom-slide-description">
				<<?php echo $content_tag;?> class="alm-custom-slide-description-content"><?php echo $description;?></<?php echo $content_tag;?>>
				<svg width="36" height="37" viewBox="0 0 36 37" fill="none" xmlns="http://www.w3.org/2000/svg">
					<g clip-path="url(#clip0_8002_15155)">
					<g filter="url(#filter0_d_8002_15155)">
					<path d="M34.415 -94C34.415 -112.778 49.6373 -128 68.415 -128L1060 -128C1078.78 -128 1094 -112.778 1094 -94V1.01893C1094 19.7966 1078.78 35.0189 1060 35.0189H659.556C640.778 35.0189 625.556 50.2412 625.556 69.0189V218C625.556 236.778 610.334 252 591.556 252H528.775H25.4211H-168C-186.778 252 -202 236.778 -202 218V69.1416C-202 50.364 -186.778 35.1416 -168 35.1416H0.414984C19.1927 35.1416 34.415 19.9193 34.415 1.14163V-94Z" fill="#C1B6DE"/>
					<path d="M624.556 69.0189V218C624.556 236.225 609.781 251 591.556 251H528.775H25.4211H-168C-186.225 251 -201 236.225 -201 218V69.1416C-201 50.9162 -186.225 36.1416 -168 36.1416H0.414978C19.7449 36.1416 35.415 20.4716 35.415 1.14163V-94C35.415 -112.225 50.1896 -127 68.415 -127L1060 -127C1078.23 -127 1093 -112.225 1093 -94V1.01892C1093 19.2443 1078.23 34.0189 1060 34.0189H659.556C640.226 34.0189 624.556 49.6889 624.556 69.0189Z" stroke="url(#paint0_linear_8002_15155)" stroke-width="2"/>
					</g>
					</g>
					<defs>
					<filter id="filter0_d_8002_15155" x="-208" y="-134" width="1308" height="392" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
					<feFlood flood-opacity="0" result="BackgroundImageFix"/>
					<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
					<feOffset/>
					<feGaussianBlur stdDeviation="3"/>
					<feComposite in2="hardAlpha" operator="out"/>
					<feColorMatrix type="matrix" values="0 0 0 0 0.820833 0 0 0 0 0.820833 0 0 0 0 0.820833 0 0 0 0.1 0"/>
					<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_8002_15155"/>
					<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_8002_15155" result="shape"/>
					</filter>
					<linearGradient id="paint0_linear_8002_15155" x1="180.799" y1="-119" x2="180.799" y2="261" gradientUnits="userSpaceOnUse">
					<stop stop-color="#F1E4F0" stop-opacity="0"/>
					<stop offset="1" stop-color="#373254"/>
					</linearGradient>
					<clipPath id="clip0_8002_15155">
					<rect width="36" height="37" fill="white"/>
					</clipPath>
					</defs>
				</svg>
			</div>
			<div class="alm-custom-slide-image">
				<svg width="46" height="69" viewBox="0 0 46 69" fill="none" xmlns="http://www.w3.org/2000/svg">
					<g clip-path="url(#clip0_8002_15152)">
					<g filter="url(#filter0_d_8002_15152)">
					<path d="M-579.585 -95C-579.585 -113.778 -564.363 -129 -545.585 -129L446 -129C464.778 -129 480 -113.778 480 -95V0.0189253C480 18.7966 464.778 34.0189 446 34.0189H45.5559C26.7782 34.0189 11.5559 49.2412 11.5559 68.0189V217C11.5559 235.778 -3.66638 251 -22.4441 251H-85.2254H-588.579H-782C-800.778 251 -816 235.778 -816 217V68.1416C-816 49.364 -800.778 34.1416 -782 34.1416H-613.585C-594.807 34.1416 -579.585 18.9193 -579.585 0.141631V-95Z" fill="#C1B6DE"/>
					<path d="M10.5559 68.0189V217C10.5559 235.225 -4.21869 250 -22.4441 250H-85.2255H-588.579H-782C-800.225 250 -815 235.225 -815 217V68.1416C-815 49.9162 -800.225 35.1416 -782 35.1416H-613.585C-594.255 35.1416 -578.585 19.4716 -578.585 0.141632V-95C-578.585 -113.225 -563.81 -128 -545.585 -128L446 -128C464.225 -128 479 -113.225 479 -95V0.0189209C479 18.2443 464.225 33.0189 446 33.0189H45.5559C26.226 33.0189 10.5559 48.6889 10.5559 68.0189Z" stroke="url(#paint0_linear_8002_15152)" stroke-width="2"/>
					</g>
					</g>
					<defs>
					<filter id="filter0_d_8002_15152" x="-822" y="-135" width="1308" height="392" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
					<feFlood flood-opacity="0" result="BackgroundImageFix"/>
					<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
					<feOffset/>
					<feGaussianBlur stdDeviation="3"/>
					<feComposite in2="hardAlpha" operator="out"/>
					<feColorMatrix type="matrix" values="0 0 0 0 0.820833 0 0 0 0 0.820833 0 0 0 0 0.820833 0 0 0 0.1 0"/>
					<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_8002_15152"/>
					<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_8002_15152" result="shape"/>
					</filter>
					<linearGradient id="paint0_linear_8002_15152" x1="-433.201" y1="-120" x2="-433.201" y2="260" gradientUnits="userSpaceOnUse">
					<stop stop-color="#F1E4F0" stop-opacity="0"/>
					<stop offset="1" stop-color="#373254"/>
					</linearGradient>
					<clipPath id="clip0_8002_15152">
					<rect width="46" height="69" fill="white"/>
					</clipPath>
					</defs>
				</svg>
				<?php
					echo wp_get_attachment_image( $image['id'], 'full' );
				?>
			</div>
		</div>
		<?php
	}
}
