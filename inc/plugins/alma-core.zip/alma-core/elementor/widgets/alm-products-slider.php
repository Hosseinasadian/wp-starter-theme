<?php
class ALM_Products_Slider extends \ALMA\CORE\ALM_SWIPER{
	public function get_name() {
        return 'alm_products_slider';
    }

    public function get_title() {
        return __('لیست محصولات', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-products';
    }

	public function get_keywords()
    {
        return ['alma', 'products','slider', 'woocommerce'];
    }

	public function get_style_depends()
    {
		$style_depends = parent::get_style_depends()??[];
        return array_unique(array_merge($style_depends,[
			'alm-products-slider'
		]));
    }

	public function get_script_depends()
    {
		$style_depends = parent::get_script_depends()??[];
        return array_unique(array_merge($style_depends,[
			'wc-add-to-cart'
		]));
    }

	protected function register_controls()
    {
		parent::register_controls();

        $this->start_controls_section(
            'query_content',
            [
                'label' => esc_html__('فیلتر محصولات', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('products_count', [
            'label' => esc_html__('تعداد محصول', 'alma-core'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 8,
        ]);
		$this->add_control(
			'products_source',
			[
				'label' => esc_html__( 'چینش محصولات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'latest',
				'options' => [
					'latest' => esc_html__( 'جدیدترین محصولات', 'alma-core' ),
					'sale' => esc_html__( 'محصولات دارای فروش ویژه', 'alma-core' ),
					'random' => esc_html__( 'انتخاب تصادفی محصولات', 'alma-core' ),
				],
			]
		);

		$this->add_control(
			'terms',
			[
				'label' => esc_html__( 'دسته بندی', 'alma-core' ),
				'type' => 'alm_select_term',
				'multiple'=>true,
				'taxonomy'=>['product_cat']
			]
		);

		$this->add_control(
			'products',
			[
				'label' => esc_html__( 'محصولات مشخض', 'alma-core' ),
				'type' => 'alm_select_post',
				'multiple'=>true,
				'post_type'=>['product']
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'cart_content',
            [
                'label' => esc_html__('کارت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
			'widget_layout',
			[
				'label' => esc_html__( 'نحوه نمایش محصولات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'slider',
				'options' => [
					'slider' => esc_html__( 'اسلایدر', 'alma-core' ),
					'list' => esc_html__( 'لیست', 'alma-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'list_cart_width',
			[
				'label' => esc_html__( 'عرض کارت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-products-slider.alm-products-display-list .alm-product-card-wrapper' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'widget_layout' => 'list',
				],
			]
		);

		$this->add_control(
			'show_slider_in_mobile_device',
			[
				'label' => esc_html__( 'برای کاربر موبایل اسلایدر نشان داده شود', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$this->add_responsive_control(
			'list_cart_column_gap',
			[
				'label' => esc_html__( 'فضای افقی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-products-slider.alm-products-display-list' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_cart_row_gap',
			[
				'label' => esc_html__( 'فضای عمودی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-products-slider.alm-products-display-list' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'show_wishlist_icon',
			[
				'label' => esc_html__( 'آیکن علاقه‌مندی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'wishlist_icon_position',
			[
				'label' => esc_html__( 'موقعیت آیکن علاقه‌مندی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'over_images',
				'options' => [
					'over_images' => esc_html__( 'کنار تصویر محصول', 'alma-core' ),
					'before_cart' => esc_html__( 'قبل از سبد خرید', 'alma-core' ),
					'after_cart' => esc_html__( 'بعد از سبد خرید', 'alma-core' ),
				],
				'condition' => [
					'show_wishlist_icon' => 'yes',
				],
			]
		);

		$this->add_control(
			'first_section_content',
			[
				'label' => esc_html__( 'کنار تصویر محصول چه اطلاعاتی نشان داده شود؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => [
					'title'  => esc_html__( 'عنوان', 'alma-core' ),
					'category' => esc_html__( 'دسته بندی', 'alma-core' ),
					'properties' => esc_html__( 'ویژگی های محصول', 'alma-core' ),
				],
				'default' => [],
			]
		);
		$this->add_control(
			'product_attributes_list',
			[
				'label' => esc_html__( 'کدام ویژگی های محصول نشان داده شود؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => alm_wc_product_attributes_list(),
				'default' => [],
			]
		);
		$this->add_control(
			'show_gallery',
			[
				'label' => esc_html__( 'گالری تصاویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'show_metas',
			[
				'label' => esc_html__( 'آمار محصول', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'show_category',
			[
				'label' => esc_html__( 'نمایش دسته بندی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'show_attributes',
			[
				'label' => esc_html__( 'نمایش ویژگی ها', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$this->add_control(
			'add_to_cart_icon',
			[
				'label' => esc_html__( 'آیکن افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
		$this->add_control(
			'add_to_cart_text',
			[
				'label' => esc_html__( 'متن افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'view_detail_icon',
			[
				'label' => esc_html__( 'آیکن مشاهده جزییات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
		$this->add_control(
			'view_detail_text',
			[
				'label' => esc_html__( 'متن مشاهده جزییات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'cart_style',
            [
                'label' => esc_html__('کارت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
            'cart_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'cart_display_direction',
			[
				'label' => esc_html__( 'نوع چیدمان', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'column',
				'options' => [
					'row' => esc_html__( 'افقی', 'alma-core' ),
					'column' => esc_html__( 'عمودی', 'alma-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'cart_column_gap',
			[
				'label' => esc_html__( 'فضای افقی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'cart_row_gap',
			[
				'label' => esc_html__( 'فضای عمودی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/* */
		$this->add_responsive_control(
			'cart_justify_content',
			[
				'label' => esc_html__( 'تراز کردن محتوا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-end-h',
					],
					'space-between' => [
						'title' => esc_html__( 'فاصله بینابینی', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-between-h',
					],
					'space-around' => [
						'title' => esc_html__( 'فضای اطراف', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-around-h',
					],
					'space-evenly' => [
						'title' => esc_html__( 'فضا یکنواخت', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-evenly-h',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'cart_align_items',
			[
				'label' => esc_html__( 'چینش موارد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-center-v',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => esc_html__( 'کشیده', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'align-items: {{VALUE}};',
				],
			]
		);
		/* */

		$this->add_responsive_control(
			'first_section_width',
			[
				'label' => esc_html__( 'عرض سکشن اول', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'first_section_flex',
			[
				'label' => esc_html__( 'اندازه سکسن اول', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => esc_html__( 'grow', 'alma-core' ),
						'icon' => 'eicon-grow',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section' => 'flex: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'second_section_width',
			[
				'label' => esc_html__( 'عرض سکسن دوم', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-second-section' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'second_section_flex',
			[
				'label' => esc_html__( 'اندازه سکسن دوم', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => esc_html__( 'grow', 'alma-core' ),
						'icon' => 'eicon-grow',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-second-section' => 'flex: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
            'cart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card-content',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'cart_border',
				'selector' => '{{WRAPPER}} .alm-product-card-content',
			]
		);
		$this->add_responsive_control(
			'cart_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .alm-product-card:hover:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'cart_box_shadow',
				'selector' => '{{WRAPPER}} .alm-product-card-content',
			]
		);
		//hover background
		$this->add_control(
			'cart_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور کارت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card:hover:before',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'divider_style',
            [
                'label' => esc_html__('جداکننده', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'divider_icon',
			[
				'label' => esc_html__( 'آیکن جداکننده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);

		$this->add_responsive_control(
			'divider_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-divider' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'divider_line_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-divider-line',
			]
		);
		$this->add_responsive_control(
			'divider_line_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-divider-line' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'divider_line_height',
			[
				'label' => esc_html__( 'ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-divider-line' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
            'divider-logo-container_padding',
            [
                'label' => esc_html__('فاصله داخلی لوگو', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-divider-logo-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

		$this->start_controls_section(
            'product_first_section_style',
            [
                'label' => esc_html__('سکشن اول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_first_section_align_self',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'start' => esc_html__( 'آغاز', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-center-v',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => esc_html__( 'کشیده', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section' => 'align-self: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_first_section_column_gap',
			[
				'label' => esc_html__( 'فضای افقی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'product_first_section_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		//
		$this->add_responsive_control(
			'first_section_product_images_width',
			[
				'label' => esc_html__( 'عرض سکشن تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section .alm-product-images' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'first_section_product_images_flex',
			[
				'label' => esc_html__( 'اندازه سکسن تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => esc_html__( 'grow', 'alma-core' ),
						'icon' => 'eicon-grow',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section .alm-product-images' => 'flex: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'first_section_content_width',
			[
				'label' => esc_html__( 'عرض سکشن محتوا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section .alm-product-first-section-content' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'first_section_content_flex',
			[
				'label' => esc_html__( 'اندازه سکسن محتوا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => esc_html__( 'grow', 'alma-core' ),
						'icon' => 'eicon-grow',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-first-section .alm-product-first-section-content' => 'flex: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'product_images_style',
            [
                'label' => esc_html__('تصاویر محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
			'product_images_display_direction',
			[
				'label' => esc_html__( 'نوع چیدمان', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'column',
				'options' => [
					'row' => esc_html__( 'افقی', 'alma-core' ),
					'column' => esc_html__( 'عمودی', 'alma-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-images' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_images_column_gap',
			[
				'label' => esc_html__( 'فضای افقی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-images' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_images_row_gap',
			[
				'label' => esc_html__( 'فضای عمودی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-images' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'main_image_heading',
			[
				'label' => esc_html__( 'تصویر شاخص', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'main_image_flex',
			[
				'label' => esc_html__( 'اندازه تصویر شاخص', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => esc_html__( 'grow', 'alma-core' ),
						'icon' => 'eicon-grow',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-main-image' => 'flex: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
            'main_image_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-main-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
			'product_gallery_images_gap',
			[
				'label' => esc_html__( 'فاصله تصاویر گالری', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-gallery-images' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'main_image_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-main-image',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'main_image_border',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-main-image',
			]
		);
		$this->add_responsive_control(
			'main_image_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-main-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'gallery_image_heading',
			[
				'label' => esc_html__( 'تصویر گالری', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'gallery_image_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-gallery-image img',
			]
		);
		$this->add_responsive_control(
            'gallery_image_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-gallery-image img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
			'gallery_image_width',
			[
				'label' => esc_html__( 'عرض باکس تصویر گالری', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-gallery-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'product_title_style',
            [
                'label' => esc_html__('عنوان محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_title_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .alm-product-card .alm-product-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_title_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-title',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'sale_price_style',
            [
                'label' => esc_html__('قیمت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'sale_price_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .sale-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sale_price_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .sale-price',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'regular_price_style',
            [
                'label' => esc_html__('قیمت بدون تخفیف محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'regular_price_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .regular-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'regular_price_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .regular-price',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'currency_style',
            [
                'label' => esc_html__('واحد پولی', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'currency_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-price-currency' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'currency_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-price-currency',
			]
		);

		$this->add_responsive_control(
			'price_box_gap',
			[
				'label' => esc_html__( 'فاصله قیمت و واحد پولی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-price-box' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'add_to_cart_style',
            [
                'label' => esc_html__('دکمه افزودن به سبد', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
            'add_to_cart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-add-to-cart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'add_to_cart_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-add-to-cart',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'add_to_cart_border',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-add-to-cart',
			]
		);

		$this->add_responsive_control(
			'add_to_cart_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-add-to-cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'add_to_cart_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card a.alm-add-to-cart' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'add_to_cart_gap',
			[
				'label' => esc_html__( 'فاصله متن و آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-add-to-cart' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'add_to_cart_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-add-to-cart-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'add_to_cart_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-add-to-cart-text',
			]
		);

		$this->add_control(
			'add_to_cart_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-product-card a.alm-add-to-cart svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'add_to_cart_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-product-card a.alm-add-to-cart svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sell_info_gap',
			[
				'label' => esc_html__( 'فاصله قیمت و افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-sell-info' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'add_to_cart_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'add_to_cart_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card:hover .alm-add-to-cart',
			]
		);

		//view datail for grouped and variable product
		$this->add_control(
			'view_detail_heading',
			[
				'label' => esc_html__( 'دکمه مشاهده جزيیات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
            'view_detail_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-view-detail' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'view_detail_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-view-detail',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'view_detail_border',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-view-detail',
			]
		);

		$this->add_responsive_control(
			'view_detail_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-view-detail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_detail_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card a.alm-view-detail' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'view_detail_gap',
			[
				'label' => esc_html__( 'فاصله متن و آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-view-detail' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_detail_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-view-detail-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'view_detail_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-view-detail-text',
			]
		);

		$this->add_control(
			'view_detail_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-product-card a.alm-view-detail svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'view_detail_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-product-card a.alm-view-detail svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_detail_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'view_detail_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card:hover .alm-view-detail',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'product_category_item_style',
            [
                'label' => esc_html__('دسته بندی محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_category_item_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-category a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_category_item_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-category a',
			]
		);

		$this->add_responsive_control(
            'product_category_item_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-category a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'product_category_item_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-category a',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'product_category_item_border',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-category a',
			]
		);

		$this->add_responsive_control(
			'product_category_item_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-category a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'product_category_gap',
			[
				'label' => esc_html__( 'فاصله بین دسته بندی ها', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-category' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'product_attributes_style',
            [
                'label' => esc_html__('ویژگی های محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'product_attributes_item_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-attributes .alm-product-attribute' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_attributes_item_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-attributes .alm-product-attribute',
			]
		);
		$this->add_control(
			'product_attributes_list_style_type',
			[
				'label' => esc_html__( 'مارکر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => [
					'none' => esc_html__( 'هیچ', 'alma-core' ),
					'circle' => esc_html__( 'دایره توخالی', 'alma-core' ),
					'disc' => esc_html__( 'دایره توپر', 'alma-core' ),
					'square'  => esc_html__( 'مربع', 'alma-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-attributes' => 'list-style-type: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'product_attributes_list_style_position',
			[
				'label' => esc_html__( 'موقعیت مارکر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'inside',
				'options' => [
					'inside' => esc_html__( 'داخل', 'alma-core' ),
					'outside' => esc_html__( 'خارج', 'alma-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-attributes' => 'list-style-position: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'product_attributes_gap',
			[
				'label' => esc_html__( 'فاصله بین ویژگی ها', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-attributes' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'product_metas_style',
            [
                'label' => esc_html__('آمار محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
			'product_metas_gap',
			[
				'label' => esc_html__( 'فضای بین آمار', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-metas' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'product_meta_name_heading',
			[
				'label' => esc_html__( 'عنوان', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'product_meta_name_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta .alm-product-meta-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_meta_name_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta .alm-product-meta-name',
			]
		);
		$this->add_control(
			'product_meta_value_heading',
			[
				'label' => esc_html__( 'مقدار', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'product_meta_value_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta .alm-product-meta-value' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_meta_value_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta .alm-product-meta-value',
			]
		);

		//
		$this->add_control(
			'product_meta_divider_heading',
			[
				'label' => esc_html__( 'جداکننده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'product_meta_divider_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta-divider',
			]
		);
		$this->add_responsive_control(
			'product_meta_divider_width',
			[
				'label' => esc_html__( 'ضخامت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-metas .alm-product-meta-divider' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'product_discount_style',
            [
                'label' => esc_html__('درصد تخفیف', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_discount_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_discount_typography',
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-discount-percentage',
			]
		);
		$this->add_control(
			'discount_main_layer_heading',
			[
				'label' => esc_html__( 'لایه اصلی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_height',
			[
				'label' => esc_html__( 'ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_top',
			[
				'label' => esc_html__( 'آفست بالا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_left',
			[
				'label' => esc_html__( 'آفست چپ', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'discount_main_layer_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-discount-percentage',
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'discount_before_layer_heading',
			[
				'label' => esc_html__( 'لایه پشتی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_height',
			[
				'label' => esc_html__( 'ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_top',
			[
				'label' => esc_html__( 'آفست بالا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_left',
			[
				'label' => esc_html__( 'آفست چپ', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'discount_before_layer_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before',
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-product-card .alm-product-discount-percentage::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
            'items_margin_style',
            [
                'label' => esc_html__('حاشیه خارجی آیتم ها', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'product_title_margin',
            [
                'label' => esc_html__('عنوان محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'product_category_margin',
            [
                'label' => esc_html__('دسته بندی های محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-category' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'product_attributes_margin',
            [
                'label' => esc_html__('ویژگی های محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-attributes' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'product_metas_margin',
            [
                'label' => esc_html__('آمار محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-metas' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'product_sell_info_margin',
            [
                'label' => esc_html__('سکشن قیمت و سبد خرید', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-card .alm-product-sell-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();


	}

	protected function get_products() {
		$settings = $this->get_settings_for_display(); // Retrieve widget settings

		// Default query args
		$args = [
			'post_type' => 'product',
			'posts_per_page' => $settings['products_count'],
			'post_status' => 'publish',
		];

		// Handle product source selection
		switch ($settings['products_source']) {
			case 'latest':
				$args['orderby'] = 'date';
				$args['order'] = 'DESC';
				break;

			case 'sale':
				$product_ids_on_sale = wc_get_product_ids_on_sale(); // Get product IDs on sale

				global $wpdb;
				$parent_ids = $wpdb->get_col("
					SELECT DISTINCT post_parent
					FROM $wpdb->posts
					WHERE ID IN (" . implode(',', $product_ids_on_sale) . ")
					AND post_parent != 0
				");

				// Merge parent product IDs with the sale products list
				$product_ids_on_sale = array_merge($product_ids_on_sale, $parent_ids);

				// Remove duplicates
				$product_ids_on_sale = array_unique($product_ids_on_sale);

				$args['post__in'] = $product_ids_on_sale;
				break;

			case 'random':
				$args['orderby'] = 'rand';
				break;

			case 'manual':
				// Handle manual product selection if you implement it later
				// For now, we can leave this empty or customize based on manual product IDs
				break;
		}

		// Filter by category if categories are selected
		if (!empty($settings['terms'])) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'product_cat',
					'field' => 'term_id',
					'terms' => $settings['terms'],
				],
			];
		}

		if(!empty($settings['products'])){
			$args['post__in']=$settings['products'];
		}

		// Run the query
		$query = new WP_Query($args);

		// Return the query result (can be used in render function to display products)
		return $query;
	}

	protected function render_slides(){
		$query = $this->items;
		$show_gallery = $this->get_settings_for_display('show_gallery')=='yes';
		$show_metas = $this->get_settings_for_display('show_metas')=='yes';
		$show_category = $this->get_settings_for_display('show_category')=='yes';
		$show_attributes = $this->get_settings_for_display('show_attributes')=='yes';

		$widget_layout = $this->get_settings_for_display('widget_layout');
		$layout_mobile_slider_mode = wp_is_mobile() && $this->get_settings_for_display('show_slider_in_mobile_device') == 'yes';


		$first_section_content = $this->get_settings_for_display('first_section_content');

		$add_to_cart_icon = $this->get_settings_for_display('add_to_cart_icon');
		$add_to_cart_text = $this->get_settings_for_display('add_to_cart_text');

		$view_detail_icon = $this->get_settings_for_display('view_detail_icon');
		$view_detail_text = $this->get_settings_for_display('view_detail_text');
		$divider_icon = $this->get_settings_for_display('divider_icon');

		$currency = get_woocommerce_currency_symbol();

		$show_wishlist = alm_wc_wishlist_enabled() && $this->get_settings_for_display('show_wishlist_icon')=='yes';
		$wishlist_position = $this->get_settings_for_display('wishlist_icon_position');

		while ($query->have_posts()) {
			$query->the_post();
            global $product;
			$attachment_ids = $product->get_gallery_image_ids();
			$attachment_ids = array_slice($attachment_ids, 0, 3);
			$price_html = alm_wc_price_html($product);
			$discount = alm_wc_discount_percentage($product);

			if($widget_layout == 'slider'|| $layout_mobile_slider_mode)
				echo '<div class="swiper-slide">';
			else
				echo '<div class="alm-product-card-wrapper">';
			?>
				<div class="alm-product-card">
					<div class="alm-product-card-content">
						<?php if($discount){?>
						<div class="alm-product-discount-percentage">
							<?php echo alm_wc_discount_percentage($product)?>
						</div>
						<?php }?>
						<div class="alm-product-first-section">
							<div class="alm-product-images">
								<div class="alm-product-main-image">
									<a href="<?php the_permalink()?>">
										<?php echo $product->get_image() ?>
									</a>
								</div>
								<?php if($show_gallery && count($attachment_ids)>0){?>
									<div class="alm-product-gallery-images">
										<?php foreach($attachment_ids as $attachment_id){?>
											<div class="alm-product-gallery-image"><?php echo wp_get_attachment_image($attachment_id);?></div>
										<?php }?>
									</div>
								<?php }?>
								<?php
									if($show_wishlist && $wishlist_position == 'over_images'){
										alm_wc_product_images_over_wishlist();
									}
								?>
							</div>
							<?php $this->show_first_section_items();?>
						</div>

						<div class="alm-divider">
							<div class="alm-divider-line"></div>
							<div class="alm-divider-logo-container">
								<?php
									if($divider_icon && !empty($divider_icon['value'])){
										\Elementor\Icons_Manager::render_icon( $divider_icon, [ 'aria-hidden' => 'true','class'=> 'alm-divider-logo'] );
									}else{
										echo '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="12" viewBox="0 0 10 12" fill="none"><g id="christianity--religion-jesus-christianity-christ-fish-culture" opacity="0.5" clip-path="url(#clip0_396_12642)"><g id="christianity--religion-jesus-christianity-christ-fish-culture_2"><path id="Vector" d="M7.27922 11.5762C7.27922 11.5762 3.3304 8.43049 3.33041 4.71906C3.32553 3.83745 3.50725 2.97113 3.85553 2.21513C4.20382 1.45913 4.70524 0.842659 5.30481 0.433349C5.90438 0.842659 6.40581 1.45913 6.75409 2.21513C7.10238 2.97113 7.28406 3.83745 7.27922 4.71906C7.27922 8.43049 3.3304 11.5762 3.3304 11.5762" stroke="#8D8D8D" stroke-linecap="round" stroke-linejoin="round"></path></g></g><defs><clipPath id="clip0_396_12642"><rect width="12" height="9.2139" fill="white" transform="translate(9.9117 0.00488281) rotate(90)"></rect></clipPath></defs></svg>';
									}
								?>
							</div>
							<div class="alm-divider-line"></div>
						</div>

						<div class="alm-product-second-section">
							<?php
								if(!in_array('title',$first_section_content))
									$this->show_title();
								if($show_category && !in_array('category',$first_section_content))
									$this->show_categories();
								if($show_attributes && !in_array('properties',$first_section_content))
										$this->show_properties();
								if($show_metas)
									$this->show_metas();
							?>

							<?php if($price_html || $price_html == '0'){?>
							<div class="alm-product-sell-info">
								<div class="alm-product-sell-info-actions">
									<?php
										if($show_wishlist && $wishlist_position == 'before_cart'){
											alm_wc_product_images_over_wishlist();
										}
									?>
									<?php if ($product->is_type('variable') || $product->is_type('grouped')) {?>
										<a class="alm-view-detail" href='<?php echo the_permalink() ?>'>
											<?php
												if($view_detail_icon && !empty($view_detail_icon['value'])){
													\Elementor\Icons_Manager::render_icon( $view_detail_icon, [ 'aria-hidden' => 'true','class'=> 'alm-view-detail-icon'] );
												}else{
													echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
  <path d="M7.5 7.67489V6.70489C7.5 4.45489 9.31 2.24489 11.56 2.03489C14.24 1.77489 16.5 3.88489 16.5 6.51489V7.89489" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M9 22.0049H15C19.02 22.0049 19.74 20.3949 19.95 18.4349L20.7 12.4349C20.97 9.99488 20.27 8.00488 16 8.00488H8C3.73 8.00488 3.03 9.99488 3.3 12.4349L4.05 18.4349C4.26 20.3949 4.98 22.0049 9 22.0049Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M15.4955 12.0049H15.5045" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8.49451 12.0049H8.50349" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
												}
												?>
											<?php
												if($view_detail_text){
													echo "<span class='alm-view-detail-text'>$view_detail_text</span>";
												}
											?>
										</a>
									<?php }else {?>
										<a class="alm-add-to-cart add_to_cart_button ajax_add_to_cart" href='<?php echo $product->add_to_cart_url() ?>' data-quantity="1" data-product_id="<?php echo $product->get_id()?>">
											<?php
												if($add_to_cart_icon['value'] && !empty($add_to_cart_icon['value'])){
													\Elementor\Icons_Manager::render_icon( $add_to_cart_icon, [ 'aria-hidden' => 'true','class'=> 'alm-add-to-cart-icon'] );
												}else{
													echo '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
  <path d="M7.5 7.67489V6.70489C7.5 4.45489 9.31 2.24489 11.56 2.03489C14.24 1.77489 16.5 3.88489 16.5 6.51489V7.89489" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M9 22.0049H15C19.02 22.0049 19.74 20.3949 19.95 18.4349L20.7 12.4349C20.97 9.99488 20.27 8.00488 16 8.00488H8C3.73 8.00488 3.03 9.99488 3.3 12.4349L4.05 18.4349C4.26 20.3949 4.98 22.0049 9 22.0049Z" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M15.4955 12.0049H15.5045" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8.49451 12.0049H8.50349" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
												}
											?>
											<?php
												if($add_to_cart_text){
													echo "<span class='alm-add-to-cart-text'>$add_to_cart_text</span>";
												}
											?>
										</a>
									<?php }?>
									<?php
										if($show_wishlist && $wishlist_position == 'after_cart'){
											alm_wc_product_images_over_wishlist();
										}
									?>
								</div>
								<div class='alm-product-price-box'>
									<div class='alm-product-price'>
										<?php echo $price_html;?>
									</div>
									<?php if(alm_wc_enable_show_currency($product)):?>
									<div class='alm-product-price-currency'>
										<?php echo $currency;?>
									</div>
									<?php endif;?>
								</div>
							</div>
							<?php }?>
						</div>
					</div>
				</div>
			<?php
			echo '</div>';
		}
	}

	protected function render(){
		$query = $this->get_products();
		$this->set_items($query);
		if ($query->have_posts()) {
			$widget_layout = $this->get_settings_for_display('widget_layout');
			$layout_mobile_slider_mode = wp_is_mobile() && $this->get_settings_for_display('show_slider_in_mobile_device') == 'yes';
		?>
            <div class="alm-products-slider <?php echo ((!$layout_mobile_slider_mode && $widget_layout == 'list')?'alm-products-display-list':'')?>" style="height: 100%">
                <?php
					if($widget_layout=='slider' || $layout_mobile_slider_mode){
						parent::render();
					}else{
						$this->render_slides();
					}
				?>
            </div>
		<?php
		}
		wp_reset_postdata();
	}

	protected function show_title(){
		?>
			<h3 class="alm-product-title"><a href="<?php the_permalink()?>"><?php the_title();?></a></h3>
		<?php
	}

	protected function show_categories(){
		echo wc_get_product_category_list(get_the_ID(), '','<div class="alm-product-category">','</div>');
	}

	protected function show_properties(){
		global $product;
		$product_attributes_list = $this->get_settings_for_display('product_attributes_list');
		if(count($product_attributes_list)>0){
			echo "<ul class='alm-product-attributes'>";
			foreach($product_attributes_list as $atrribute){
				$attribute_value = $product->get_attribute( "pa_$atrribute" );
				$attribute_label = alm_wc_product_get_attribute_label($atrribute);
				if($attribute_value){
					echo "<li class='alm-product-attribute'>" . esc_html($attribute_label) . " " .esc_html( $attribute_value )."</li>";
				}
			}
			echo "</ul>";
		}
	}

	protected function show_metas(){
	?>
		<div class="alm-product-metas">
			<div class="alm-product-meta">
				<span class="alm-product-meta-name"><?php esc_html_e('فروش','alma-core')?></span>
				<span class="alm-product-meta-value"><?php echo alm_wc_get_total_sales(get_the_ID())?></span>
			</div>
			<div class="alm-product-meta-divider"></div>
			<div class="alm-product-meta">
				<span class="alm-product-meta-name"><?php esc_html_e('رضایت','alma-core')?></span>
				<span class="alm-product-meta-value"><?php echo alm_wc_product_rate_percentage()?></span>
			</div>
			<div class="alm-product-meta-divider"></div>
			<div class="alm-product-meta">
				<span class="alm-product-meta-name"><?php esc_html_e('موجودی','alma-core')?></span>
				<span class="alm-product-meta-value"><?php echo alm_wc_product_stock_quantity();?></span>
			</div>
		</div>
	<?php
	}

	protected function show_first_section_items(){
		$first_section_content = $this->get_settings_for_display('first_section_content');
		if(count($first_section_content)>0){
			echo "<div class='alm-product-first-section-content'>";
			foreach($first_section_content as $item){
				switch($item){
					case 'title':
						$this->show_title();
						break;
					case 'category':
						$this->show_categories();
						break;
					case 'properties':
						$this->show_properties();
						break;
				}
			}
			echo "</div>";
		}
	}
}
