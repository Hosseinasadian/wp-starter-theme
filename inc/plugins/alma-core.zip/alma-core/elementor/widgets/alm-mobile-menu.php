<?php

class ALM_Mobile_Menu extends \Elementor\Widget_Base{
    public function get_name()
    {
        return 'alma_mobile_menu';
    }

    public function get_title()
    {
        return esc_html__('منوی موبایل', 'alma-core');
    }

    public function get_icon()
    {
        return 'eicon-nav-menu';
    }

	public function get_categories()
    {
        return ['alma'];
    }

    public function get_keywords()
    {
        return ['alma', 'mobile', 'menu'];
    }

	protected function register_controls(){
		$this->start_controls_section(
			'settings',
			[
				'label' => esc_html__( 'تنطیمات', 'alma-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'menu',
			[
				'label' => esc_html__( 'منو را از لیست انتخاب کنید', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'solid',
				'options' => get_registered_nav_menus(),
            ]
		);
        $this->add_control(
            'toggle_icon',
            [
                'label' => esc_html__('آیکن باز کردن زیرمنو', 'alma-core'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
		$this->end_controls_section();

        $this->start_controls_section(
			'styles',
			[
				'label' => esc_html__( 'استایل', 'alma-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'list_items_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'list_typography',
                'selector' => '{{WRAPPER}} .alm-mobile-menu li',
            ]
        );
		$this->add_control(
			'links_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'links_extended_color',
			[
				'label' => esc_html__( 'رنگ متن در حالت گسترده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu li.alm-extend-mobile-menu-item a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'toggle_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-toggle-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-toggle-icon svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-toggle-icon svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-toggle-icon svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-toggle-icon svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'toggle_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-toggle-icon' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-toggle-icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'toggle_icon_extended_color',
			[
				'label' => esc_html__( 'رنگ آیکن در حالت گسترده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'toggle_icon_extended_rotate',
			[
				'label' => esc_html__( 'چرخش آیکن در حالت گسترده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'unit' => 'px',
					'size' => -90,
				],
				'selectors' => [
					'{{WRAPPER}} li.alm-extend-mobile-menu-item .alm-toggle-icon' => 'transform: rotateZ({{SIZE}}deg);',
				],
			]
		);
		$this->add_control(
			'first_level_menu',
			[
				'label' => esc_html__( 'آیتم های اصلی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
            'first_level_list_items_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu >ul >li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'list_children_typography',
                'selector' => '{{WRAPPER}} .alm-mobile-menu >ul >li',
            ]
        );


		$this->add_control(
            'items_divider_width',
            [
                'label' => esc_html__( 'عرض جداکننده', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu li .alm-mobile-list-divider' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
            ]
        );
		$this->add_control(
            'items_divider_height',
            [
                'label' => esc_html__( 'ارتفاع جداکننده', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-mobile-menu li .alm-mobile-list-divider' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-mobile-menu li .alm-mobile-list-divider',
			]
		);
        $this->end_controls_section();
	}

	public function get_script_depends()
    {
        return ["alm-mobile-menu"];
    }

	public function get_style_depends()
    {
        return ["alm-mobile-menu"];
    }

	protected function render(){
		$menu_location = $this->get_settings_for_display('menu');
		$exist_menu = false;
        $menu_items = [];

		if (($menu_location) && ($locations = get_nav_menu_locations()) && isset($locations[$menu_location])) {
			$menu = get_term($locations[$menu_location], 'nav_menu');
			if ($menu && !is_wp_error($menu)) {
				$all_menu_items = wp_get_nav_menu_items($menu->term_id);
				$exist_menu = true;

				$menu_items = self::getTreeModeMenuItems($all_menu_items);
                if(count($menu_items)>0){
                    echo "<div class='alm-mobile-menu'>";
                    $this->renderMenuItems($menu_items);
                    echo "</div>";
                }
			}

		}
	}

    public function renderMenuItems($menu_items,$level=1){
        echo "<ul>";
        foreach (array_values($menu_items) as $index=>$menu_item) {
            echo "<li>";
            echo "<a href='{$menu_item->url}'>";

            echo "<span class='alm-link-content'>{$menu_item->title}</span>";

            if(count($menu_item->children) > 0){
                $toggle_icon = $this->get_settings_for_display('toggle_icon');
				echo "<div class='alm-toggle-icon'>";
                if($toggle_icon && !empty($toggle_icon['value'])){
                    \Elementor\Icons_Manager::render_icon( $toggle_icon, [ 'aria-hidden' => 'true' ] );
                }else{
					echo '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="21" viewBox="0 0 26 21" fill="none"><path opacity="0.15" d="M17.1948 18.8451C21.7972 18.8451 25.5282 15.1142 25.5282 10.5118C25.5282 5.90943 21.7972 2.17847 17.1948 2.17847C12.5925 2.17847 8.86151 5.90943 8.86151 10.5118C8.86151 15.1142 12.5925 18.8451 17.1948 18.8451Z" fill="#8D8D8D"></path><path d="M10.5618 19.1437C15.1641 19.1437 18.8951 15.4128 18.8951 10.8104C18.8951 6.20801 15.1641 2.47705 10.5618 2.47705C5.95938 2.47705 2.22842 6.20801 2.22842 10.8104C2.22842 15.4128 5.95938 19.1437 10.5618 19.1437Z" stroke="#8D8D8D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M13.4784 10.8104H8.47842" stroke="#8D8D8D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M10.1451 8.31039L7.64511 10.8104L10.1451 13.3104" stroke="#8D8D8D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
				}
				echo "</div>";
                // todo show toggle icon
            }

            echo "</a>";

            if(count($menu_item->children) > 0){
                $this->renderMenuItems($menu_item->children,1+$level);
            }

			if($level <= 1 && 1+$index<count($menu_items)){
				echo "<div class='alm-mobile-list-divider'></div>";
			}

            echo "</li>";
        }
        echo "</ul>";
    }

	public static function getTreeModeMenuItems($menu_items)
    {
        $mainItems = self::getMenuItemChildren($menu_items, 0);
        if ($mainItems) {
            foreach ($mainItems as $mainItem) {
                $mainItem->children = self::getRecursiveMenuItemChildren($menu_items, $mainItem->ID);
            }
        }
        return $mainItems;
    }

	public static function getMenuItemChildren($menu_items, $menu_item_parent = 0)
    {
        return array_filter($menu_items, function ($item) use ($menu_item_parent) {
            return $item->menu_item_parent == $menu_item_parent;
        });
    }

    public static function getRecursiveMenuItemChildren($menu_items, $menu_item_parent = 0)
    {
        $direct_children = self::getMenuItemChildren($menu_items, $menu_item_parent);
        foreach ($direct_children as $child) {
            $child->children = self::getRecursiveMenuItemChildren($menu_items, $child->ID);
        }
        return $direct_children;
    }
}
