<?php
class ALM_Newsletter extends \Elementor\Widget_Base {

    public function get_name() {
        return 'alm_newsletter_widget';
    }

    public function get_title() {
        return __( 'خبرنامه', 'alma-core' );
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_keywords()
    {
        return ['alma', 'newsletter'];
    }

    public function get_categories() {
        return [ 'alma' ];
    }

    public function get_script_depends()
    {
        return ['alm-newsletter'];
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'تنطیمات خبرنامه', 'alma-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'input_placeholder',
            [
                'label' => __( 'متن راهنمای فیلد شماره تلفن / ایمیل', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'شماره تماس یا ایمیل خود را وارد کنید' , 'alma-core' ),
            ]
        );
        $this->add_control(
            'button_text',
            [
                'label' => __( 'متن دکمه ارسال شماره تلفن / ایمیل', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'ثبت' , 'alma-core' ),
            ]
        );
        $this->add_control(
            'button_icon',
            [
                'label' => esc_html__( 'آیکن دکمه ارسال شماره تلفن / ایمیل', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
		$this->add_control(
			'show_divider',
			[
				'label' => esc_html__( 'نمایش جدا‌کننده', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'استایل دهی خبرنامه', 'alma-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'gap',
            [
                'label' => esc_html__( 'فاصله بین فیلدهای فرم', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-content-area' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'newsletter-form_gap',
            [
                'label' => esc_html__( 'فاصله بین باکس پیام و فرم', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} .newsletter-form' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		/* */
		$this->add_control(
            'content_area_padding',
            [
                'label' => esc_html__( 'فاصله داخلی', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-content-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'content_area_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-content-area',
			]
		);
		$this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'content_area__border',
                'selector' => '{{WRAPPER}} .alm-content-area',
            ]
        );
        $this->add_control(
            'content_area__radius',
            [
                'label' => esc_html__( 'شعاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-content-area' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		/* */

        $this->add_control(
            'input_heading',
            [
                'label' => esc_html__( 'فیلد شماره تلفن / ایمیل', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'input_typography',
                'selector' => '{{WRAPPER}} input',
            ]
        );
        $this->add_control(
            'input_text_color',
            [
                'label' => esc_html__( 'رنگ متن', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} input' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'input_bg_color',
            [
                'label' => esc_html__( 'رنگ پس زمینه', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} input' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'input_border',
                'selector' => '{{WRAPPER}} input',
            ]
        );
        $this->add_control(
            'input_radius',
            [
                'label' => esc_html__( 'شعاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} input' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'input_padding',
            [
                'label' => esc_html__( 'فاصله داخلی', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'input_height',
            [
                'label' => esc_html__( 'ارتفاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} input' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'input_focus_heading',
            [
                'label' => esc_html__( 'حالت فوکوس فیلد', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
		$this->add_control(
            'input_focus_text_color',
            [
                'label' => esc_html__( 'رنگ متن', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} input:focus, {{WRAPPER}} input:focus-visible' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
            'input_focus_bg_color',
            [
                'label' => esc_html__( 'رنگ پس زمینه', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} input:focus, {{WRAPPER}} input:focus-visible' => 'background-color: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'input_focus_border',
                'selector' => '{{WRAPPER}} input:focus, {{WRAPPER}} input:focus-visible',
            ]
        );

        $this->add_control(
            'button_heading',
            [
                'label' => esc_html__( 'دکمه ارسال شماره تلفن / ایمیل', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} button',
            ]
        );
        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__( 'رنگ متن', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'button_bg_color',
            [
                'label' => esc_html__( 'رنگ پس زمینه', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} button' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} button',
            ]
        );
        $this->add_control(
            'button_radius',
            [
                'label' => esc_html__( 'شعاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} button' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_padding',
            [
                'label' => esc_html__( 'فاصله داخلی', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_height',
            [
                'label' => esc_html__( 'ارتفاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} button' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_gap',
            [
                'label' => esc_html__( 'فاصله متن و آیکن', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
                'selectors' => [
                    '{{WRAPPER}} button' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'divider_heading',
            [
                'label' => esc_html__( 'جدا‌کننده', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
		$this->add_control(
            'divider_width',
            [
                'label' => esc_html__( 'عرض', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-newsletter-form-divider' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'divider_height',
            [
                'label' => esc_html__( 'ارتفاع', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                'selectors' => [
                    '{{WRAPPER}} .alm-newsletter-form-divider' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'divider_bg_color',
            [
                'label' => esc_html__( 'رنگ پس زمینه', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-newsletter-form-divider' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'message_heading',
            [
                'label' => esc_html__( 'پیام ها', 'alma-core' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'messages_typography',
                'selector' => '{{WRAPPER}} .alm-newsletter-message',
            ]
        );
        $this->add_control(
            'messages_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-newsletter-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'message_success_color',
            [
                'label' => esc_html__('رنگ پیام موفق', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'green',
                'selectors' => [
                    '{{WRAPPER}} .alm-success-message' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'message_error_color',
            [
                'label' => esc_html__('رنگ پیام ناموفق', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'red',
                'selectors' => [
                    '{{WRAPPER}} .alm-error-message' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        ?>
        <div class="newsletter-widget">
            <form class="newsletter-form alm-d-flex alm-flex-column-wrap">
                <div class="alm-content-area alm-d-flex alm-flex-row-nowrap alm-align-items-center">
                    <input class="alm-flex-1 alm-ignore-outline alm-w-10px" type="text" name="contact" autocomplete="off" required placeholder="<?php echo $this->get_settings_for_display('input_placeholder')?>">
                    <?php if($this->get_settings_for_display('show_divider')=='yes'):?>
						<div class='alm-newsletter-form-divider'></div>
					<?php endif;?>
					<button class="alm-d-flex alm-flex-row-wrap alm-align-items-center">
                        <?php echo $this->get_settings_for_display('button_text')?>
                        <?php if ($button_icon = $this->get_settings_for_display('button_icon')) \Elementor\Icons_Manager::render_icon( $button_icon, [ 'aria-hidden' => 'true' ] );?>
                    </button>
                </div>
                <div class="alm-newsletter-message alm-hide"></div>
            </form>
        </div>
        <?php
    }
}
