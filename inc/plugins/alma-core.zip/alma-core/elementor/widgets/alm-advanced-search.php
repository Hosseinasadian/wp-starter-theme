<?php
class ALM_Advanced_Search extends \Elementor\Widget_Base {
    public function get_name() {
        return 'alm_advanced_search';
    }

    public function get_title() {
        return __('جستجوی پیشرفته', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-search-results';
    }

	public function get_categories()
    {
        return ['alma'];
    }

	public function get_keywords()
    {
        return ['alma', 'advanced', 'search'];
    }

	protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('محتوا', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => __('متن راهنما', 'alma-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('نام محصول مورد نظر خود را وارد کنید', 'alma-core'),
            ]
        );
		$this->add_control(
            'show_search_divider',
            [
                'label' => esc_html__('خط جداکننده را نشان بده؟', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('بله', 'alma-core'),
                'label_off' => esc_html__('خیر', 'alma-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
		$this->add_control(
            'search_icon',
            [
                'label' => esc_html__('آیکن جستجو', 'alma-core'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            'search_wrapper_style_section',
            [
                'label' => esc_html__('باکس اصلی جستجو', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'search_wrapper_padding',
            [
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
            'search_wrapper_gap',
            [
                'label' => esc_html__('فضای داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'search_wrapper_border',
                'selector' => '{{WRAPPER}} .alm-search-wrapper',
            ]
        );
        $this->add_control(
            'search_wrapper_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'search_wrapper_bg_color',
            [
                'label' => esc_html__('پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_responsive_control(
            'search_wrapper_height',
            [
                'label' => esc_html__('ارتفاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
            'search_input_style_section',
            [
                'label' => esc_html__('فیلد جستجو', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'search_input_typography',
                'selector' => '{{WRAPPER}} .alm-search-wrapper .alm-search-box-input',
            ]
        );
		$this->add_control(
            'search_input_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper .alm-search-box-input' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
            'search_input_placeholder_color',
            [
                'label' => esc_html__('رنگ متن راهنما', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper .alm-search-box-input::placeholder' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
            'search_divider_style_section',
            [
                'label' => esc_html__('خط جداکننده', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'search_divider_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper .alm-search-box-divider' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'search_divider_height',
            [
                'label' => esc_html__('ارتفاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper .alm-search-box-divider' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'search_divider_bg_color',
            [
                'label' => esc_html__('پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
				'default'=>'rgba(185, 185, 185, 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .alm-search-wrapper .alm-search-box-divider' => 'background-color: {{VALUE}}',
                ],
            ]
        );
		$this->end_controls_section();

		$this->start_controls_section(
            'search_results_style_section',
            [
                'label' => esc_html__('نتایج جستجو', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
			'search_results_margin_top',
			[
				'label' => esc_html__( 'فاصله از باکس جستجو', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
                    '{{WRAPPER}} .alm-advanced-search .alm-search-results' => 'margin-top: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
            'search_results_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-advanced-search .alm-search-results' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'search_results_background',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .alm-advanced-search .alm-search-results',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'search_results_border',
                'selector' => '{{WRAPPER}} .alm-advanced-search .alm-search-results',
            ]
        );
        $this->add_control(
            'search_results_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-advanced-search .alm-search-results' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'search_results_box_shadow',
				'selector' => '{{WRAPPER}} .alm-advanced-search .alm-search-results',
			]
		);
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'search_results_typography',
                'selector' => '{{WRAPPER}} .alm-advanced-search .alm-search-results .alm-search-result-items, {{WRAPPER}} .alm-advanced-search .alm-search-results .alm-search-result-empty',
            ]
        );
		$this->add_control(
			'search_items_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-advanced-search .alm-search-results .alm-search-result-items .alm-search-result-item a,{{WRAPPER}} .alm-advanced-search .alm-search-results .alm-search-result-empty' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'search_items_hover_color',
			[
				'label' => esc_html__( 'رنگ متن در حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-advanced-search .alm-search-results .alm-search-result-items .alm-search-result-item:hover a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

    }

	public function get_script_depends()
    {
        return ["alm-advanced-search"];
    }

	public function get_style_depends()
    {
        return ["alm-advanced-search"];
    }

	protected function render() {
        $placeholder = $this->get_settings_for_display('placeholder');
		$search_icon = $this->get_settings_for_display('search_icon');
		$show_search_divider = $this->get_settings_for_display('show_search_divider')=='yes';
		?>
		<div class="alm-advanced-search">
			<form method="get" class="alm-search-form">
				<div class="alm-search-wrapper">
					<input type="text" class="alm-search-box-input" placeholder="<?php echo esc_attr($placeholder)?>" name="s" autocomplete="off">
					<?php if($show_search_divider):?>
					<div class="alm-search-box-divider"></div>
					<?php endif;?>
					<button type="submit" class="alm-search-submit">
						<?php
						if($search_icon && !empty($search_icon['value'])):
							\Elementor\Icons_Manager::render_icon( $search_icon, [ 'aria-hidden' => 'true','class'=> 'alm-search-box-icon'] );
						else:
							echo '<svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
	<path d="M10.1447 18.0694C14.5169 18.0694 18.0614 14.5249 18.0614 10.1527C18.0614 5.78044 14.5169 2.23602 10.1447 2.23602C5.77244 2.23602 2.22803 5.78044 2.22803 10.1527C2.22803 14.5249 5.77244 18.0694 10.1447 18.0694Z" stroke="#8D8D8D" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M18.8947 18.9027L17.228 17.236" stroke="#8D8D8D" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>';
						endif;
						?>
					</button>
				</div>
			</form>
			<div class="alm-search-results alm-hide"></div>
		</div>
		<?php
	}
}
