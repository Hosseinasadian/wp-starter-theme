<?php
class ALM_Custom_Image  extends \Elementor\Widget_Base{
    public function get_name() {
        return 'alm_custom_image';
    }

    public function get_title() {
        return __('تصویر سفارشی', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-image-box';
    }

	public function get_categories()
    {
        return ['alma'];
    }

	public function get_keywords()
    {
        return ['alma', 'custom', 'image'];
    }

	protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('محتوا', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'تصویر مورد نطر را انتخاب کنید', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'image_size',
			[
				'label' => esc_html__( 'اندازه تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'thumbnail',
				'options' => alm_attachment_sizes(),
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('استایل', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


		$this->add_responsive_control(
			'image_wrapper_display',
			[
				'label' => esc_html__( 'نحوه نمایش', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'flex' => esc_html__( 'عرض کامل', 'alma-core' ),
					'inline-flex' => esc_html__( 'عرض محتوا', 'alma-core' ),
				],
				'default' => 'flex',
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper' => 'display: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_wrapper_justify_content',
			[
				'label' => esc_html__( 'تراز کردن محتوا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-end-h',
					],
					'space-between' => [
						'title' => esc_html__( 'فاصله بینابینی', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-between-h',
					],
					'space-around' => [
						'title' => esc_html__( 'فضای اطراف', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-around-h',
					],
					'space-evenly' => [
						'title' => esc_html__( 'فضا یکنواخت', 'alma-core' ),
						'icon' => 'eicon-flex eicon-justify-space-evenly-h',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_wrapper_align_items',
			[
				'label' => esc_html__( 'چینش موارد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-center-v',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => esc_html__( 'کشیده', 'alma-core' ),
						'icon' => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper' => 'align-items: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
            'image_wrapper_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-image-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'image_wrapper_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-image-wrapper',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'image_wrapper_border',
				'selector' => '{{WRAPPER}} .alm-custom-image-wrapper',
			]
		);
		$this->add_responsive_control(
			'image_wrapper_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label' => esc_html__( 'عرض تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_height',
			[
				'label' => esc_html__( 'ارتفاع تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_object_fit',
			[
				'label' => esc_html__( 'متناسب با Object', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__( 'پیش فرض', 'alma-core' ),
					'fill' => esc_html__( 'پر', 'alma-core' ),
					'cover' => esc_html__( 'پوشش', 'alma-core' ),
					'contain' => esc_html__( 'دربرگیرنده', 'alma-core' ),
					'scale-down' => esc_html__( 'کاهش ابعاد', 'alma-core' ),
				],
				'default' => '',
				'condition' => [
					'image_height!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper img' => 'object-fit: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'image_object_position',
			[
				'label' => esc_html__( 'موقعیت شیء', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'' => esc_html__( 'پیش فرض', 'alma-core' ),
					'center center' => esc_html__( 'وسط وسط', 'alma-core' ),
					'center left' => esc_html__( 'وسط چپ', 'alma-core' ),
					'center right' => esc_html__( 'وسط راست', 'alma-core' ),
					'top center' => esc_html__( 'بالا وسط', 'alma-core' ),
					'top left' => esc_html__( 'بالا چپ', 'alma-core' ),
					'top right' => esc_html__( 'بالا راست', 'alma-core' ),
					'bottom center' => esc_html__( 'پایین وسط', 'alma-core' ),
					'bottom left' => esc_html__( 'پایین چپ', 'alma-core' ),
					'bottom right' => esc_html__( 'پایین راست', 'alma-core' ),
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .alm-custom-image-wrapper img' => 'object-position: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	public function get_style_depends()
    {
        return ["alm-custom-image"];
    }


	protected function render() {
        $image = $this->get_settings_for_display('image');
		$image_size = $this->get_settings_for_display('image_size');
		if(isset($image['id'])){
			echo "<div class='alm-custom-image-wrapper'>";
			echo wp_get_attachment_image( $image['id'], $image_size );
			echo "</div>";
		}
	}
}
