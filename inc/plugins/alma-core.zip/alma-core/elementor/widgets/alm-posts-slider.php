<?php

class ALM_Posts_Slider extends \ALMA\CORE\ALM_SWIPER{
	public function get_name() {
        return 'alm_posts_slider';
    }

    public function get_title() {
        return __('لیست نوشته ها', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

	public function get_keywords()
    {
        return ['alma', 'posts','slider'];
    }

	public function get_style_depends()
    {
		$style_depends = parent::get_style_depends()??[];
        return array_unique(array_merge($style_depends,[
			'alm-post-card'
		]));
    }

	protected function register_controls()
    {
		parent::register_controls();

		$this->start_controls_section(
            'query_content',
            [
                'label' => esc_html__('فیلتر نوشته ها', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('posts_count', [
            'label' => esc_html__('تعداد نوشته', 'alma-core'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 8,
        ]);

		$this->add_control(
			'terms',
			[
				'label' => esc_html__( 'دسته بندی', 'alma-core' ),
				'type' => 'alm_select_term',
				'multiple'=>true,
				'taxonomy'=>['category']
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'cart_content',
            [
                'label' => esc_html__('کارت نوشته', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

		$this->add_control(
			'widget_layout',
			[
				'label' => esc_html__( 'نحوه نمایش نوشته', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'slider',
				'options' => [
					'slider' => esc_html__( 'اسلایدر', 'alma-core' ),
					'list' => esc_html__( 'لیست', 'alma-core' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'cart_style',
            [
                'label' => __('کارت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'cart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'cart_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-post-card',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'cart_border',
				'selector' => '{{WRAPPER}} .alm-post-card',
			]
		);
		$this->add_responsive_control(
			'cart_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-post-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'cart_box_shadow',
				'selector' => '{{WRAPPER}} .alm-post-card',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'post_title_style',
            [
                'label' => esc_html__('عنوان پست', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'post_title_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-post-card .alm-post-card-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .alm-post-card .alm-post-card-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'post_title_typography',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-title',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'post_time_style',
            [
                'label' => esc_html__('تاریخ پست', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'post_time_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-post-card .alm-post-card-time' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'post_time_typography',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-time',
			]
		);
		$this->add_responsive_control(
            'post_time_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card .alm-post-card-time' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'post_time_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-time',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'post_time_border',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-time',
			]
		);
		$this->add_responsive_control(
			'post_time_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-post-card .alm-post-card-time' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'post_time_box_shadow',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-time',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'post_image_style',
            [
                'label' => esc_html__('تصویر پست', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'post_header_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card .alm-post-card-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		/**/
		$this->add_responsive_control(
            'post_header_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card .alm-post-card-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'post_header_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-header',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'post_header_border',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-header',
			]
		);
		$this->add_responsive_control(
			'post_header_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-post-card .alm-post-card-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'post_header_box_shadow',
				'selector' => '{{WRAPPER}} .alm-post-card .alm-post-card-header',
			]
		);
		/**/
		$this->add_responsive_control(
            'post_image_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card .alm-post-img-link img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'post_image_height',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-post-card .alm-post-img-link img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
			'post_image_object_fit',
			[
				'label' => esc_html__( 'متناسب با آبجکت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => [
					'' => esc_html__( 'پیش فرض', 'alma-core' ),
					'fill' => esc_html__( 'پر', 'alma-core' ),
					'cover'  => esc_html__( 'پوشش', 'alma-core' ),
					'contain' => esc_html__( 'دربرگیرنده', 'alma-core' ),
					'scale-down' => esc_html__( 'کاهش ابعاد', 'alma-core' ),
				],
				'selectors' => [
					'{{WRAPPER}} .alm-post-card .alm-post-img-link img' => 'object-fit: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

	}

	protected function render_slides(){
		$widget_layout = $this->get_settings_for_display('widget_layout');

		$query = $this->items;
		while($query->have_posts()){
			$query->the_post();
			$time_diff = human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) );

			if($widget_layout == 'slider')
				echo '<div class="swiper-slide">';
		?>
			<article class="alm-elementor-post-card alm-post-card">
				<div class="alm-post-card-header">
					<a class="alm-post-img-link" href="<?php the_permalink(); ?>">
						<img src="<?php echo get_the_post_thumbnail_url(get_the_ID()) ?>"
								alt="<?php echo get_the_title() ?>"/>
					</a>
				</div>
				<div class="alm-post-card-body">
					<div class="alm-post-card-title-time">
						<h3 class="alm-post-card-title">
							<a href="<?php the_permalink(); ?>">
								<?php the_title() ?>
							</a>
						</h3>
						<?php if($time_diff){?>
							<div class="alm-post-card-time"><?php echo $time_diff?></div>
						<?php }?>
					</div>
				</div>
			</article>
		<?php
			if($widget_layout == 'slider')
				echo '</div>';
		}
		wp_reset_postdata();
	}

	protected function render(){
		$query = $this->get_posts();
		$this->set_items($query);
		if ($query->have_posts()) {
			$widget_layout = $this->get_settings_for_display('widget_layout');
		?>
            <div class="alm-posts-slider <?php echo ($widget_layout == 'list'?'alm-posts-display-list':'')?>" style="height: 100%">
                <?php
					if($widget_layout=='slider'){
						parent::render();
					}else{
						$this->render_slides();
					}
				?>
            </div>
		<?php
		}
	}

	protected function get_posts(){
		$settings = $this->get_settings_for_display();

		$args = [
			'post_type' => 'post',
			'posts_per_page' => $settings['posts_count'],
			'post_status' => 'publish',
		];
		if (!empty($settings['terms'])) {
			$args['category__in'] = $settings['terms'];
		}

		$query = new WP_Query($args);

		return $query;
	}
}
