<?php
class ALM_Categories_Slider extends \ALMA\CORE\ALM_SWIPER{
	public function get_name()
    {
        return 'alm_categories_slider';
    }

    public function get_title()
    {
        return esc_html__('اسلایدر دسته بندی ', 'alma-core');
    }

    public function get_icon()
    {
        return 'eicon-slider-push';
    }

	public function get_keywords()
    {
        return ['alm', 'categories', 'slider'];
    }

	public function get_style_depends()
    {
		$style_depends = parent::get_style_depends()??[];
        return array_unique(array_merge($style_depends,[
			'alm-categories-slider'
		]));
    }

	protected function register_controls(){
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
            'category_name',
            [
                'label' => esc_html__('عنوان دسته بندی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
            ],
        );
		$repeater->add_control(
			'category_image',
			[
				'label' => esc_html__( 'تصویر دسته بندی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'category_link',
			[
				'label' => esc_html__( 'پیوند', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->start_controls_section(
            'slides_content',
            [
                'label' => esc_html__('اسلایدها', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
            'slides',
            [
                'label' => esc_html__('لیست اسلایدها', 'alma-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [],
            ]
        );
		$this->add_control(
			'image_size',
			[
				'label' => esc_html__( 'اندازه تصاویر دسته بندی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'thumbnail',
				'options' => alm_attachment_sizes(),
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'slides_style',
            [
                'label' => esc_html__('اسلایدها', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'slides_gap',
			[
				'label' => esc_html__( 'فاصله تصویر و عنوان', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-categories-slide' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
            'slides_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-categories-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'slides_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'category_name_style',
            [
                'label' => esc_html__('عنوان دسته بندی', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'category_name_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-categories-slide .alm-category-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'category_name_typography',
				'selector' => '{{WRAPPER}} .alm-categories-slide .alm-category-name',
			]
		);
		$this->add_control(
			'category_name_hover_text_color',
			[
				'label' => esc_html__( 'رنگ هاور متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-categories-slide-wrapper:hover .alm-category-name' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'category_image_style',
            [
                'label' => esc_html__('تصویر دسته بندی', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'category_image_width',
			[
				'label' => esc_html__( 'عرض باکس بیرونی تصویر', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-categories-slide .alm-category-image' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'category_image_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'category_image_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-categories-slide-wrapper .alm-category-image:after',
			]
		);

		$this->end_controls_section();


		parent::register_controls();
	}

	protected function render_slides()
    {
		$image_size = $this->get_settings_for_display('image_size');
        foreach ($this->items as $item) {
			?>
			<div class="swiper-slide elementor-repeater-item-<?php echo esc_attr($item['_id']) ?>">
				<?php if(isset($item['category_image']['id']) || isset($item['category_name'])){?>
					<?php
						$category_link = $item['category_link']['url']??'';
						$tag = $category_link?'a':'div';
						$tag_attributes = '';
						if($category_link){
							$tag_attributes .= "href='$category_link'";
						}
					?>
					<div class="alm-categories-slide-wrapper">
					<<?php echo $tag;?> class="alm-categories-slide" style="height: 100%" <?php echo $tag_attributes?>>
						<?php if(isset($item['category_image']['id'])){?>
							<div class="alm-category-image">
								<?php echo wp_get_attachment_image( $item['category_image']['id'], $image_size );?>
							</div>
						<?php }?>
						<?php if (isset($item['category_name'])) {?>
							<h3 class="alm-category-name"><?php echo $item['category_name']; ?></h3>
						<?php }?>
					</<?php echo $tag;?>>
						<svg width="75" height="10" viewBox="0 0 75 10" fill="none" xmlns="http://www.w3.org/2000/svg">
							<g clip-path="url(#clip0_8024_12665)">
							<rect width="75" height="10" fill="white"/>
							<path d="M97.4995 11.0001V121C97.4995 126.247 93.2462 130.5 87.9995 130.5H-12.0004C-17.2471 130.5 -21.5004 126.247 -21.5004 121V11.0001C-21.5004 5.75337 -17.2471 1.50008 -12.0004 1.50006L1.48381 1.50001C3.89164 1.50001 6.20965 2.4143 7.96914 4.05804L9.37586 5.37222C11.3205 7.18897 13.8825 8.19951 16.5438 8.19951H37.9996H58.1829C60.6838 8.19951 63.1026 7.30688 65.0039 5.68226L67.2329 3.77761C68.9532 2.30772 71.1416 1.50009 73.4043 1.50009H87.9995C93.2463 1.50009 97.4995 5.75339 97.4995 11.0001Z" fill="#F6F6F6" stroke="url(#paint0_linear_8024_12665)"/>
							</g>
							<defs>
							<linearGradient id="paint0_linear_8024_12665" x1="37.9996" y1="1" x2="37.9996" y2="121" gradientUnits="userSpaceOnUse">
							<stop stop-color="#B9B9B9"/>
							<stop offset="1" stop-color="#B9B9B9" stop-opacity="0"/>
							</linearGradient>
							<clipPath id="clip0_8024_12665">
							<rect width="75" height="10" fill="white"/>
							</clipPath>
							</defs>
						</svg>
					</div>
				<?php }?>
			</div>
			<?php
        }
    }

	protected function render()
    {
        $slides = $this->get_settings_for_display('slides');
        if (count($slides) > 0) {
            $this->set_items($slides);
            ?>
            <div class="alm-categories-slider" style="height: 100%">
                <?php parent::render(); ?>
            </div>
            <?php
        }
    }
}
