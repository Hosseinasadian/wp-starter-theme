<?php

class ALM_Product_Brands extends \ALMA\CORE\ALM_SWIPER {
    public function get_name() {
        return 'alm_product_brands';
    }

    public function get_title() {
        return __('لیست برندها', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-product-categories';
    }

	public function get_categories()
    {
        return ['alma'];
    }

	public function get_keywords()
    {
        return ['alma', 'product', 'brands'];
    }

	public function get_style_depends(){
		return ['alm-product-brands'];
	}

	protected function register_controls()
    {
		$this->start_controls_section(
            'cart_content',
            [
                'label' => esc_html__('تنظیمات نمایش', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
			'information',
			[
				'label' => esc_html__( 'Border Style', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'options' => [
					'all' => esc_html__( 'نام و لوگو', 'alma-core' ),
					'name' => esc_html__( 'نام', 'alma-core' ),
					'logo'  => esc_html__( 'لوگو', 'alma-core' ),
				],
			]
		);
		$this->add_control(
			'widget_layout',
			[
				'label' => esc_html__( 'نحوه نمایش محصولات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'list',
				'options' => [
					'slider' => esc_html__( 'اسلایدر', 'alma-core' ),
					'list' => esc_html__( 'لیست', 'alma-core' ),
				],
			]
		);
		$this->add_responsive_control(
			'list_cart_width',
			[
				'label' => esc_html__( 'عرض کارت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brands.alm-brands-display-list .alm-elementor-brand-item' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'widget_layout' => 'list',
				],
			]
		);
		$this->add_responsive_control(
			'list_cart_column_gap',
			[
				'label' => esc_html__( 'فضای افقی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brands.alm-brands-display-list' => 'column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'list_cart_row_gap',
			[
				'label' => esc_html__( 'فضای عمودی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brands.alm-brands-display-list' => 'row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'query_content',
            [
                'label' => esc_html__('فیلتر برندها', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('items_count', [
            'label' => esc_html__('تعداد برند', 'alma-core'),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'default' => 8,
        ]);
		$this->add_control(
			'hide_empty',
			[
				'label' => esc_html__( 'حذف برندهای خالی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'فعال', 'alma-core' ),
				'label_off' => esc_html__( 'غیرفعال', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'cart_style',
            [
                'label' => __('باکس دربرگیرنده', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'cart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-elementor-brand-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'cart_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-elementor-brand-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-elementor-brand-item',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'cart_border',
				'selector' => '{{WRAPPER}} .alm-elementor-brand-item',
			]
		);
		$this->add_responsive_control(
			'cart_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brand-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'cart_min_width',
			[
				'label' => esc_html__( 'کمترین عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brand-item' => 'min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'cart_min_height',
			[
				'label' => esc_html__( 'کمترین ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brand-item' => 'min-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'cart_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-elementor-brand-item:hover',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'cart_hover_border',
				'selector' => '{{WRAPPER}} .alm-elementor-brand-item:hover',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'logo_style',
            [
                'label' => __('برند', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'logo_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-elementor-brand-logo-container' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-logo-container svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-logo-container svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-elementor-brand-logo-container svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-logo-container svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'brand_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brand-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'brand_typography',
				'selector' => '{{WRAPPER}} .alm-elementor-brand-title a',
			]
		);
		$this->add_control(
			'brand_hover_heading',
			[
				'label' => esc_html__( 'حالت هاور', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'logo_hover_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-logo-container' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-logo-container svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-item:hover .alm-elementor-brand-logo-container svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-logo-container svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-logo-container svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'brand_hover_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-elementor-brand-item:hover .alm-elementor-brand-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

		parent::register_controls();
	}

	protected function render_slides(){
		$terms = $this->items;

		$widget_layout = $this->get_settings_for_display('widget_layout');
		$information = $this->get_settings_for_display('information');

		foreach ($terms as $term) {
			$brand_svg = get_term_meta($term->term_id, 'alm_brand_svg', true);


			if($widget_layout == 'slider')
				echo '<div class="swiper-slide">';
			?>

			<div class="alm-elementor-brand-item">
				<?php if(in_array($information,['all','logo']) && $brand_svg):?>
				<div class="alm-elementor-brand-logo-container">
					<a href="<?php echo get_term_link($term)?>"><?php echo alm_safe_svg($brand_svg);?></a>
				</div>
				<?php endif; ?>
				<?php if(in_array($information,['all','name'])):?>
				<h4 class="alm-elementor-brand-title"><a href="<?php echo get_term_link($term)?>"><?php echo $term->name?></a></h4>
				<?php endif;?>
			</div>
			<?php
			if($widget_layout == 'slider')
				echo '</div>';
		}
	}

	protected function render() {
		$args = array(
			'taxonomy' => 'alm_product_brand',
			'hide_empty' => $this->get_settings_for_display('hide_empty') == 'yes',
			'number' => $this->get_settings_for_display('items_count'),
		);
		$terms = get_terms($args);
		$this->set_items($terms);

		$widget_layout = $this->get_settings_for_display('widget_layout');

		?>
		<div class="alm-elementor-brands <?php echo ($widget_layout == 'list'?'alm-brands-display-list':'')?>">
			<?php
				if($widget_layout=='slider'){
					parent::render();
				}else{
					$this->render_slides();
				}
			?>
		</div>
		<?php
	}
}
