<?php
class ALM_Otp_Button extends \Elementor\Widget_Base{
	public function get_name() {
        return 'alm_otp_button';
    }

    public function get_title() {
        return __('دکمه ورود', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-dual-button';
    }

	public function get_categories()
    {
        return ['alma'];
    }

	public function get_keywords()
    {
        return ['alma', 'otp', 'login','button'];
    }

	protected function _register_controls() {
		$this->start_controls_section(
            'content_section',
            [
                'label' => __('محتوا', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
		$this->add_control(
			'button_title',
			[
				'label' => esc_html__( 'عنوان', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default'=>esc_html__('حساب کاربری','alma-core')
			]
		);

		$this->add_control(
			'button_icon',
			[
				'label' => esc_html__( 'انتخاب آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
		$this->add_control(
			'hide_if_logged_in',
			[
				'label' => esc_html__( 'برای کاربران وارد شده چیزی نشان نده؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'بله', 'alma-core' ),
				'label_off' => esc_html__( 'خیر', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'hide_if_guest',
			[
				'label' => esc_html__( 'برای کاربران مهمان چیزی نشان نده؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'بله', 'alma-core' ),
				'label_off' => esc_html__( 'خیر', 'alma-core' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'show_userinfo',
			[
				'label' => esc_html__( 'برای کاربران وارد شده نام و آواتار نشان بده؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'بله', 'alma-core' ),
				'label_off' => esc_html__( 'خیر', 'alma-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'content_style',
            [
                'label' => __('استایل کلی', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-otp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-otp-button',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'button_border',
				'selector' => '{{WRAPPER}} .alm-otp-button',
			]
		);
		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .alm-otp-button',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'title_icon_style',
            [
                'label' => __('متن و آیکن', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_title_typography',
                'selector' => '{{WRAPPER}} .alm-otp-button-title',
            ]
        );
		$this->add_control(
            'button_title_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-title' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
			'button_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-icon' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-otp-button-icon svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-otp-button-icon svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-otp-button-icon svg [stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-otp-button-icon svg [fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'button_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-icon' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-otp-button-icon svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_gap',
			[
				'label' => esc_html__( 'فضای خالی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-otp-button' => 'gap: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'button_flex_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'textdomain' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'textdomain' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'textdomain' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'textdomain' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_flex-wrap',
			[
				'label' => esc_html__( 'Wrap', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'wrap' => [
						'title' => esc_html__( 'Wrap', 'textdomain' ),
						'icon' => 'eicon-flex eicon-wrap',
					],
					'nowrap' => [
						'title' => esc_html__( 'No Wrap', 'textdomain' ),
						'icon' => 'eicon-flex eicon-nowrap',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button' => 'flex-wrap: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_justify_content',
			[
				'label' => esc_html__( 'تراز کردن محتوا', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-end-h',
					],
					'space-between' => [
						'title' => esc_html__( 'فاصله بینابینی', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-between-h',
					],
					'space-around' => [
						'title' => esc_html__( 'فضای اطراف', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-around-h',
					],
					'space-evenly' => [
						'title' => esc_html__( 'فضا یکنواخت', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-evenly-h',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'button_align_items',
			[
				'label' => esc_html__( 'چینش موارد', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-center-v',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => esc_html__( 'کشیده', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button' => 'align-items: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'username_avatar_style',
            [
                'label' => __('مشخصات کاربر', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'username_typography',
                'selector' => '{{WRAPPER}} .alm-otp-button-username',
            ]
        );
		$this->add_control(
            'username_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-username' => 'color: {{VALUE}}',
                ],
            ]
        );

		$this->add_responsive_control(
			'logged-in_button_gap',
			[
				'label' => esc_html__( 'فضای خالی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'selectors' => [
                    '{{WRAPPER}} .alm-otp-button.alm-otp-button-logged-in' => 'gap: {{SIZE}}{{UNIT}}',
				],
			]
		);
		$this->add_responsive_control(
			'logged-in_button_flex_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'textdomain' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'textdomain' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'textdomain' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'textdomain' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button.alm-otp-button-logged-in' => 'flex-direction: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'logged-in_button_flex-wrap',
			[
				'label' => esc_html__( 'Wrap', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'wrap' => [
						'title' => esc_html__( 'Wrap', 'textdomain' ),
						'icon' => 'eicon-flex eicon-wrap',
					],
					'nowrap' => [
						'title' => esc_html__( 'No Wrap', 'textdomain' ),
						'icon' => 'eicon-flex eicon-nowrap',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button.alm-otp-button-logged-in' => 'flex-wrap: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'logged-in_button_justify_content',
			[
				'label' => esc_html__( 'تراز کردن محتوا', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-start-h',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-center-h',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-end-h',
					],
					'space-between' => [
						'title' => esc_html__( 'فاصله بینابینی', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-between-h',
					],
					'space-around' => [
						'title' => esc_html__( 'فضای اطراف', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-around-h',
					],
					'space-evenly' => [
						'title' => esc_html__( 'فضا یکنواخت', 'textdomain' ),
						'icon' => 'eicon-flex eicon-justify-space-evenly-h',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button.alm-otp-button-logged-in' => 'justify-content: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'logged-in_button_align_items',
			[
				'label' => esc_html__( 'چینش موارد', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'start' => [
						'title' => esc_html__( 'آغاز', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-start-v',
					],
					'center' => [
						'title' => esc_html__( 'وسط', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-center-v',
					],
					'end' => [
						'title' => esc_html__( 'پایان', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-end-v',
					],
					'stretch' => [
						'title' => esc_html__( 'کشیده', 'textdomain' ),
						'icon' => 'eicon-flex eicon-align-stretch-v',
					],
				],
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button.alm-otp-button-logged-in' => 'align-items: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'logged-in_avatar_size',
			[
				'label' => esc_html__( 'اندازه آواتار', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
					'size' => 42,
				],
				'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-avatar img' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		/* avatar image */
		$this->add_responsive_control(
            'avatar_image_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-otp-button-avatar img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'avatar_image_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-otp-button-avatar img',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'avatar_image_border',
				'selector' => '{{WRAPPER}} .alm-otp-button-avatar img',
			]
		);
		$this->add_responsive_control(
			'avatar_image_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-otp-button-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'avatar_image_box_shadow',
				'selector' => '{{WRAPPER}} .alm-otp-button-avatar img',
			]
		);

		$this->end_controls_section();
	}

	public function get_style_depends()
    {
        return ["alm-otp-button"];
    }

	protected function render_for_guest(){
		$otp_enabled = alm_is_otp_enabled();
		$is_logged_in = is_user_logged_in();
		$link = '#';
		if($is_logged_in){
			$link = get_dashboard_url();
			if(function_exists('wc_get_account_endpoint_url') && wc_get_account_endpoint_url('dashboard')){
				$link = wc_get_account_endpoint_url('dashboard');
			}
		}else{
			if(!$otp_enabled){
				$link = wp_login_url();
				if(function_exists('wc_get_page_permalink') && wc_get_page_permalink( 'myaccount' )){
					$link = wc_get_page_permalink( 'myaccount' );
				}
			}
		}

		$button_title = $this->get_settings_for_display('button_title');
		$button_icon = $this->get_settings_for_display('button_icon');
		?>
			<a href="<?php echo $link?>" class="alm-open-otp-modal alm-otp-button" <?php echo (!$is_logged_in && $otp_enabled)?'data-otp':''?>>
				<?php if($button_title){?>
					<p class="alm-otp-button-title"><?php echo $button_title;?></p>
				<?php }?>
				<p class="alm-otp-button-icon">
					<?php
					if($button_icon && !empty($button_icon['value'])){
						\Elementor\Icons_Manager::render_icon( $button_icon, [ 'aria-hidden' => 'true' ] );
					}else{
						echo '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="29" viewBox="0 0 28 29" fill="none"><g id="vuesax/linear/profile-2user"><g id="profile-2user"><path id="Vector" d="M10.6857 13.2839C10.569 13.2722 10.429 13.2722 10.3007 13.2839C7.524 13.1905 5.319 10.9155 5.319 8.11555C5.319 5.25721 7.629 2.93555 10.499 2.93555C13.3573 2.93555 15.679 5.25721 15.679 8.11555C15.6673 10.9155 13.4623 13.1905 10.6857 13.2839Z" stroke="#F5683C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path id="Vector_2" d="M19.144 5.26855C21.4073 5.26855 23.2273 7.10022 23.2273 9.35189C23.2273 11.5569 21.4773 13.3536 19.2957 13.4352C19.2023 13.4236 19.0973 13.4236 18.9923 13.4352" stroke="#F5683C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path id="Vector_3" d="M4.85232 17.5886C2.02898 19.4786 2.02898 22.5586 4.85232 24.4369C8.06065 26.5836 13.3223 26.5836 16.5307 24.4369C19.354 22.5469 19.354 19.4669 16.5307 17.5886C13.334 15.4536 8.07232 15.4536 4.85232 17.5886Z" stroke="#F5683C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path id="Vector_4" d="M21.3957 23.9355C22.2357 23.7605 23.029 23.4222 23.6823 22.9205C25.5023 21.5555 25.5023 19.3039 23.6823 17.9389C23.0407 17.4489 22.259 17.1222 21.4307 16.9355" stroke="#F5683C" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></g></g></svg>';
					}  ?>
				</p>
			</a>
		<?php
	}

	protected function render() {
		$hide_if_logged_in = $this->get_settings_for_display('hide_if_logged_in') === 'yes';
		$hide_if_guest = $this->get_settings_for_display('hide_if_guest') === 'yes';
		if(is_user_logged_in()){
			if(!$hide_if_logged_in){
				$account_link = get_dashboard_url();
				if(function_exists('wc_get_account_endpoint_url') && wc_get_account_endpoint_url('dashboard')){
					$account_link = wc_get_account_endpoint_url('dashboard');
				}

				$show_userinfo = $this->get_settings_for_display('show_userinfo') === 'yes';
				if($show_userinfo){
					$user = wp_get_current_user();
					?>
						<a href="<?php echo $account_link?>" class="alm-otp-button alm-otp-button-logged-in">
							<p class="alm-otp-button-username"><?php echo $user->display_name;?></p>
							<p class="alm-otp-button-avatar"><?php echo get_avatar($user->ID)?></p>
						</a>
					<?php
				}else{
					$this->render_for_guest();
				}
			}
		}else{
			if(!$hide_if_guest){
				$this->render_for_guest();
			}
		}
	}
}
