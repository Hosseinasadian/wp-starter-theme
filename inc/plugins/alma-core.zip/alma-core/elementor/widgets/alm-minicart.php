<?php

class ALM_MiniCart extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alm_minicart';
    }

    public function get_title()
    {
        return esc_html__('مینی کارت', 'alma-core');
    }

    public function get_icon()
    {
        return 'eicon-cart';
    }

    public function get_categories()
    {
        return ['alma'];
    }

    public function get_keywords()
    {
        return ['alma', 'cart', 'minicart'];
    }

    public function get_script_depends()
    {
        return ['alm-minicart'];
    }

	public function get_style_depends()
    {
        return ['alm-minicart'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'show_cart_button',
            [
                'label' => esc_html__('دکمه نمایش سبد خرید', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'show_cart_button_icon',
            [
                'label' => esc_html__('آیکون سبد خرید', 'alma-core'),
                'type' => \Elementor\Controls_Manager::ICONS,
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'show_cart_button_style',
            [
                'label' => esc_html__('دکمه نمایش سبد خرید', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'show_cart_button_popover_toggle',
            [
                'label' => esc_html__('سفارشی سازی دکمه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->start_popover();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'show_cart_button_border',
                'selector' => '{{WRAPPER}} .alm-card-button',
            ]
        );
        $this->add_responsive_control(
            'show_cart_button_size',
            [
                'label' => esc_html__('سایز', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button' => 'display:flex;align-items:center;justify-content:center;width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_button_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_button_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_button_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'show_cart_button_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button .shopping-cart svg' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-card-button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_popover();

        $this->add_control(
            'show_cart_icon_size',
            [
                'label' => esc_html__('سایز آیکون سبد خرید', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-card-button .shopping-cart svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'show_cart_count_popover_toggle',
            [
                'label' => esc_html__('سفارشی سازی تعداد اقلام', 'alma-core'),
                'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->start_popover();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'show_cart_count_border',
                'selector' => '{{WRAPPER}} .card-count',
            ]
        );
        $this->add_control(
            'show_cart_count_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_height',
            [
                'label' => esc_html__('ارتفاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_top',
            [
                'label' => esc_html__('فاصله از بالا', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'show_cart_count_left',
            [
                'label' => esc_html__('فاصله از چپ', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .card-count' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_popover();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'show_cart_count_typography',
                'selector' => '{{WRAPPER}} .card-count',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'mini_cart_section',
            [
                'label' => esc_html__('خلاصه سبد خرید', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'mini_cart_z_index',
			[
				'label' => esc_html__( 'Z-Index', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .alm-minicart' => 'z-index: {{SIZE}};',
				],
			]
		);
        $this->add_responsive_control(
            'minicart_horizontal_position',
            [
                'label' => esc_html__('موقعیت افقی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'right' => esc_html__('راست', 'alma-core'),
                    'left' => esc_html__('چپ', 'alma-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => '{{VALUE}}: 0;',
                ],
            ]
        );
        $this->add_control(
            'minicart_top',
            [
                'label' => esc_html__('فاصله از بالا', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'minicart_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'minicart_border',
                'selector' => '{{WRAPPER}} .alm-minicart',
            ]
        );
        $this->add_control(
            'minicart_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'minicart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'minicart_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'items_space',
            [
                'label' => esc_html__('فاصله بین ردیف ها', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-woocommerce-mini-cart-item' => 'padding-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .alm-woocommerce-mini-cart-item:not(:first-child)' => 'padding-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'items_divider_size',
            [
                'label' => esc_html__('اندازه جدا کننده', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .alm-woocommerce-mini-cart-item' => 'border-bottom-width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'items_divider_border_color',
            [
                'label' => esc_html__('رنگ جدا کننده', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-woocommerce-mini-cart-item' => 'border-bottom-color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_image',
            [
                'label' => esc_html__('تصویر محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
            'cart_items_image_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail' => 'background-color: {{VALUE}}',
                ],
            ]
        );
		$this->add_control(
            'cart_items_image_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'cart_items_image_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'cart_items_image_border',
                'selector' => '{{WRAPPER}} .alm-product-thumbnail',
            ]
        );
        $this->add_control(
            'cart_items_image_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_title',
            [
                'label' => esc_html__('نام محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'items_title_typography',
                'selector' => '{{WRAPPER}} .alm-product-title',
            ]
        );
        $this->add_control(
            'items_title_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-product-title,{{WRAPPER}} .alm-product-title a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_title_gap',
            [
                'label' => esc_html__('فضای بین عنوان و تصویر محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail-title' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'thumbnail_title_margin_bottom',
            [
                'label' => esc_html__('فاصله از پایین', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-thumbnail-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_remove_button',
            [
                'label' => esc_html__('دکمه حذف آیتم', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'cart_items_remove_button_top',
            [
                'label' => esc_html__('فاصله از بالا', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .remove_from_cart_button' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'cart_items_remove_button_left',
            [
                'label' => esc_html__('فاصله از چپ', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .remove_from_cart_button' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'cart_items_remove_button_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .remove_from_cart_button svg' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'cart_items_remove_button_size',
            [
                'label' => esc_html__('اندازه آیکن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .remove_from_cart_button svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_discount_badge',
            [
                'label' => esc_html__('کادر تخفیف', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'discount_badge_typography',
                'selector' => '{{WRAPPER}} .alm-product-discount',
            ]
        );
        $this->add_control(
            'discount_badge_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-product-discount' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'discount_badge_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-product-discount' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'discount_badge_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-discount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'discount_badge_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-product-discount' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_regular_price',
            [
                'label' => esc_html__('قیمت قدیمی محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'regular_price_typography',
                'selector' => '{{WRAPPER}} .regular-price',
            ]
        );
        $this->add_control(
            'regular_price_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .regular-price' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_price',
            [
                'label' => esc_html__('قیمت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'price_typography',
                'selector' => '{{WRAPPER}} .sale-price',
            ]
        );
        $this->add_control(
            'price_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sale-price' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'price_currency_symbol_typography',
                'selector' => '{{WRAPPER}} .sale-price .woocommerce-Price-currencySymbol',
            ]
        );
        $this->add_control(
            'price_currency_symbol_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .sale-price .woocommerce-Price-currencySymbol' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_items_quantity',
            [
                'label' => esc_html__('تعداد محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .alm-add-to-cart-quantity',
            ]
        );
        $this->add_control(
            'quantity_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-add-to-cart-quantity' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'quantity_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-add-to-cart-quantity' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'quantity_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-add-to-cart-quantity' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'quantity_input',
            [
                'label' => esc_html__('فیلد تعداد', 'alma-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'quantity_input_width',
            [
                'label' => esc_html__('عرض', 'alma-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .quantity .qty' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'quantity_input_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .quantity .qty' => 'background-color: {{VALUE}};border:none;',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'quantity_input_typography',
                'selector' => '{{WRAPPER}} .quantity .qty',
            ]
        );
        $this->add_control(
            'quantity_input_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .quantity .qty' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'quantity_buttons',
            [
                'label' => esc_html__('دکمه های افزایش و کاهش تعداد محصول', 'alma-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'quantity_buttons_typography',
                'selector' => '{{WRAPPER}} .quantity .alm-change-quantity',
            ]
        );
        $this->add_control(
            'quantity_buttons_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .quantity .alm-change-quantity' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .quantity .alm-change-quantity svg path' => 'stroke: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'quantity_buttons_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .quantity .alm-change-quantity' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'quantity_buttons_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .quantity .alm-change-quantity' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'quantity_buttons_border',
                'selector' => '{{WRAPPER}} .quantity .alm-change-quantity',
            ]
        );
        $this->add_control(
            'quantity_buttons_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .quantity .alm-change-quantity' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'total_price',
            [
                'label' => esc_html__('قیمت کل', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'cart_total_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-total-price' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'cart_total_typography',
                'selector' => '{{WRAPPER}} .alm-total-price',
            ]
        );
		$this->add_control(
            'cart_total_price_title_heading',
            [
                'label' => esc_html__('برچسب', 'alma-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
		$this->add_control(
            'cart_total_price_title_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-total-price .alm-total-price-title' => 'color: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'cart_total_price_title_typography',
                'selector' => '{{WRAPPER}} .alm-minicart-total-price .alm-total-price-title',
            ]
        );
        $this->add_control(
            'cart_total_price_unit_title',
            [
                'label' => esc_html__('واحد پولی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'cart_total_title_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-total-price-title' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-total-price .woocommerce-Price-currencySymbol' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'cart_total_title_typography',
                'selector' => '{{WRAPPER}} .alm-total-price-title,{{WRAPPER}} .alm-total-price .woocommerce-Price-currencySymbol',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'cart_button',
            [
                'label' => esc_html__('دکمه ثبت سفارش', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'cart_button_typography',
                'selector' => '{{WRAPPER}} .alm-minicart-button',
            ]
        );
        $this->add_control(
            'cart_button_bg_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-button' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'cart_button_text_color',
            [
                'label' => esc_html__('رنگ متن', 'alma-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'cart_button_radius',
            [
                'label' => esc_html__('شعاع', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'cart_button_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'cart_button_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-minicart-total' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

    }

    public function render()
    {
        $cart_icon = $this->get_settings_for_display('show_cart_button_icon');
        ?>
        <div class="alm-elementor-minicart">
            <div class="alm-card-button">
                <span class="shopping-cart">
					<?php
					if($cart_icon && !empty($cart_icon['value'])){
						\Elementor\Icons_Manager::render_icon($cart_icon, ['aria-hidden' => 'true', 'className' => 'shopping-cart']);
					}else{
						echo '<svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
  <path d="M9.71906 2.81039L6.09906 6.44039" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M16.0991 2.81039L19.7191 6.44039" stroke="white" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M2.90906 8.6604C2.90906 6.8104 3.89906 6.6604 5.12906 6.6604H20.6891C21.9191 6.6604 22.9091 6.8104 22.9091 8.6604C22.9091 10.8104 21.9191 10.6604 20.6891 10.6604H5.12906C3.89906 10.6604 2.90906 10.8104 2.90906 8.6604Z" stroke="white" stroke-width="1.5"/>
  <path d="M10.6691 14.8104V18.3604" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M15.269 14.8104V18.3604" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M4.40906 10.8104L5.81906 19.4504C6.13906 21.3904 6.90906 22.8104 9.76906 22.8104H15.7991C18.9091 22.8104 19.3691 21.4504 19.7291 19.5704L21.4091 10.8104" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
</svg>';
					}
					 ?>
				</span>
                <span class="card-count"><?php echo WC()->cart->get_cart_contents_count() ?></span>
            </div>
            <div class="alm-minicart alm-hide">
                <?php
            	alm_get_mini_cart_content();
                ?>
            </div>
        </div>
        <?php
    }
}
