<?php
class ALM_Custome_Products_Slider extends \ALMA\CORE\ALM_SWIPER{
	public function get_name() {
        return 'alm_custom_products_slider';
    }

    public function get_title() {
        return __('لیست محصولات سفارشی', 'alma-core');
    }

    public function get_icon() {
        return 'eicon-slider-device';
    }

	public function get_keywords()
    {
        return ['alma', 'products','slider','custom', 'woocommerce'];
    }

	public function get_style_depends()
    {
		$style_depends = parent::get_style_depends()??[];
        return array_unique(array_merge($style_depends,[
			'alm-custom-products-slider'
		]));
    }

	protected function transform_settings($settings){
		$settings['autoHeight']=true;
		return $settings;
	}

	protected function register_controls()
    {
		$products = new \Elementor\Repeater();

		$products->add_control(
			'product_image',
			[
				'label' => esc_html__( 'تصویر محصول', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$products->add_control(
			'product_id',
			[
				'label' => esc_html__( 'انتخاب محصول', 'alma-core' ),
				'type' => 'alm_select_post',
				'post_type'=>['product']
			]
		);


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'محتوا', 'alma-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'products',
			[
				'label' => esc_html__( 'لیست محصولات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $products->get_controls(),
				'prevent_empty'=>false,
				'default'=>[]
			]
		);

		$this->add_control(
			'product_attributes_list',
			[
				'label' => esc_html__( 'کدام ویژگی های محصول نشان داده شود؟', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => alm_wc_product_attributes_list(),
				'default' => [],
			]
		);

		$this->add_control(
			'add_to_cart_icon',
			[
				'label' => esc_html__( 'آیکن افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,

			]
		);
		$this->add_control(
			'add_to_cart_text',
			[
				'label' => esc_html__( 'متن افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'view_detail_icon',
			[
				'label' => esc_html__( 'آیکن مشاهده جزییات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
		$this->add_control(
			'view_detail_text',
			[
				'label' => esc_html__( 'متن مشاهده جزییات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'card_style',
			[
				'label' => esc_html__( 'کارت محصول', 'alma-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'card_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'card_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'card_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card-content',
			]
		);
		$this->add_responsive_control(
			'card_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .alm-custom-product-card:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],
			]
		);
		$this->add_control(
			'cart_before_background_heading',
			[
				'label' => esc_html__( 'سایه کارت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_gradient_border',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card:before',
			]
		);
		$this->add_control(
			'cart_before_background_hover_heading',
			[
				'label' => esc_html__( 'سایه در حالت هاور کارت', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cart_hover_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card:hover:before',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'product_image_style',
			[
				'label' => esc_html__( 'تصویر محصول', 'alma-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'product_image_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-image' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
            'product_discount_style',
            [
                'label' => esc_html__('درصد تخفیف', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_discount_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_discount_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage',
			]
		);
		$this->add_control(
			'discount_main_layer_heading',
			[
				'label' => esc_html__( 'لایه اصلی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_height',
			[
				'label' => esc_html__( 'ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_top',
			[
				'label' => esc_html__( 'آفست بالا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_left',
			[
				'label' => esc_html__( 'آفست چپ', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'discount_main_layer_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage',
			]
		);
		$this->add_responsive_control(
			'discount_main_layer_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'discount_before_layer_heading',
			[
				'label' => esc_html__( 'لایه پشتی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_width',
			[
				'label' => esc_html__( 'عرض', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_height',
			[
				'label' => esc_html__( 'ارتفاع', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_top',
			[
				'label' => esc_html__( 'آفست بالا', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_left',
			[
				'label' => esc_html__( 'آفست چپ', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'discount_before_layer_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before',
			]
		);
		$this->add_responsive_control(
			'discount_before_layer_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-discount-percentage::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
            'product_title_style',
            [
                'label' => esc_html__('عنوان محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'product_title_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_title_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-title',
			]
		);
		$this->end_controls_section();

		//modify
		$this->start_controls_section(
            'sale_price_style',
            [
                'label' => esc_html__('قیمت محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_responsive_control(
            'product_sell_info_margin',
            [
                'label' => esc_html__('حاشیه خارجی سبد خرید و قیمت', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-sell-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
			'sale_price_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .sale-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sale_price_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .sale-price',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'regular_price_style',
            [
                'label' => esc_html__('قیمت بدون تخفیف محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'regular_price_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .regular-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'regular_price_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .regular-price',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'currency_style',
            [
                'label' => esc_html__('واحد پولی', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'currency_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-price-currency' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'currency_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-price-currency',
			]
		);

		$this->add_responsive_control(
			'price_box_gap',
			[
				'label' => esc_html__( 'فاصله قیمت و واحد پولی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-price-box' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'add_to_cart_style',
            [
                'label' => esc_html__('دکمه افزودن به سبد', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
            'add_to_cart_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'add_to_cart_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'add_to_cart_border',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart',
			]
		);

		$this->add_responsive_control(
			'add_to_cart_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'add_to_cart_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'add_to_cart_gap',
			[
				'label' => esc_html__( 'فاصله متن و آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'add_to_cart_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'add_to_cart_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-add-to-cart-text',
			]
		);

		$this->add_control(
			'add_to_cart_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'add_to_cart_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-add-to-cart svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sell_info_gap',
			[
				'label' => esc_html__( 'فاصله قیمت و افزودن به سبد', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-sell-info' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		//view datail for grouped and variable product
		$this->add_control(
			'view_detail_heading',
			[
				'label' => esc_html__( 'دکمه مشاهده جزيیات', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
            'view_detail_padding',
            [
                'label' => esc_html__('فاصله داخلی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card .alm-view-detail' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'view_detail_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-view-detail',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'view_detail_border',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-view-detail',
			]
		);

		$this->add_responsive_control(
			'view_detail_border_radius',
			[
				'label' => esc_html__( 'انحنای حاشیه', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-view-detail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_detail_display_direction',
			[
				'label' => esc_html__( 'جهت یابی', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'ردیف-افقی', 'alma-core' ),
						'icon' => 'eicon-arrow-left',
					],
					'column' => [
						'title' => esc_html__( 'ستون-عمودی', 'alma-core' ),
						'icon' => 'eicon-arrow-down',
					],
					'row-reverse' => [
						'title' => esc_html__( 'سطر-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-right',
					],
					'column-reverse' => [
						'title' => esc_html__( 'ستون-معکوس شده', 'alma-core' ),
						'icon' => 'eicon-arrow-up',
					],
				],
				'default' => 'row',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card a.alm-view-detail' => 'flex-direction: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'view_detail_gap',
			[
				'label' => esc_html__( 'فاصله متن و آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-view-detail' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'view_detail_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-view-detail-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'view_detail_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-view-detail-text',
			]
		);

		$this->add_control(
			'view_detail_icon_color',
			[
				'label' => esc_html__( 'رنگ آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail svg[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail svg[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .alm-custom-product-card a.alm-view-detail svg path[stroke]:not([stroke="none"])' => 'stroke: {{VALUE}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail svg path[fill]:not([fill="none"])' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'view_detail_icon_size',
			[
				'label' => esc_html__( 'اندازه آیکن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
				'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail' => 'font-size: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .alm-custom-product-card a.alm-view-detail svg' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'product_attributes_style',
            [
                'label' => esc_html__('ویژگی های محصول', 'alma-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
            'product_attributes_margin',
            [
                'label' => esc_html__('حاشیه خارجی', 'alma-core'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-attributes' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'product_attributes_item_text_color',
			[
				'label' => esc_html__( 'رنگ متن', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-attributes .alm-custom-product-attribute' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'product_attributes_item_typography',
				'selector' => '{{WRAPPER}} .alm-custom-product-card .alm-custom-product-attributes .alm-custom-product-attribute',
			]
		);
		$this->add_responsive_control(
			'product_attributes_gap',
			[
				'label' => esc_html__( 'فاصله بین ویژگی ها', 'alma-core' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .alm-custom-product-card .alm-custom-product-attributes' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		parent::register_controls();

	}

	protected function get_products($products){
		$selected_products = [];
		if($products){
			$include = array_unique(array_map(function($product){
				return $product['product_id'][0];
			},$products));
			$products_list = wc_get_products([
				'include'=>$include
			]);
			foreach($products_list as $item){
				$selected_products[$item->get_id()] = $item;
			}
		}
		return $selected_products;
	}

	protected function render(){
		$products = $this->get_settings_for_display('products');

		$this->set_items($products);

		?>
		<div class="alm-custom-products-slider" style="height: 100%">
			<?php
				parent::render();
			?>
		</div>
		<?php
	}

	protected function render_slides(){
		$add_to_cart_icon = $this->get_settings_for_display('add_to_cart_icon');
		$add_to_cart_text = $this->get_settings_for_display('add_to_cart_text');

		$view_detail_icon = $this->get_settings_for_display('view_detail_icon');
		$view_detail_text = $this->get_settings_for_display('view_detail_text');

		$currency = get_woocommerce_currency_symbol();

		$products = $this->items;
		$products_list = $this->get_products($products);
		foreach($products as $item){
			if(isset($item['product_id'][0]) && isset($products_list[$item['product_id'][0]])){
				$product = $products_list[$item['product_id'][0]];
				$price_html = alm_wc_price_html($product);
				$discount = alm_wc_discount_percentage($product);
				?>
				<div class="swiper-slide elementor-repeater-item-<?php echo $item['_id'];?>" data-img="<?php echo $item['product_image']['url']?>">
					<div class="alm-custom-product-card">
						<div class="alm-custom-product-card-content">
							<?php if($discount){?>
								<div class="alm-custom-product-discount-percentage">
									<?php echo alm_wc_discount_percentage($product)?>
								</div>
							<?php }?>
							<h3 class="alm-custom-product-title"><a href="<?php echo get_the_permalink($product->get_id())?>"><?php echo get_the_title($product->get_id());?></a></h3>
							<?php $this->show_properties($product);?>
							<?php if($price_html){?>
								<div class="alm-custom-product-sell-info">
									<?php if ($product->is_type('variable') || $product->is_type('grouped')) {?>
										<a class="alm-view-detail" href='<?php echo the_permalink() ?>'>
											<?php
												if($view_detail_icon && !empty($view_detail_icon['value'])){
													\Elementor\Icons_Manager::render_icon( $view_detail_icon, [ 'aria-hidden' => 'true','class'=> 'alm-view-detail-icon'] );
												}else{
													echo '<svg class="alm-view-detail-icon" xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
  <path d="M6.92334 7.31347V6.50514C6.92334 4.63014 8.43167 2.78847 10.3067 2.61347C12.54 2.39681 14.4233 4.15514 14.4233 6.34681V7.49681" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8.17332 19.2552H13.1733C16.5233 19.2552 17.1233 17.9135 17.2983 16.2802L17.9233 11.2802C18.1483 9.24682 17.565 7.58849 14.0067 7.58849H7.33998C3.78165 7.58849 3.19832 9.24682 3.42332 11.2802L4.04832 16.2802C4.22332 17.9135 4.82332 19.2552 8.17332 19.2552Z" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M13.5863 10.9218H13.5938" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M7.75206 10.9218H7.75954" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
												}											?>
											<?php
												if($view_detail_text){
													echo "<span class='alm-view-detail-text'>$view_detail_text</span>";
												}
											?>
										</a>
									<?php }else {?>
										<a class="alm-add-to-cart add_to_cart_button ajax_add_to_cart" href='<?php echo $product->add_to_cart_url() ?>' data-quantity="1" data-product_id="<?php echo $product->get_id()?>">
											<?php
												if($add_to_cart_icon && !empty($add_to_cart_icon['value'])){
													\Elementor\Icons_Manager::render_icon( $add_to_cart_icon, [ 'aria-hidden' => 'true','class'=> 'alm-add-to-cart-icon'] );
												}else{
													echo '<svg class="alm-add-to-cart-icon" xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
  <path d="M6.92334 7.31347V6.50514C6.92334 4.63014 8.43167 2.78847 10.3067 2.61347C12.54 2.39681 14.4233 4.15514 14.4233 6.34681V7.49681" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M8.17332 19.2552H13.1733C16.5233 19.2552 17.1233 17.9135 17.2983 16.2802L17.9233 11.2802C18.1483 9.24682 17.565 7.58849 14.0067 7.58849H7.33998C3.78165 7.58849 3.19832 9.24682 3.42332 11.2802L4.04832 16.2802C4.22332 17.9135 4.82332 19.2552 8.17332 19.2552Z" stroke="white" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M13.5863 10.9218H13.5938" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M7.75206 10.9218H7.75954" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
</svg>';
												}
											?>
											<?php
												if($add_to_cart_text){
													echo "<span class='alm-add-to-cart-text'>$add_to_cart_text</span>";
												}
											?>
										</a>
									<?php }?>
									<?php if($price_html || $price_html == '0'){?>
									<div class='alm-custom-product-price-box'>
										<div class='alm-custom-product-price'>
											<?php echo $price_html;?>
										</div>
										<?php if(alm_wc_enable_show_currency($product)):?>
										<div class='alm-custom-product-price-currency'>
											<?php echo $currency;?>
										</div>
										<?php endif;?>
									</div>
									<?php }?>
								</div>
							<?php }?>
						</div>
					</div>
				</div>
				<?php
			}
		}
	}

	protected function before_swiper(){
		echo "<div class='alm-custom-product-image'></div>";
	}

	protected function show_properties($product){
		$product_attributes_list = $this->get_settings_for_display('product_attributes_list');
		if(count($product_attributes_list)>0){
			echo "<ul class='alm-custom-product-attributes'>";
			foreach($product_attributes_list as $atrribute){
				$attribute_value = $product->get_attribute( "pa_$atrribute" );
				$attribute_label = alm_wc_product_get_attribute_label($atrribute);
				if($attribute_value){
					echo "<li class='alm-custom-product-attribute'>" . esc_html($attribute_label) . " " .esc_html( $attribute_value )."</li>";
				}
			}
			echo "</ul>";
		}
	}
}
