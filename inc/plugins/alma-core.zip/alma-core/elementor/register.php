<?php
function add_elementor_widget_alma_category($elements_manager)
{
	$elements_manager->add_category(
		'alma',
		[
			'title' => esc_html__('ویجت های قالب آلما', 'alma-core'),
			'icon' => 'fa fa-plug',
		]
	);
}

add_action('elementor/elements/categories_registered', 'add_elementor_widget_alma_category');

function register_alm_core_widgets($widgets_manager) {
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-mobile-menu.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-advanced-search.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-custom-image.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-categories-slider.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-post-card.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-posts-slider.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-comments-slider.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-otp-button.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-newsletter.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-custom-slide.php';

	// woocommerce
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-products-slider.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-minicart.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-product-brands.php';
	require ALMA_CORE_ROOT . '/elementor/widgets/alm-custom-products-slider.php';

	$widgets_manager->register( new ALM_Mobile_Menu() );
	$widgets_manager->register( new ALM_Advanced_Search() );
	$widgets_manager->register( new ALM_Custom_Image() );
	$widgets_manager->register( new ALM_Categories_Slider );
	$widgets_manager->register( new ALM_Post_Card );
	$widgets_manager->register( new ALM_Posts_Slider() );
	$widgets_manager->register( new ALM_Comments_Slider() );
	$widgets_manager->register( new ALM_Otp_Button() );
	$widgets_manager->register( new ALM_Newsletter() );
	$widgets_manager->register( new ALM_Custom_Slide() );

	// woocommerce
	$widgets_manager->register( new ALM_Products_Slider() );
	$widgets_manager->register( new ALM_MiniCart() );
	$widgets_manager->register( new ALM_Product_Brands() );
	$widgets_manager->register( new ALM_Custome_Products_Slider() );
}
add_action( 'elementor/widgets/register', 'register_alm_core_widgets' );

function register_alm_core_controls( $controls_manager ) {

    require trailingslashit(ALMA_CORE_ROOT) . 'elementor/controls/alm-select-term.php';
	require trailingslashit(ALMA_CORE_ROOT) . 'elementor/controls/alm-select-post.php';

    $controls_manager->register( new ALM_Select_Term() );
	$controls_manager->register( new ALM_Select_Post() );

}
add_action( 'elementor/controls/register', 'register_alm_core_controls' );
